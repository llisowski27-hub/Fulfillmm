// ============================================================
// THE LIQUIDATOR — Payouts Module
// src/types/payouts.ts
// ============================================================
// Single source of truth: TS interface + Zod schemas
// Mirrors: SQL schema v1.1 → tabela `payouts`
// ============================================================

import { z } from "zod";

// ────────────────────────────────────────────────────────────
// 1. ENUM
// ────────────────────────────────────────────────────────────

export const PAYOUT_STATUS = ["oczekujace", "wyplacone"] as const;
export type PayoutStatus = (typeof PAYOUT_STATUS)[number];

// ────────────────────────────────────────────────────────────
// 2. INTERFEJS TYPESCRIPT — pełny wiersz z bazy
// ────────────────────────────────────────────────────────────

export interface Payout {
  id: string;
  client_id: string;
  kwota_netto: number;
  status: PayoutStatus;
  created_at: string;
  updated_at: string;
}

// ────────────────────────────────────────────────────────────
// 3. ZOD — CREATE (nowa wypłata)
// ────────────────────────────────────────────────────────────

export const createPayoutSchema = z.object({
  client_id: z.string().uuid("Nieprawidłowy identyfikator klienta"),

  kwota_netto: z
    .number()
    .min(0, "Kwota netto nie może być ujemna")
    .max(999_999.99, "Kwota przekracza dopuszczalny limit"),

  // Nowa wypłata zawsze startuje jako oczekująca
  status: z
    .literal("oczekujace", {
      errorMap: () => ({
        message: "Nowa wypłata musi mieć status 'oczekujace'",
      }),
    })
    .default("oczekujace"),
});

export type CreatePayoutInput = z.infer<typeof createPayoutSchema>;

// ────────────────────────────────────────────────────────────
// 4. ZOD — UPDATE (zmiana statusu: oczekujace → wyplacone)
//    Jednokierunkowa tranzycja — nie można cofnąć wypłaty.
//    Kwota i client_id niezmienne po utworzeniu.
// ────────────────────────────────────────────────────────────

export const updatePayoutSchema = z.object({
  status: z.literal("wyplacone", {
    errorMap: () => ({
      message: "Jedyna dozwolona zmiana: status → 'wyplacone'",
    }),
  }),
});

export type UpdatePayoutInput = z.infer<typeof updatePayoutSchema>;

// ────────────────────────────────────────────────────────────
// 5. ZOD — ROW (pełny wiersz z bazy, SELECT)
// ────────────────────────────────────────────────────────────

export const payoutRowSchema = z.object({
  id: z.string().uuid(),
  client_id: z.string().uuid(),
  kwota_netto: z.number(),
  status: z.enum(PAYOUT_STATUS),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

export type PayoutRow = z.infer<typeof payoutRowSchema>;

// ────────────────────────────────────────────────────────────
// 6. ZOD — FILTR (query params do listowania wypłat)
// ────────────────────────────────────────────────────────────

export const payoutFilterSchema = z.object({
  client_id: z.string().uuid().optional(),
  status: z.enum(PAYOUT_STATUS).optional(),
  from: z.string().datetime().optional(),
  to: z.string().datetime().optional(),
});

export type PayoutFilter = z.infer<typeof payoutFilterSchema>;
