// ============================================================
// THE LIQUIDATOR — Users Module
// src/types/users.ts
// ============================================================
// Single source of truth: TS interface + Zod schemas
// Mirrors: SQL migration 003 → tabele `user_profiles`,
//          `user_addresses`
// ============================================================

import { z } from "zod";

// ────────────────────────────────────────────────────────────
// 1. INTERFEJSY TYPESCRIPT
// ────────────────────────────────────────────────────────────

export interface UserProfileRow {
  id: string;
  display_name: string;
  phone: string | null;
  default_address_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface UserAddressRow {
  id: string;
  user_id: string;
  label: string;
  full_name: string;
  street: string;
  city: string;
  postal_code: string;
  country: string;
  phone: string | null;
  created_at: string;
  updated_at: string;
}

// ────────────────────────────────────────────────────────────
// 2. ZOD — USER PROFILE
// ────────────────────────────────────────────────────────────

export const createUserProfileSchema = z.object({
  display_name: z
    .string()
    .trim()
    .min(1, "Nazwa wyświetlana jest wymagana")
    .max(100, "Nazwa max 100 znaków"),
  phone: z.string().trim().max(20).nullable().default(null),
});

export type CreateUserProfileInput = z.infer<typeof createUserProfileSchema>;

export const updateUserProfileSchema = z.object({
  display_name: z.string().trim().min(1).max(100).optional(),
  phone: z.string().trim().max(20).nullable().optional(),
  default_address_id: z.string().uuid().nullable().optional(),
});

export type UpdateUserProfileInput = z.infer<typeof updateUserProfileSchema>;

export const userProfileRowSchema = z.object({
  id: z.string().uuid(),
  display_name: z.string(),
  phone: z.string().nullable(),
  default_address_id: z.string().uuid().nullable(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

// ────────────────────────────────────────────────────────────
// 3. ZOD — USER ADDRESS
// ────────────────────────────────────────────────────────────

export const createUserAddressSchema = z.object({
  label: z.string().trim().max(50, "Etykieta max 50 znaków").default("Domowy"),
  full_name: z.string().trim().min(1, "Imię i nazwisko wymagane").max(200),
  street: z.string().trim().min(1, "Ulica wymagana").max(300),
  city: z.string().trim().min(1, "Miasto wymagane").max(100),
  postal_code: z
    .string()
    .trim()
    .min(1, "Kod pocztowy wymagany")
    .regex(/^\d{2}-\d{3}$/, "Format kodu: 00-000"),
  country: z.string().trim().default("PL"),
  phone: z.string().trim().max(20).nullable().default(null),
});

export type CreateUserAddressInput = z.infer<typeof createUserAddressSchema>;

export const updateUserAddressSchema = createUserAddressSchema.partial();
export type UpdateUserAddressInput = z.infer<typeof updateUserAddressSchema>;

export const userAddressRowSchema = z.object({
  id: z.string().uuid(),
  user_id: z.string().uuid(),
  label: z.string(),
  full_name: z.string(),
  street: z.string(),
  city: z.string(),
  postal_code: z.string(),
  country: z.string(),
  phone: z.string().nullable(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});
