// ============================================================
// THE LIQUIDATOR — Barrel Export
// src/types/index.ts
// ============================================================
// Centralny punkt importów dla całego projektu.
// Usage: import { Client, createClientSchema, STAN_ITEMS } from "@/types";
// ============================================================

// ── Clients ─────────────────────────────────────────────────
export {
  TYP_MODELU,
  type TypModelu,
  type Client,
  createClientSchema,
  type CreateClientInput,
  updateClientSchema,
  type UpdateClientInput,
  clientRowSchema,
  type ClientRow,
} from "./clients";

// ── Inventory Items ─────────────────────────────────────────
export {
  STAN_ITEMS,
  STAN_LABELS,
  type Stan,
  STATUS_ITEMS,
  type Status,
  type InventoryItem,
  createInventoryItemSchema,
  type CreateInventoryItemInput,
  updateInventoryItemSchema,
  type UpdateInventoryItemInput,
  inventoryItemRowSchema,
  type InventoryItemRow,
  markAuditedSchema,
  type MarkAuditedInput,
} from "./inventory";

// ── Warehouse Logs ──────────────────────────────────────────
export {
  TYP_AKCJI,
  type TypAkcji,
  type WarehouseLog,
  createWarehouseLogSchema,
  type CreateWarehouseLogInput,
  updateWarehouseLogSchema,
  type UpdateWarehouseLogInput,
  warehouseLogRowSchema,
  type WarehouseLogRow,
  warehouseLogFilterSchema,
  type WarehouseLogFilter,
} from "./warehouse-logs";

// ── Payouts ─────────────────────────────────────────────────
export {
  PAYOUT_STATUS,
  type PayoutStatus,
  type Payout,
  createPayoutSchema,
  type CreatePayoutInput,
  updatePayoutSchema,
  type UpdatePayoutInput,
  payoutRowSchema,
  type PayoutRow,
  payoutFilterSchema,
  type PayoutFilter,
} from "./payouts";

// ── Users (Marketplace) ────────────────────────────────────
export {
  type UserProfileRow,
  type UserAddressRow,
  createUserProfileSchema,
  type CreateUserProfileInput,
  updateUserProfileSchema,
  type UpdateUserProfileInput,
  userProfileRowSchema,
  createUserAddressSchema,
  type CreateUserAddressInput,
  updateUserAddressSchema,
  type UpdateUserAddressInput,
  userAddressRowSchema,
} from "./users";

// ── Listings (Marketplace) ─────────────────────────────────
export {
  LISTING_TYPES,
  LISTING_TYPE_LABELS,
  type ListingType,
  LISTING_STATUSES,
  LISTING_STATUS_LABELS,
  type ListingStatus,
  type ListingRow,
  createListingSchema,
  type CreateListingInput,
  updateListingSchema,
  type UpdateListingInput,
  listingRowSchema,
  listingFilterSchema,
  type ListingFilter,
} from "./listings";

// ── Auctions & Bids (Marketplace) ──────────────────────────
export {
  AUCTION_STATUSES,
  AUCTION_STATUS_LABELS,
  type AuctionStatus,
  type AuctionRow,
  type BidRow,
  createAuctionSchema,
  type CreateAuctionInput,
  updateAuctionSchema,
  type UpdateAuctionInput,
  auctionRowSchema,
  bidRowSchema,
  placeBidSchema,
  type PlaceBidInput,
  auctionFilterSchema,
  type AuctionFilter,
} from "./auctions";

// ── Orders (Marketplace) ───────────────────────────────────
export {
  ORDER_STATUSES,
  ORDER_STATUS_LABELS,
  ORDER_TRANSITIONS,
  type OrderStatus,
  type OrderRow,
  type OrderItemRow,
  type OrderItemInput,
  createOrderSchema,
  type CreateOrderInput,
  updateOrderStatusSchema,
  type UpdateOrderStatusInput,
  orderRowSchema,
  orderItemRowSchema,
  orderFilterSchema,
  type OrderFilter,
} from "./orders";
