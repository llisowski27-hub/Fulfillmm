// ============================================================
// THE LIQUIDATOR — Listings Module
// src/types/listings.ts
// ============================================================
// Single source of truth: TS interface + Zod schemas
// Mirrors: SQL migration 003 → tabela `listings`
// ============================================================

import { z } from "zod";

// ────────────────────────────────────────────────────────────
// 1. ENUMY
// ────────────────────────────────────────────────────────────

export const LISTING_TYPES = ["buy_now", "auction"] as const;
export type ListingType = (typeof LISTING_TYPES)[number];

export const LISTING_TYPE_LABELS: Record<ListingType, string> = {
  buy_now: "Kup teraz",
  auction: "Aukcja",
};

export const LISTING_STATUSES = ["draft", "active", "sold", "cancelled"] as const;
export type ListingStatus = (typeof LISTING_STATUSES)[number];

export const LISTING_STATUS_LABELS: Record<ListingStatus, string> = {
  draft: "Szkic",
  active: "Aktywna",
  sold: "Sprzedana",
  cancelled: "Anulowana",
};

// ────────────────────────────────────────────────────────────
// 2. INTERFEJS TYPESCRIPT — pełny wiersz z bazy
// ────────────────────────────────────────────────────────────

export interface ListingRow {
  id: string;
  inventory_item_id: string;
  listing_type: ListingType;
  status: ListingStatus;
  title: string;
  description: string | null;
  images: string[];
  buy_now_price: number | null;
  quantity_available: number;
  is_active: boolean;
  is_featured: boolean;
  slug: string | null;
  category: string | null;
  tags: string[];
  published_at: string | null;
  created_at: string;
  updated_at: string;
}

// ────────────────────────────────────────────────────────────
// 3. HELPERY — reużywalne pola Zod
// ────────────────────────────────────────────────────────────

const slugField = z
  .string()
  .trim()
  .max(200, "Slug max 200 znaków")
  .regex(
    /^[a-z0-9]+(?:-[a-z0-9]+)*$/,
    "Slug: małe litery, cyfry, myślniki (np. nike-air-force-1-42)"
  )
  .nullable()
  .default(null);

const categoryField = z
  .string()
  .trim()
  .max(100, "Kategoria max 100 znaków")
  .nullable()
  .default(null);

const tagsField = z
  .array(z.string().trim().max(50, "Tag max 50 znaków"))
  .max(20, "Maksymalnie 20 tagów")
  .default([]);

const imagesField = z
  .array(z.string().url("Nieprawidłowy URL obrazka"))
  .max(10, "Maksymalnie 10 zdjęć")
  .default([]);

// ────────────────────────────────────────────────────────────
// 4. ZOD — schema BUY_NOW (wymaga ceny)
// ────────────────────────────────────────────────────────────

const buyNowBaseSchema = z.object({
  listing_type: z.literal("buy_now"),
  inventory_item_id: z.string().uuid("Nieprawidłowy identyfikator przedmiotu"),

  title: z.string().trim().min(1, "Tytuł jest wymagany").max(300, "Tytuł max 300 znaków"),
  description: z.string().trim().max(5000, "Opis max 5000 znaków").nullable().default(null),
  images: imagesField,

  buy_now_price: z.number().min(0.01, "Cena musi być większa niż 0"),

  quantity_available: z.number().int().min(1, "Ilość min 1").default(1),
  is_featured: z.boolean().default(false),

  slug: slugField,
  category: categoryField,
  tags: tagsField,
});

// ────────────────────────────────────────────────────────────
// 5. ZOD — schema AUCTION (cena buy_now opcjonalna)
// ────────────────────────────────────────────────────────────

const auctionBaseSchema = z.object({
  listing_type: z.literal("auction"),
  inventory_item_id: z.string().uuid("Nieprawidłowy identyfikator przedmiotu"),

  title: z.string().trim().min(1, "Tytuł jest wymagany").max(300, "Tytuł max 300 znaków"),
  description: z.string().trim().max(5000, "Opis max 5000 znaków").nullable().default(null),
  images: imagesField,

  // Opcjonalna cena "kup teraz" dla aukcji (buy-it-now)
  buy_now_price: z.number().min(0.01).nullable().default(null),

  quantity_available: z.number().int().min(1).default(1),
  is_featured: z.boolean().default(false),

  slug: slugField,
  category: categoryField,
  tags: tagsField,
});

// ────────────────────────────────────────────────────────────
// 6. ZOD — CREATE (discriminated union)
// ────────────────────────────────────────────────────────────

export const createListingSchema = z.discriminatedUnion("listing_type", [
  buyNowBaseSchema,
  auctionBaseSchema,
]);

export type CreateListingInput = z.infer<typeof createListingSchema>;

// ────────────────────────────────────────────────────────────
// 7. ZOD — UPDATE (partial, ale listing_type wymagany)
// ────────────────────────────────────────────────────────────

export const updateListingSchema = z.discriminatedUnion("listing_type", [
  buyNowBaseSchema.partial({
    inventory_item_id: true,
    title: true,
    description: true,
    images: true,
    quantity_available: true,
    is_featured: true,
    slug: true,
    category: true,
    tags: true,
  }),
  auctionBaseSchema.partial({
    inventory_item_id: true,
    title: true,
    description: true,
    images: true,
    quantity_available: true,
    is_featured: true,
    slug: true,
    category: true,
    tags: true,
  }),
]);

export type UpdateListingInput = z.infer<typeof updateListingSchema>;

// ────────────────────────────────────────────────────────────
// 8. ZOD — ROW (pełny wiersz z bazy, SELECT)
// ────────────────────────────────────────────────────────────

export const listingRowSchema = z.object({
  id: z.string().uuid(),
  inventory_item_id: z.string().uuid(),
  listing_type: z.enum(LISTING_TYPES),
  status: z.enum(LISTING_STATUSES),
  title: z.string(),
  description: z.string().nullable(),
  images: z.array(z.string()),
  buy_now_price: z.number().nullable(),
  quantity_available: z.number(),
  is_active: z.boolean(),
  is_featured: z.boolean(),
  slug: z.string().nullable(),
  category: z.string().nullable(),
  tags: z.array(z.string()),
  published_at: z.string().datetime().nullable(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

// ────────────────────────────────────────────────────────────
// 9. ZOD — FILTR (katalog publiczny)
// ────────────────────────────────────────────────────────────

export const listingFilterSchema = z.object({
  listing_type: z.enum(LISTING_TYPES).optional(),
  category: z.string().optional(),
  min_price: z.number().min(0).optional(),
  max_price: z.number().min(0).optional(),
  search: z.string().max(200).optional(),
  tags: z.array(z.string()).optional(),
  is_featured: z.boolean().optional(),
});

export type ListingFilter = z.infer<typeof listingFilterSchema>;
