// ============================================================
// THE LIQUIDATOR — Clients Module
// src/types/clients.ts
// ============================================================
// Single source of truth: TS interface + Zod schemas
// Mirrors: SQL schema v1.1 → tabela `clients`
// ============================================================

import { z } from "zod";

// ────────────────────────────────────────────────────────────
// 1. ENUMY (reużywalne w całym projekcie)
// ────────────────────────────────────────────────────────────

export const TYP_MODELU = ["fulfillment", "komis"] as const;
export type TypModelu = (typeof TYP_MODELU)[number];

// ────────────────────────────────────────────────────────────
// 2. INTERFEJS TYPESCRIPT — pełny wiersz z bazy
// ────────────────────────────────────────────────────────────

export interface Client {
  id: string;
  nazwa: string;
  email: string | null;
  telefon: string | null;
  typ_modelu: TypModelu;
  stawka_prowizji: number | null;
  stawka_za_paczke: number | null;
  archived_at: string | null;
  created_at: string;
  updated_at: string;
}

// ────────────────────────────────────────────────────────────
// 3. ZOD — schema bazowy (wspólne pola)
// ────────────────────────────────────────────────────────────

const clientBaseSchema = z.object({
  nazwa: z
    .string()
    .min(1, "Nazwa klienta jest wymagana")
    .max(200, "Nazwa max 200 znaków"),

  email: z
    .string()
    .email("Nieprawidłowy adres email")
    .nullable()
    .default(null),

  telefon: z
    .string()
    .max(20, "Telefon max 20 znaków")
    .nullable()
    .default(null),

  typ_modelu: z.enum(TYP_MODELU, {
    errorMap: () => ({ message: "Wybierz model: fulfillment lub komis" }),
  }),
});

// ────────────────────────────────────────────────────────────
// 4. ZOD — schema KOMIS (wymaga stawki prowizji)
// ────────────────────────────────────────────────────────────

const komisSchema = clientBaseSchema.extend({
  typ_modelu: z.literal("komis"),

  stawka_prowizji: z
    .number()
    .min(0, "Prowizja nie może być ujemna")
    .max(1, "Prowizja max 1.0 (100%)"),

  stawka_za_paczke: z.number().min(0).nullable().default(null),
});

// ────────────────────────────────────────────────────────────
// 5. ZOD — schema FULFILLMENT (wymaga stawki za paczkę)
// ────────────────────────────────────────────────────────────

const fulfillmentSchema = clientBaseSchema.extend({
  typ_modelu: z.literal("fulfillment"),

  stawka_prowizji: z.number().min(0).max(1).nullable().default(null),

  stawka_za_paczke: z
    .number()
    .min(0, "Stawka za paczkę nie może być ujemna"),
});

// ────────────────────────────────────────────────────────────
// 6. ZOD — discriminated union (CREATE / UPDATE)
// ────────────────────────────────────────────────────────────

/**
 * Schema do tworzenia klienta.
 * Discriminated union na `typ_modelu` — Zod automatycznie
 * wymusza odpowiednie pola zależnie od modelu biznesowego.
 */
export const createClientSchema = z.discriminatedUnion("typ_modelu", [
  komisSchema,
  fulfillmentSchema,
]);

export type CreateClientInput = z.infer<typeof createClientSchema>;

/**
 * Schema do edycji klienta.
 * Partial na polach bazowych, ale `typ_modelu` wymagany
 * (zmiana modelu = zmiana wymaganych pól).
 */
export const updateClientSchema = z.discriminatedUnion("typ_modelu", [
  komisSchema.partial({ nazwa: true, email: true, telefon: true }),
  fulfillmentSchema.partial({ nazwa: true, email: true, telefon: true }),
]);

export type UpdateClientInput = z.infer<typeof updateClientSchema>;

// ────────────────────────────────────────────────────────────
// 7. ZOD — schema pełnego wiersza (SELECT z bazy)
// ────────────────────────────────────────────────────────────

export const clientRowSchema = clientBaseSchema.extend({
  id: z.string().uuid(),
  stawka_prowizji: z.number().nullable(),
  stawka_za_paczke: z.number().nullable(),
  archived_at: z.string().datetime().nullable(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

export type ClientRow = z.infer<typeof clientRowSchema>;
