// ============================================================
// THE LIQUIDATOR — Warehouse Logs Module
// src/types/warehouse-logs.ts
// ============================================================
// Single source of truth: TS interface + Zod schemas
// Mirrors: SQL schema v1.1 → tabela `warehouse_logs`
// ============================================================

import { z } from "zod";

// ────────────────────────────────────────────────────────────
// 1. ENUM
// ────────────────────────────────────────────────────────────

export const TYP_AKCJI = ["PRZYJECIE", "WYDANIE", "ZWROT", "KOREKTA"] as const;
export type TypAkcji = (typeof TYP_AKCJI)[number];

// ────────────────────────────────────────────────────────────
// 2. INTERFEJS TYPESCRIPT — pełny wiersz z bazy
// ────────────────────────────────────────────────────────────

export interface WarehouseLog {
  id: string;
  item_id: string;
  typ_akcji: TypAkcji;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

// ────────────────────────────────────────────────────────────
// 3. ZOD — CREATE (nowy wpis w logu)
// ────────────────────────────────────────────────────────────

export const createWarehouseLogSchema = z.object({
  item_id: z.string().uuid("Nieprawidłowy identyfikator przedmiotu"),

  typ_akcji: z.enum(TYP_AKCJI, {
    errorMap: () => ({
      message: "Wybierz typ akcji: PRZYJECIE, WYDANIE, ZWROT lub KOREKTA",
    }),
  }),

  notes: z
    .string()
    .trim()
    .max(500, "Notatka max 500 znaków")
    .nullable()
    .default(null),
});

export type CreateWarehouseLogInput = z.infer<
  typeof createWarehouseLogSchema
>;

// ────────────────────────────────────────────────────────────
// 4. ZOD — UPDATE (edycja istniejącego wpisu)
//    Tylko notes jest edytowalne — typ_akcji i item_id
//    są niezmienne po utworzeniu (log = fakt historyczny).
// ────────────────────────────────────────────────────────────

export const updateWarehouseLogSchema = z.object({
  notes: z
    .string()
    .trim()
    .max(500, "Notatka max 500 znaków")
    .nullable(),
});

export type UpdateWarehouseLogInput = z.infer<
  typeof updateWarehouseLogSchema
>;

// ────────────────────────────────────────────────────────────
// 5. ZOD — ROW (pełny wiersz z bazy, SELECT)
// ────────────────────────────────────────────────────────────

export const warehouseLogRowSchema = z.object({
  id: z.string().uuid(),
  item_id: z.string().uuid(),
  typ_akcji: z.enum(TYP_AKCJI),
  notes: z.string().nullable(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

export type WarehouseLogRow = z.infer<typeof warehouseLogRowSchema>;

// ────────────────────────────────────────────────────────────
// 6. ZOD — FILTR (query params do listowania logów)
// ────────────────────────────────────────────────────────────

export const warehouseLogFilterSchema = z.object({
  item_id: z.string().uuid().optional(),
  typ_akcji: z.enum(TYP_AKCJI).optional(),
  from: z.string().datetime().optional(),
  to: z.string().datetime().optional(),
});

export type WarehouseLogFilter = z.infer<typeof warehouseLogFilterSchema>;
