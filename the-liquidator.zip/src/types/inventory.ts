// ============================================================
// THE LIQUIDATOR — Inventory Items Module
// src/types/inventory.ts
// ============================================================
// Single source of truth: TS interface + Zod schemas
// Mirrors: SQL schema v1.1 → tabela `inventory_items`
// ============================================================

import { z } from "zod";

// ────────────────────────────────────────────────────────────
// 1. ENUMY
// ────────────────────────────────────────────────────────────

export const STAN_ITEMS = [
  "nowy",
  "powystawowy",
  "używany",
  "uszkodzony",
  "po_zwrocie",
  "nowy_z_defektem",
  "niepelny_komplet",
  "odnowiony",
] as const;
export type Stan = (typeof STAN_ITEMS)[number];

/** Mapowanie wartości enum → etykiety UI (single source of truth) */
export const STAN_LABELS: Record<Stan, string> = {
  nowy: "Nowy",
  powystawowy: "Powystawowy",
  używany: "Używany",
  uszkodzony: "Uszkodzony",
  po_zwrocie: "Po zwrocie",
  nowy_z_defektem: "Nowy z defektem",
  niepelny_komplet: "Niepełny komplet",
  odnowiony: "Odnowiony",
};

export const STATUS_ITEMS = ["w_magazynie", "sprzedane", "zwrocone", "wycofane"] as const;
export type Status = (typeof STATUS_ITEMS)[number];

// ────────────────────────────────────────────────────────────
// 2. INTERFEJS TYPESCRIPT — pełny wiersz z bazy
// ────────────────────────────────────────────────────────────

export interface InventoryItem {
  id: string;
  sku: string;
  nazwa: string;
  opis: string | null;
  stan: Stan;
  status: Status;
  lokalizacja_kod: string;
  cena_zakupu: number;
  cena_docelowa: number;
  client_id: string;
  last_audited_at: string | null;
  checked_by: string | null;
  created_at: string;
  updated_at: string;
}

// ────────────────────────────────────────────────────────────
// 3. HELPERY — reużywalne pola Zod
// ────────────────────────────────────────────────────────────

const skuField = z
  .string()
  .trim()
  .min(1, "SKU jest wymagane")
  .max(50, "SKU max 50 znaków")
  .regex(
    /^[A-Z0-9\-_]+$/,
    "SKU: tylko wielkie litery, cyfry, myślnik, podkreślnik"
  );

const lokalizacjaField = z
  .string()
  .trim()
  .min(1, "Kod lokalizacji jest wymagany")
  .max(20, "Lokalizacja max 20 znaków")
  .regex(
    /^[A-Z0-9\-]+$/,
    "Lokalizacja: tylko wielkie litery, cyfry, myślnik (np. A-01-03)"
  );

const cenaZakupuField = z
  .number()
  .min(0, "Cena zakupu nie może być ujemna");

// ────────────────────────────────────────────────────────────
// 4. ZOD — CREATE (przyjęcie nowego przedmiotu)
// ────────────────────────────────────────────────────────────

export const createInventoryItemSchema = z
  .object({
    sku: skuField,
    nazwa: z
      .string()
      .trim()
      .min(1, "Nazwa przedmiotu jest wymagana")
      .max(300, "Nazwa max 300 znaków"),

    opis: z.string().trim().max(1000, "Opis max 1000 znaków").nullable().default(null),

    stan: z.enum(STAN_ITEMS, {
      errorMap: () => ({ message: "Wybierz stan: nowy lub używany" }),
    }),

    status: z
      .enum(STATUS_ITEMS, {
        errorMap: () => ({
          message: "Wybierz status: w_magazynie, sprzedane lub zwrocone",
        }),
      })
      .default("w_magazynie"),

    lokalizacja_kod: lokalizacjaField,

    cena_zakupu: cenaZakupuField,

    cena_docelowa: z.number().min(0, "Cena docelowa nie może być ujemna"),

    client_id: z.string().uuid("Nieprawidłowy identyfikator klienta"),

    // Pola audytowe — opcjonalne przy tworzeniu
    last_audited_at: z.string().datetime().nullable().default(null),
    checked_by: z.string().max(100).nullable().default(null),
  })
  .refine((data) => data.cena_docelowa >= data.cena_zakupu, {
    message: "Cena docelowa nie może być niższa niż cena zakupu",
    path: ["cena_docelowa"],
  });

export type CreateInventoryItemInput = z.infer<
  typeof createInventoryItemSchema
>;

// ────────────────────────────────────────────────────────────
// 5. ZOD — UPDATE (częściowa edycja)
// ────────────────────────────────────────────────────────────

export const updateInventoryItemSchema = z
  .object({
    nazwa: z.string().trim().min(1).max(300).optional(),
    opis: z.string().trim().max(1000).nullable().optional(),
    stan: z.enum(STAN_ITEMS).optional(),
    status: z.enum(STATUS_ITEMS).optional(),
    lokalizacja_kod: lokalizacjaField.optional(),
    cena_zakupu: cenaZakupuField.optional(),
    cena_docelowa: z.number().min(0).optional(),
    last_audited_at: z.string().datetime().nullable().optional(),
    checked_by: z.string().max(100).nullable().optional(),
  })
  .refine(
    (data) => {
      // Walidacja cross-field tylko gdy oba pola obecne
      if (
        data.cena_docelowa !== undefined &&
        data.cena_zakupu !== undefined
      ) {
        return data.cena_docelowa >= data.cena_zakupu;
      }
      return true;
    },
    {
      message: "Cena docelowa nie może być niższa niż cena zakupu",
      path: ["cena_docelowa"],
    }
  );

export type UpdateInventoryItemInput = z.infer<
  typeof updateInventoryItemSchema
>;

// ────────────────────────────────────────────────────────────
// 6. ZOD — ROW (pełny wiersz z bazy, SELECT)
// ────────────────────────────────────────────────────────────

export const inventoryItemRowSchema = z.object({
  id: z.string().uuid(),
  sku: skuField,
  nazwa: z.string(),
  opis: z.string().nullable(),
  stan: z.enum(STAN_ITEMS),
  status: z.enum(STATUS_ITEMS),
  lokalizacja_kod: lokalizacjaField,
  cena_zakupu: z.number(),
  cena_docelowa: z.number(),
  client_id: z.string().uuid(),
  last_audited_at: z.string().datetime().nullable(),
  checked_by: z.string().nullable(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

export type InventoryItemRow = z.infer<typeof inventoryItemRowSchema>;

// ────────────────────────────────────────────────────────────
// 7. HELPER — audyt ręczny (osobny schema do Server Action)
// ────────────────────────────────────────────────────────────

export const markAuditedSchema = z.object({
  item_id: z.string().uuid("Nieprawidłowy identyfikator przedmiotu"),
  checked_by: z
    .string()
    .min(1, "Podaj kto przeprowadził kontrolę")
    .max(100, "Imię max 100 znaków"),
});

export type MarkAuditedInput = z.infer<typeof markAuditedSchema>;
