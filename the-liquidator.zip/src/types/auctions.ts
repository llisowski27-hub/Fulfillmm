// ============================================================
// THE LIQUIDATOR — Auctions & Bids Module
// src/types/auctions.ts
// ============================================================
// Single source of truth: TS interface + Zod schemas
// Mirrors: SQL migration 003 → tabele `auctions`, `bids`
// ============================================================

import { z } from "zod";

// ────────────────────────────────────────────────────────────
// 1. ENUMY
// ────────────────────────────────────────────────────────────

export const AUCTION_STATUSES = ["scheduled", "active", "ended", "cancelled"] as const;
export type AuctionStatus = (typeof AUCTION_STATUSES)[number];

export const AUCTION_STATUS_LABELS: Record<AuctionStatus, string> = {
  scheduled: "Zaplanowana",
  active: "Trwa",
  ended: "Zakończona",
  cancelled: "Anulowana",
};

// ────────────────────────────────────────────────────────────
// 2. INTERFEJSY TYPESCRIPT
// ────────────────────────────────────────────────────────────

export interface AuctionRow {
  id: string;
  listing_id: string;
  status: AuctionStatus;
  start_time: string;
  end_time: string;
  starting_price: number;
  reserve_price: number | null;
  min_bid_increment: number;
  current_price: number | null;
  winning_bid_id: string | null;
  bid_count: number;
  extend_count: number;
  max_extends: number;
  created_at: string;
  updated_at: string;
}

export interface BidRow {
  id: string;
  auction_id: string;
  user_id: string;
  amount: number;
  is_winning: boolean;
  created_at: string;
}

// ────────────────────────────────────────────────────────────
// 3. ZOD — CREATE AUCTION
// ────────────────────────────────────────────────────────────

export const createAuctionSchema = z
  .object({
    listing_id: z.string().uuid("Nieprawidłowy identyfikator oferty"),

    start_time: z.string().datetime("Nieprawidłowy format daty startu"),
    end_time: z.string().datetime("Nieprawidłowy format daty końca"),

    starting_price: z
      .number()
      .min(0.01, "Cena wywoławcza musi być większa niż 0"),

    reserve_price: z
      .number()
      .min(0.01, "Cena minimalna musi być większa niż 0")
      .nullable()
      .default(null),

    min_bid_increment: z
      .number()
      .min(0.01, "Krok licytacji musi być większy niż 0")
      .default(1.00),
  })
  .refine((data) => new Date(data.start_time) < new Date(data.end_time), {
    message: "Data startu musi być wcześniejsza niż data końca",
    path: ["end_time"],
  })
  .refine(
    (data) => {
      if (data.reserve_price === null) return true;
      return data.reserve_price >= data.starting_price;
    },
    {
      message: "Cena minimalna nie może być niższa niż cena wywoławcza",
      path: ["reserve_price"],
    }
  );

export type CreateAuctionInput = z.infer<typeof createAuctionSchema>;

// ────────────────────────────────────────────────────────────
// 4. ZOD — UPDATE AUCTION
//    Przed startem: można zmienić czasy i ceny.
//    W trakcie: tylko end_time (przedłużenie).
//    Po zakończeniu: nic.
//    Logikę tranzycji wymusza Server Action, nie Zod.
// ────────────────────────────────────────────────────────────

export const updateAuctionSchema = z
  .object({
    start_time: z.string().datetime().optional(),
    end_time: z.string().datetime().optional(),
    starting_price: z.number().min(0.01).optional(),
    reserve_price: z.number().min(0.01).nullable().optional(),
    min_bid_increment: z.number().min(0.01).optional(),
  })
  .refine(
    (data) => {
      if (data.start_time && data.end_time) {
        return new Date(data.start_time) < new Date(data.end_time);
      }
      return true;
    },
    {
      message: "Data startu musi być wcześniejsza niż data końca",
      path: ["end_time"],
    }
  )
  .refine(
    (data) => {
      if (
        data.reserve_price !== undefined &&
        data.reserve_price !== null &&
        data.starting_price !== undefined
      ) {
        return data.reserve_price >= data.starting_price;
      }
      return true;
    },
    {
      message: "Cena minimalna nie może być niższa niż cena wywoławcza",
      path: ["reserve_price"],
    }
  );

export type UpdateAuctionInput = z.infer<typeof updateAuctionSchema>;

// ────────────────────────────────────────────────────────────
// 5. ZOD — ROW SCHEMAS (SELECT z bazy)
// ────────────────────────────────────────────────────────────

export const auctionRowSchema = z.object({
  id: z.string().uuid(),
  listing_id: z.string().uuid(),
  status: z.enum(AUCTION_STATUSES),
  start_time: z.string().datetime(),
  end_time: z.string().datetime(),
  starting_price: z.number(),
  reserve_price: z.number().nullable(),
  min_bid_increment: z.number(),
  current_price: z.number().nullable(),
  winning_bid_id: z.string().uuid().nullable(),
  bid_count: z.number(),
  extend_count: z.number(),
  max_extends: z.number(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

export const bidRowSchema = z.object({
  id: z.string().uuid(),
  auction_id: z.string().uuid(),
  user_id: z.string().uuid(),
  amount: z.number(),
  is_winning: z.boolean(),
  created_at: z.string().datetime(),
});

// ────────────────────────────────────────────────────────────
// 6. ZOD — PLACE BID (kupujący składa ofertę)
// ────────────────────────────────────────────────────────────

export const placeBidSchema = z.object({
  auction_id: z.string().uuid("Nieprawidłowy identyfikator aukcji"),
  amount: z
    .number()
    .min(0.01, "Kwota licytacji musi być większa niż 0"),
});

export type PlaceBidInput = z.infer<typeof placeBidSchema>;

// ────────────────────────────────────────────────────────────
// 7. ZOD — FILTR AUKCJI
// ────────────────────────────────────────────────────────────

export const auctionFilterSchema = z.object({
  status: z.enum(AUCTION_STATUSES).optional(),
  ending_before: z.string().datetime().optional(),
  ending_after: z.string().datetime().optional(),
  min_price: z.number().min(0).optional(),
  max_price: z.number().min(0).optional(),
});

export type AuctionFilter = z.infer<typeof auctionFilterSchema>;
