// ============================================================
// THE LIQUIDATOR — Orders Module
// src/types/orders.ts
// ============================================================
// Single source of truth: TS interface + Zod schemas
// Mirrors: SQL migration 003 → tabele `orders`, `order_items`
// ============================================================

import { z } from "zod";
import { LISTING_TYPES, type ListingType } from "./listings";

// ────────────────────────────────────────────────────────────
// 1. ENUMY
// ────────────────────────────────────────────────────────────

export const ORDER_STATUSES = [
  "pending",
  "paid",
  "shipped",
  "completed",
  "cancelled",
] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  pending: "Oczekujące",
  paid: "Opłacone",
  shipped: "Wysłane",
  completed: "Zrealizowane",
  cancelled: "Anulowane",
};

// Dozwolone tranzycje statusu zamówienia
export const ORDER_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  pending: ["paid", "cancelled"],
  paid: ["shipped", "cancelled"],
  shipped: ["completed"],
  completed: [],
  cancelled: [],
};

// ────────────────────────────────────────────────────────────
// 2. INTERFEJSY TYPESCRIPT
// ────────────────────────────────────────────────────────────

export interface OrderRow {
  id: string;
  user_id: string;
  status: OrderStatus;
  shipping_name: string;
  shipping_street: string;
  shipping_city: string;
  shipping_postal: string;
  shipping_country: string;
  shipping_phone: string | null;
  subtotal: number;
  shipping_cost: number;
  total: number;
  notes: string | null;
  payment_method: string | null;
  payment_id: string | null;
  paid_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface OrderItemRow {
  id: string;
  order_id: string;
  listing_id: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  source_type: ListingType;
  bid_id: string | null;
  created_at: string;
}

// ────────────────────────────────────────────────────────────
// 3. HELPERY — adres dostawy (snapshot)
// ────────────────────────────────────────────────────────────

const shippingSchema = z.object({
  shipping_name: z.string().trim().min(1, "Imię i nazwisko wymagane").max(200),
  shipping_street: z.string().trim().min(1, "Ulica wymagana").max(300),
  shipping_city: z.string().trim().min(1, "Miasto wymagane").max(100),
  shipping_postal: z
    .string()
    .trim()
    .min(1, "Kod pocztowy wymagany")
    .regex(/^\d{2}-\d{3}$/, "Format: 00-000"),
  shipping_country: z.string().trim().default("PL"),
  shipping_phone: z.string().trim().max(20).nullable().default(null),
});

// ────────────────────────────────────────────────────────────
// 4. ZOD — CREATE ORDER (checkout)
// ────────────────────────────────────────────────────────────

const orderItemInputSchema = z.object({
  listing_id: z.string().uuid("Nieprawidłowy identyfikator oferty"),
  quantity: z.number().int().min(1, "Ilość min 1"),
  unit_price: z.number().min(0, "Cena nie może być ujemna"),
  source_type: z.enum(LISTING_TYPES),
  bid_id: z.string().uuid().nullable().default(null),
});

export type OrderItemInput = z.infer<typeof orderItemInputSchema>;

export const createOrderSchema = shippingSchema.extend({
  items: z
    .array(orderItemInputSchema)
    .min(1, "Zamówienie musi zawierać przynajmniej jedną pozycję"),
  notes: z
    .string()
    .trim()
    .max(500, "Notatka max 500 znaków")
    .nullable()
    .default(null),
});

export type CreateOrderInput = z.infer<typeof createOrderSchema>;

// ────────────────────────────────────────────────────────────
// 5. ZOD — UPDATE ORDER STATUS
//    Tranzycje wymuszane w Server Action (ORDER_TRANSITIONS).
// ────────────────────────────────────────────────────────────

export const updateOrderStatusSchema = z.object({
  status: z.enum(ORDER_STATUSES, {
    errorMap: () => ({ message: "Nieprawidłowy status zamówienia" }),
  }),
});

export type UpdateOrderStatusInput = z.infer<typeof updateOrderStatusSchema>;

// ────────────────────────────────────────────────────────────
// 6. ZOD — ROW SCHEMAS (SELECT z bazy)
// ────────────────────────────────────────────────────────────

export const orderRowSchema = z.object({
  id: z.string().uuid(),
  user_id: z.string().uuid(),
  status: z.enum(ORDER_STATUSES),
  shipping_name: z.string(),
  shipping_street: z.string(),
  shipping_city: z.string(),
  shipping_postal: z.string(),
  shipping_country: z.string(),
  shipping_phone: z.string().nullable(),
  subtotal: z.number(),
  shipping_cost: z.number(),
  total: z.number(),
  notes: z.string().nullable(),
  payment_method: z.string().nullable(),
  payment_id: z.string().nullable(),
  paid_at: z.string().datetime().nullable(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

export const orderItemRowSchema = z.object({
  id: z.string().uuid(),
  order_id: z.string().uuid(),
  listing_id: z.string().uuid(),
  quantity: z.number(),
  unit_price: z.number(),
  total_price: z.number(),
  source_type: z.enum(LISTING_TYPES),
  bid_id: z.string().uuid().nullable(),
  created_at: z.string().datetime(),
});

// ────────────────────────────────────────────────────────────
// 7. ZOD — FILTR ZAMÓWIEŃ
// ────────────────────────────────────────────────────────────

export const orderFilterSchema = z.object({
  status: z.enum(ORDER_STATUSES).optional(),
  user_id: z.string().uuid().optional(),
  from: z.string().datetime().optional(),
  to: z.string().datetime().optional(),
});

export type OrderFilter = z.infer<typeof orderFilterSchema>;
