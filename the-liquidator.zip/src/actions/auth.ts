// ============================================================
// THE LIQUIDATOR — Auth Server Actions
// src/actions/auth.ts
// ============================================================
// Email + password auth. Bez OAuth, bez reset hasła.
// ============================================================

"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";

// ────────────────────────────────────────────────────────────
// Schemas
// ────────────────────────────────────────────────────────────

const loginSchema = z.object({
  email: z.string().email("Nieprawidłowy email"),
  password: z.string().min(6, "Hasło min 6 znaków"),
});

const registerSchema = loginSchema.extend({
  display_name: z
    .string()
    .trim()
    .min(1, "Nazwa wymagana")
    .max(100, "Nazwa max 100 znaków"),
});

type AuthResult =
  | { success: true }
  | { success: false; error: string };

// ────────────────────────────────────────────────────────────
// REGISTER
// ────────────────────────────────────────────────────────────

export async function registerAction(
  input: z.infer<typeof registerSchema>
): Promise<AuthResult> {
  try {
    const parsed = registerSchema.parse(input);
    const supabase = await createClient();

    const { data, error } = await supabase.auth.signUp({
      email: parsed.email,
      password: parsed.password,
      options: {
        data: { display_name: parsed.display_name },
      },
    });

    if (error) throw new Error(error.message);

    // Utwórz profil użytkownika
    if (data.user) {
      await supabase.from("user_profiles").insert({
        id: data.user.id,
        display_name: parsed.display_name,
      });
    }

    revalidatePath("/", "layout");
    return { success: true };
  } catch (err) {
    const message =
      err instanceof Error ? err.message : "Błąd rejestracji";
    return { success: false, error: message };
  }
}

// ────────────────────────────────────────────────────────────
// LOGIN
// ────────────────────────────────────────────────────────────

export async function loginAction(
  input: z.infer<typeof loginSchema>
): Promise<AuthResult> {
  try {
    const parsed = loginSchema.parse(input);
    const supabase = await createClient();

    const { error } = await supabase.auth.signInWithPassword({
      email: parsed.email,
      password: parsed.password,
    });

    if (error) throw new Error(error.message);

    revalidatePath("/", "layout");
    return { success: true };
  } catch (err) {
    const message =
      err instanceof Error ? err.message : "Błąd logowania";
    return { success: false, error: message };
  }
}

// ────────────────────────────────────────────────────────────
// LOGOUT
// ────────────────────────────────────────────────────────────

export async function logoutAction(): Promise<void> {
  const supabase = await createClient();
  await supabase.auth.signOut();
  revalidatePath("/", "layout");
  redirect("/");
}
