// ============================================================
// THE LIQUIDATOR — Inventory Items Server Actions v2
// src/actions/inventory.ts
// ============================================================
// CHANGELOG v2:
//   [1] Soft delete zamiast hard delete (status → 'wycofane')
//   [2] Race condition usunięty — walidacja cen przez DB CHECK,
//       nie przez SELECT + UPDATE
//   [3] Boilerplate zredukowany przez withAction helper
// ============================================================

"use server";

import { revalidatePath } from "next/cache";
import { withAction } from "./_helpers";
import {
  createInventoryItemSchema,
  updateInventoryItemSchema,
  inventoryItemRowSchema,
  markAuditedSchema,
  type CreateInventoryItemInput,
  type UpdateInventoryItemInput,
  type MarkAuditedInput,
} from "@/types";

// ────────────────────────────────────────────────────────────
// Supabase error → czytelny komunikat kontekstowy
// ────────────────────────────────────────────────────────────

function throwOnError(error: { code?: string; message: string }) {
  if (error.code === "23505") {
    throw new Error(
      "Ta lokalizacja jest już zajęta dla tego klienta"
    );
  }
  if (error.code === "23514") {
    throw new Error(
      "Cena docelowa nie może być niższa niż cena zakupu"
    );
  }
  throw new Error(error.message);
}

// ────────────────────────────────────────────────────────────
// CREATE — przyjęcie nowego przedmiotu do magazynu
// ────────────────────────────────────────────────────────────

export const createInventoryItemAction = withAction(
  "inventory:create",
  async (supabase, input: CreateInventoryItemInput) => {
    const parsed = createInventoryItemSchema.parse(input);

    const { data, error } = await supabase
      .from("inventory_items")
      .insert(parsed)
      .select()
      .single();

    if (error) throwOnError(error);

    revalidatePath("/inventory");
    return inventoryItemRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// READ — lista przedmiotów (opcjonalnie filtrowana)
// ────────────────────────────────────────────────────────────

interface InventoryFilters {
  client_id?: string;
  status?: string;
  lokalizacja_kod?: string;
}

export const getInventoryItemsAction = withAction(
  "inventory:list",
  async (supabase, filters?: InventoryFilters) => {
    let query = supabase
      .from("inventory_items")
      .select("*")
      .order("created_at", { ascending: false });

    if (filters?.client_id) {
      query = query.eq("client_id", filters.client_id);
    }
    if (filters?.status) {
      query = query.eq("status", filters.status);
    }
    if (filters?.lokalizacja_kod) {
      query = query.eq("lokalizacja_kod", filters.lokalizacja_kod);
    }

    const { data, error } = await query;
    if (error) throw new Error(error.message);

    return data.map((row) => inventoryItemRowSchema.parse(row));
  }
);

// ────────────────────────────────────────────────────────────
// READ — pojedynczy przedmiot po ID
// ────────────────────────────────────────────────────────────

export const getInventoryItemByIdAction = withAction(
  "inventory:get",
  async (supabase, id: string) => {
    const { data, error } = await supabase
      .from("inventory_items")
      .select("*")
      .eq("id", id)
      .single();

    if (error) throw new Error(error.message);
    return inventoryItemRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// READ — wyszukanie po SKU
// ────────────────────────────────────────────────────────────

export const getInventoryItemBySkuAction = withAction(
  "inventory:sku",
  async (supabase, sku: string) => {
    const { data, error } = await supabase
      .from("inventory_items")
      .select("*")
      .eq("sku", sku.trim().toUpperCase())
      .single();

    if (error) throw new Error(error.message);
    return inventoryItemRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// UPDATE — edycja przedmiotu
// [v2] Brak SELECT przed UPDATE. Walidacja cen przez
//      CHECK constraint w SQL (chk_cena_docelowa).
//      Jeśli baza odrzuci — łapiemy kod 23514.
// ────────────────────────────────────────────────────────────

export const updateInventoryItemAction = withAction(
  "inventory:update",
  async (supabase, id: string, input: UpdateInventoryItemInput) => {
    const parsed = updateInventoryItemSchema.parse(input);

    const { data, error } = await supabase
      .from("inventory_items")
      .update(parsed)
      .eq("id", id)
      .select()
      .single();

    if (error) throwOnError(error);

    revalidatePath("/inventory");
    revalidatePath(`/inventory/${id}`);
    return inventoryItemRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// SOFT DELETE — wycofanie przedmiotu
// [v2] Zmiana statusu zamiast fizycznego usunięcia.
//      Historia logów i dane rozliczeniowe zostają nienaruszone.
// ────────────────────────────────────────────────────────────

export const archiveInventoryItemAction = withAction(
  "inventory:archive",
  async (supabase, id: string) => {
    const { data, error } = await supabase
      .from("inventory_items")
      .update({ status: "wycofane" as const })
      .eq("id", id)
      .select()
      .single();

    if (error) throw new Error(error.message);

    revalidatePath("/inventory");
    return inventoryItemRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// AUDYT — oznacz przedmiot jako skontrolowany
// ────────────────────────────────────────────────────────────

export const markItemAuditedAction = withAction(
  "inventory:audit",
  async (supabase, input: MarkAuditedInput) => {
    const parsed = markAuditedSchema.parse(input);

    const { data, error } = await supabase
      .from("inventory_items")
      .update({
        last_audited_at: new Date().toISOString(),
        checked_by: parsed.checked_by,
      })
      .eq("id", parsed.item_id)
      .select()
      .single();

    if (error) throw new Error(error.message);

    revalidatePath("/inventory");
    return inventoryItemRowSchema.parse(data);
  }
);
