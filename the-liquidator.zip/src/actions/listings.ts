// ============================================================
// THE LIQUIDATOR — Listings Server Actions
// src/actions/listings.ts
// ============================================================

"use server";

import { revalidatePath } from "next/cache";
import { withAction } from "./_helpers";
import {
  createListingSchema,
  updateListingSchema,
  listingRowSchema,
  listingFilterSchema,
  type CreateListingInput,
  type UpdateListingInput,
  type ListingFilter,
} from "@/types";

// ────────────────────────────────────────────────────────────
// Kontekstowe błędy PG
// ────────────────────────────────────────────────────────────

function throwOnError(error: { code?: string; message: string }) {
  if (error.code === "23505") {
    throw new Error(
      "Ten przedmiot ma już aktywną ofertę lub slug jest zajęty"
    );
  }
  if (error.code === "23503") {
    throw new Error("Powiązany przedmiot nie istnieje");
  }
  throw new Error(error.message);
}

// ────────────────────────────────────────────────────────────
// CREATE
// ────────────────────────────────────────────────────────────

export const createListingAction = withAction(
  "listings:create",
  async (supabase, input: CreateListingInput) => {
    const parsed = createListingSchema.parse(input);

    const { data, error } = await supabase
      .from("listings")
      .insert(parsed)
      .select()
      .single();

    if (error) throwOnError(error);

    revalidatePath("/admin/listings");
    revalidatePath("/catalog");
    return listingRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// READ — katalog publiczny (z filtrami)
// ────────────────────────────────────────────────────────────

export const getListingsAction = withAction(
  "listings:list",
  async (supabase, filters?: ListingFilter) => {
    const parsed = filters
      ? listingFilterSchema.parse(filters)
      : undefined;

    let query = supabase
      .from("listings")
      .select("*")
      .eq("is_active", true)
      .eq("status", "active")
      .order("created_at", { ascending: false });

    if (parsed?.listing_type) {
      query = query.eq("listing_type", parsed.listing_type);
    }
    if (parsed?.category) {
      query = query.eq("category", parsed.category);
    }
    if (parsed?.min_price) {
      query = query.gte("buy_now_price", parsed.min_price);
    }
    if (parsed?.max_price) {
      query = query.lte("buy_now_price", parsed.max_price);
    }
    if (parsed?.search) {
      query = query.ilike("title", `%${parsed.search}%`);
    }
    if (parsed?.is_featured) {
      query = query.eq("is_featured", true);
    }
    if (parsed?.tags && parsed.tags.length > 0) {
      query = query.overlaps("tags", parsed.tags);
    }

    const { data, error } = await query;
    if (error) throw new Error(error.message);

    return data.map((row) => listingRowSchema.parse(row));
  }
);

// ────────────────────────────────────────────────────────────
// READ — admin lista (wszystkie statusy)
// ────────────────────────────────────────────────────────────

export const getAdminListingsAction = withAction(
  "listings:admin-list",
  async (supabase) => {
    const { data, error } = await supabase
      .from("listings")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) throw new Error(error.message);
    return data.map((row) => listingRowSchema.parse(row));
  }
);

// ────────────────────────────────────────────────────────────
// READ — po ID
// ────────────────────────────────────────────────────────────

export const getListingByIdAction = withAction(
  "listings:get",
  async (supabase, id: string) => {
    const { data, error } = await supabase
      .from("listings")
      .select("*")
      .eq("id", id)
      .single();

    if (error) throw new Error(error.message);
    return listingRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// READ — po slug (strona produktu)
// ────────────────────────────────────────────────────────────

export const getListingBySlugAction = withAction(
  "listings:slug",
  async (supabase, slug: string) => {
    const { data, error } = await supabase
      .from("listings")
      .select("*")
      .eq("slug", slug.trim().toLowerCase())
      .single();

    if (error) throw new Error(error.message);
    return listingRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// UPDATE
// ────────────────────────────────────────────────────────────

export const updateListingAction = withAction(
  "listings:update",
  async (supabase, id: string, input: UpdateListingInput) => {
    const parsed = updateListingSchema.parse(input);

    const { data, error } = await supabase
      .from("listings")
      .update(parsed)
      .eq("id", id)
      .select()
      .single();

    if (error) throwOnError(error);

    revalidatePath("/admin/listings");
    revalidatePath("/catalog");
    revalidatePath(`/listing/${id}`);
    return listingRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// PUBLISH — draft → active
// ────────────────────────────────────────────────────────────

export const publishListingAction = withAction(
  "listings:publish",
  async (supabase, id: string) => {
    const { data, error } = await supabase
      .from("listings")
      .update({
        status: "active" as const,
        is_active: true,
        published_at: new Date().toISOString(),
      })
      .eq("id", id)
      .eq("status", "draft")
      .select()
      .single();

    if (error) {
      if (error.code === "PGRST116") {
        throw new Error("Oferta nie istnieje lub nie jest w statusie szkicu");
      }
      throw new Error(error.message);
    }

    revalidatePath("/admin/listings");
    revalidatePath("/catalog");
    return listingRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// CANCEL — soft cancel (nie usuwa)
// ────────────────────────────────────────────────────────────

export const cancelListingAction = withAction(
  "listings:cancel",
  async (supabase, id: string) => {
    const { data, error } = await supabase
      .from("listings")
      .update({
        status: "cancelled" as const,
        is_active: false,
      })
      .eq("id", id)
      .in("status", ["draft", "active"])
      .select()
      .single();

    if (error) {
      if (error.code === "PGRST116") {
        throw new Error("Oferta nie istnieje lub jest już zamknięta");
      }
      throw new Error(error.message);
    }

    revalidatePath("/admin/listings");
    revalidatePath("/catalog");
    return listingRowSchema.parse(data);
  }
);
