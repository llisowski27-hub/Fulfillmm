// ============================================================
// THE LIQUIDATOR — Actions Barrel Export
// src/actions/index.ts
// ============================================================

export {
  createClientAction,
  getClientsAction,
  getClientByIdAction,
  updateClientAction,
  archiveClientAction,
  restoreClientAction,
} from "./clients";

export {
  createInventoryItemAction,
  getInventoryItemsAction,
  getInventoryItemByIdAction,
  getInventoryItemBySkuAction,
  updateInventoryItemAction,
  archiveInventoryItemAction,
  markItemAuditedAction,
} from "./inventory";

export {
  createWarehouseLogAction,
  getWarehouseLogsAction,
  getLogsForItemAction,
  updateWarehouseLogAction,
} from "./warehouse-logs";

export {
  createPayoutAction,
  getPayoutsAction,
  getPayoutsForClientAction,
  getPayoutByIdAction,
  markPayoutPaidAction,
} from "./payouts";

// ── Marketplace: Listings ──────────────────────────────────
export {
  createListingAction,
  getListingsAction,
  getAdminListingsAction,
  getListingByIdAction,
  getListingBySlugAction,
  updateListingAction,
  publishListingAction,
  cancelListingAction,
} from "./listings";

// ── Marketplace: Auctions & Bids ───────────────────────────
export {
  createAuctionAction,
  getAuctionsAction,
  getAuctionByIdAction,
  getAuctionByListingAction,
  updateAuctionAction,
  startAuctionAction,
  endAuctionAction,
  placeBidAction,
  getBidsForAuctionAction,
  getUserBidsAction,
} from "./auctions";

// ── Marketplace: Orders ────────────────────────────────────
export {
  createOrderAction,
  getUserOrdersAction,
  getAdminOrdersAction,
  getOrderWithItemsAction,
  updateOrderStatusAction,
} from "./orders";
