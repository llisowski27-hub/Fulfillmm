// ============================================================
// THE LIQUIDATOR — Payouts Server Actions
// src/actions/payouts.ts
// ============================================================
// CRUD dla wypłat klientów.
// Tranzycja statusu jednokierunkowa: oczekujace → wyplacone.
// Kwota i client_id immutable po utworzeniu.
// ============================================================

"use server";

import { revalidatePath } from "next/cache";
import { withAction } from "./_helpers";
import {
  createPayoutSchema,
  updatePayoutSchema,
  payoutRowSchema,
  payoutFilterSchema,
  type CreatePayoutInput,
  type PayoutFilter,
} from "@/types";

// ────────────────────────────────────────────────────────────
// CREATE — nowa wypłata (status: oczekujace)
// ────────────────────────────────────────────────────────────

export const createPayoutAction = withAction(
  "payouts:create",
  async (supabase, input: CreatePayoutInput) => {
    const parsed = createPayoutSchema.parse(input);

    const { data, error } = await supabase
      .from("payouts")
      .insert(parsed)
      .select()
      .single();

    if (error) {
      if (error.code === "23503") {
        throw new Error("Klient o podanym ID nie istnieje");
      }
      throw new Error(error.message);
    }

    revalidatePath("/payouts");
    return payoutRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// READ — lista wypłat z filtrowaniem
// ────────────────────────────────────────────────────────────

export const getPayoutsAction = withAction(
  "payouts:list",
  async (supabase, filters?: PayoutFilter) => {
    const parsed = filters
      ? payoutFilterSchema.parse(filters)
      : undefined;

    let query = supabase
      .from("payouts")
      .select("*")
      .order("created_at", { ascending: false });

    if (parsed?.client_id) {
      query = query.eq("client_id", parsed.client_id);
    }
    if (parsed?.status) {
      query = query.eq("status", parsed.status);
    }
    if (parsed?.from) {
      query = query.gte("created_at", parsed.from);
    }
    if (parsed?.to) {
      query = query.lte("created_at", parsed.to);
    }

    const { data, error } = await query;
    if (error) throw new Error(error.message);

    return data.map((row) => payoutRowSchema.parse(row));
  }
);

// ────────────────────────────────────────────────────────────
// READ — wypłaty dla konkretnego klienta (shortcut)
// ────────────────────────────────────────────────────────────

export const getPayoutsForClientAction = withAction(
  "payouts:by-client",
  async (supabase, clientId: string) => {
    const { data, error } = await supabase
      .from("payouts")
      .select("*")
      .eq("client_id", clientId)
      .order("created_at", { ascending: false });

    if (error) throw new Error(error.message);
    return data.map((row) => payoutRowSchema.parse(row));
  }
);

// ────────────────────────────────────────────────────────────
// READ — pojedyncza wypłata po ID
// ────────────────────────────────────────────────────────────

export const getPayoutByIdAction = withAction(
  "payouts:get",
  async (supabase, id: string) => {
    const { data, error } = await supabase
      .from("payouts")
      .select("*")
      .eq("id", id)
      .single();

    if (error) throw new Error(error.message);
    return payoutRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// MARK PAID — jedyna dozwolona tranzycja statusu
// oczekujace → wyplacone (jednokierunkowa, nieodwracalna)
// ────────────────────────────────────────────────────────────

export const markPayoutPaidAction = withAction(
  "payouts:pay",
  async (supabase, id: string) => {
    // Zod literal("wyplacone") — jedyna akceptowana wartość
    const parsed = updatePayoutSchema.parse({ status: "wyplacone" });

    // Dodatkowe zabezpieczenie: update tylko jeśli status = oczekujace
    const { data, error } = await supabase
      .from("payouts")
      .update(parsed)
      .eq("id", id)
      .eq("status", "oczekujace")
      .select()
      .single();

    if (error) {
      if (error.code === "PGRST116") {
        throw new Error(
          "Wypłata już została zrealizowana lub nie istnieje"
        );
      }
      throw new Error(error.message);
    }

    revalidatePath("/payouts");
    revalidatePath(`/payouts/${id}`);
    return payoutRowSchema.parse(data);
  }
);
