// ============================================================
// THE LIQUIDATOR — Clients Server Actions v2
// src/actions/clients.ts
// ============================================================
// CHANGELOG v2:
//   [1] withAction helper — zero boilerplate
//   [2] Soft delete (archived_at) zamiast hard delete
//   [3] Spójne mapowanie błędów PG przez _helpers
// ============================================================

"use server";

import { revalidatePath } from "next/cache";
import { withAction } from "./_helpers";
import {
  createClientSchema,
  updateClientSchema,
  clientRowSchema,
  type CreateClientInput,
  type UpdateClientInput,
} from "@/types";

// ────────────────────────────────────────────────────────────
// CREATE
// ────────────────────────────────────────────────────────────

export const createClientAction = withAction(
  "clients:create",
  async (supabase, input: CreateClientInput) => {
    const parsed = createClientSchema.parse(input);

    const { data, error } = await supabase
      .from("clients")
      .insert(parsed)
      .select()
      .single();

    if (error) throw new Error(error.message);

    revalidatePath("/clients");
    return clientRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// READ — lista aktywnych klientów
// ────────────────────────────────────────────────────────────

export const getClientsAction = withAction(
  "clients:list",
  async (supabase) => {
    const { data, error } = await supabase
      .from("clients")
      .select("*")
      .is("archived_at", null)
      .order("created_at", { ascending: false });

    if (error) throw new Error(error.message);
    return data.map((row) => clientRowSchema.parse(row));
  }
);

// ────────────────────────────────────────────────────────────
// READ — pojedynczy klient po ID
// ────────────────────────────────────────────────────────────

export const getClientByIdAction = withAction(
  "clients:get",
  async (supabase, id: string) => {
    const { data, error } = await supabase
      .from("clients")
      .select("*")
      .eq("id", id)
      .single();

    if (error) throw new Error(error.message);
    return clientRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// UPDATE
// ────────────────────────────────────────────────────────────

export const updateClientAction = withAction(
  "clients:update",
  async (supabase, id: string, input: UpdateClientInput) => {
    const parsed = updateClientSchema.parse(input);

    const { data, error } = await supabase
      .from("clients")
      .update(parsed)
      .eq("id", id)
      .select()
      .single();

    if (error) throw new Error(error.message);

    revalidatePath("/clients");
    revalidatePath(`/clients/${id}`);
    return clientRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// SOFT DELETE — archiwizacja klienta
// Ustawia `archived_at` zamiast fizycznego usunięcia.
// FK RESTRICT nadal chroni — klient z itemami nie zniknie.
// ────────────────────────────────────────────────────────────

export const archiveClientAction = withAction(
  "clients:archive",
  async (supabase, id: string) => {
    const { data, error } = await supabase
      .from("clients")
      .update({ archived_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single();

    if (error) throw new Error(error.message);

    revalidatePath("/clients");
    return clientRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// RESTORE — przywrócenie zarchiwizowanego klienta
// ────────────────────────────────────────────────────────────

export const restoreClientAction = withAction(
  "clients:restore",
  async (supabase, id: string) => {
    const { data, error } = await supabase
      .from("clients")
      .update({ archived_at: null })
      .eq("id", id)
      .select()
      .single();

    if (error) throw new Error(error.message);

    revalidatePath("/clients");
    return clientRowSchema.parse(data);
  }
);
