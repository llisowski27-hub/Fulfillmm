// ============================================================
// THE LIQUIDATOR — Orders Server Actions
// src/actions/orders.ts
// ============================================================
// Zamówienia: checkout, historia, tranzycje statusu.
// ============================================================

"use server";

import { revalidatePath } from "next/cache";
import { withAction } from "./_helpers";
import {
  createOrderSchema,
  updateOrderStatusSchema,
  orderRowSchema,
  orderItemRowSchema,
  orderFilterSchema,
  ORDER_TRANSITIONS,
  type CreateOrderInput,
  type UpdateOrderStatusInput,
  type OrderFilter,
  type OrderStatus,
} from "@/types";

// ────────────────────────────────────────────────────────────
// CREATE ORDER (checkout)
//
// Flow:
//   1. Waliduj input (adres + pozycje)
//   2. Weryfikuj dostępność każdego listingu
//   3. Oblicz subtotal / total
//   4. Wstaw order + order_items
//   5. Zmniejsz quantity_available na listingach
// ────────────────────────────────────────────────────────────

export const createOrderAction = withAction(
  "orders:create",
  async (supabase, userId: string, input: CreateOrderInput) => {
    const parsed = createOrderSchema.parse(input);

    // Buduj items JSON dla pg function
    const itemsJson = parsed.items.map((item) => ({
      listing_id: item.listing_id,
      quantity: item.quantity,
      unit_price: item.unit_price,
      source_type: item.source_type,
      bid_id: item.bid_id ?? null,
    }));

    // Atomowa operacja — jedna transakcja w pg:
    // walidacja → lock listingów (posortowanych!) → order → items → dekrementacja
    // Zero okna na deadlock, race condition, czy częściowy checkout.
    const { data: orderId, error } = await supabase.rpc(
      "create_order_atomic",
      {
        p_user_id: userId,
        p_shipping_name: parsed.shipping_name,
        p_shipping_street: parsed.shipping_street,
        p_shipping_city: parsed.shipping_city,
        p_shipping_postal: parsed.shipping_postal,
        p_shipping_country: parsed.shipping_country,
        p_shipping_phone: parsed.shipping_phone,
        p_notes: parsed.notes,
        p_items: JSON.stringify(itemsJson),
      }
    );

    if (error) {
      throw new Error(error.message.replace("ERROR: ", ""));
    }

    // Pobierz pełny order z bazy
    const { data: order, error: oErr } = await supabase
      .from("orders")
      .select("*")
      .eq("id", orderId)
      .single();

    if (oErr) throw new Error(oErr.message);

    revalidatePath("/orders");
    revalidatePath("/catalog");
    return orderRowSchema.parse(order);
  }
);

// ────────────────────────────────────────────────────────────
// READ — zamówienia użytkownika
// ────────────────────────────────────────────────────────────

export const getUserOrdersAction = withAction(
  "orders:user-list",
  async (supabase, userId: string) => {
    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });

    if (error) throw new Error(error.message);
    return data.map((row) => orderRowSchema.parse(row));
  }
);

// ────────────────────────────────────────────────────────────
// READ — wszystkie zamówienia (admin)
// ────────────────────────────────────────────────────────────

export const getAdminOrdersAction = withAction(
  "orders:admin-list",
  async (supabase, filters?: OrderFilter) => {
    const parsed = filters
      ? orderFilterSchema.parse(filters)
      : undefined;

    let query = supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false });

    if (parsed?.status) {
      query = query.eq("status", parsed.status);
    }
    if (parsed?.user_id) {
      query = query.eq("user_id", parsed.user_id);
    }
    if (parsed?.from) {
      query = query.gte("created_at", parsed.from);
    }
    if (parsed?.to) {
      query = query.lte("created_at", parsed.to);
    }

    const { data, error } = await query;
    if (error) throw new Error(error.message);

    return data.map((row) => orderRowSchema.parse(row));
  }
);

// ────────────────────────────────────────────────────────────
// READ — zamówienie po ID z pozycjami
// ────────────────────────────────────────────────────────────

export const getOrderWithItemsAction = withAction(
  "orders:detail",
  async (supabase, orderId: string) => {
    const [orderRes, itemsRes] = await Promise.all([
      supabase.from("orders").select("*").eq("id", orderId).single(),
      supabase
        .from("order_items")
        .select("*")
        .eq("order_id", orderId)
        .order("created_at", { ascending: true }),
    ]);

    if (orderRes.error) throw new Error(orderRes.error.message);
    if (itemsRes.error) throw new Error(itemsRes.error.message);

    return {
      order: orderRowSchema.parse(orderRes.data),
      items: itemsRes.data.map((row) => orderItemRowSchema.parse(row)),
    };
  }
);

// ────────────────────────────────────────────────────────────
// UPDATE STATUS — z walidacją tranzycji
//
// ORDER_TRANSITIONS definiuje dozwolone przejścia:
//   pending  → paid, cancelled
//   paid     → shipped, cancelled
//   shipped  → completed
//   completed → (nic)
//   cancelled → (nic)
// ────────────────────────────────────────────────────────────

export const updateOrderStatusAction = withAction(
  "orders:status",
  async (supabase, orderId: string, input: UpdateOrderStatusInput) => {
    const parsed = updateOrderStatusSchema.parse(input);

    // Pobierz aktualny status
    const { data: current, error: cErr } = await supabase
      .from("orders")
      .select("status")
      .eq("id", orderId)
      .single();

    if (cErr) throw new Error("Zamówienie nie istnieje");

    const currentStatus = current.status as OrderStatus;
    const allowed = ORDER_TRANSITIONS[currentStatus];

    if (!allowed.includes(parsed.status)) {
      throw new Error(
        `Niedozwolona zmiana statusu: ${currentStatus} → ${parsed.status}`
      );
    }

    const updateData: Record<string, unknown> = {
      status: parsed.status,
    };

    // Automatyczne pola przy zmianie statusu
    if (parsed.status === "paid") {
      updateData.paid_at = new Date().toISOString();
    }

    const { data, error } = await supabase
      .from("orders")
      .update(updateData)
      .eq("id", orderId)
      .eq("status", currentStatus) // Optimistic lock
      .select()
      .single();

    if (error) {
      if (error.code === "PGRST116") {
        throw new Error(
          "Status zamówienia zmienił się w międzyczasie — odśwież stronę"
        );
      }
      throw new Error(error.message);
    }

    revalidatePath("/orders");
    revalidatePath(`/orders/${orderId}`);
    return orderRowSchema.parse(data);
  }
);
