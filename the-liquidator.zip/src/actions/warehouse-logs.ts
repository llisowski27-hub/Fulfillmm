// ============================================================
// THE LIQUIDATOR — Warehouse Logs Server Actions
// src/actions/warehouse-logs.ts
// ============================================================
// CRUD + filtrowanie logów magazynowych.
// Logi są immutable — po utworzeniu zmienić można tylko notes.
// ============================================================

"use server";

import { revalidatePath } from "next/cache";
import { withAction } from "./_helpers";
import {
  createWarehouseLogSchema,
  updateWarehouseLogSchema,
  warehouseLogRowSchema,
  warehouseLogFilterSchema,
  type CreateWarehouseLogInput,
  type UpdateWarehouseLogInput,
  type WarehouseLogFilter,
} from "@/types";

// ────────────────────────────────────────────────────────────
// CREATE — nowy wpis w logu
// ────────────────────────────────────────────────────────────

export const createWarehouseLogAction = withAction(
  "whlogs:create",
  async (supabase, input: CreateWarehouseLogInput) => {
    const parsed = createWarehouseLogSchema.parse(input);

    const { data, error } = await supabase
      .from("warehouse_logs")
      .insert(parsed)
      .select()
      .single();

    if (error) throw new Error(error.message);

    revalidatePath("/warehouse");
    revalidatePath("/inventory");
    return warehouseLogRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// READ — lista logów z filtrowaniem
// ────────────────────────────────────────────────────────────

export const getWarehouseLogsAction = withAction(
  "whlogs:list",
  async (supabase, filters?: WarehouseLogFilter) => {
    const parsed = filters
      ? warehouseLogFilterSchema.parse(filters)
      : undefined;

    let query = supabase
      .from("warehouse_logs")
      .select("*")
      .order("created_at", { ascending: false });

    if (parsed?.item_id) {
      query = query.eq("item_id", parsed.item_id);
    }
    if (parsed?.typ_akcji) {
      query = query.eq("typ_akcji", parsed.typ_akcji);
    }
    if (parsed?.from) {
      query = query.gte("created_at", parsed.from);
    }
    if (parsed?.to) {
      query = query.lte("created_at", parsed.to);
    }

    const { data, error } = await query;
    if (error) throw new Error(error.message);

    return data.map((row) => warehouseLogRowSchema.parse(row));
  }
);

// ────────────────────────────────────────────────────────────
// READ — logi dla konkretnego przedmiotu (shortcut)
// ────────────────────────────────────────────────────────────

export const getLogsForItemAction = withAction(
  "whlogs:by-item",
  async (supabase, itemId: string) => {
    const { data, error } = await supabase
      .from("warehouse_logs")
      .select("*")
      .eq("item_id", itemId)
      .order("created_at", { ascending: false });

    if (error) throw new Error(error.message);
    return data.map((row) => warehouseLogRowSchema.parse(row));
  }
);

// ────────────────────────────────────────────────────────────
// UPDATE — edycja notatki (jedyne mutowalne pole)
// ────────────────────────────────────────────────────────────

export const updateWarehouseLogAction = withAction(
  "whlogs:update",
  async (supabase, id: string, input: UpdateWarehouseLogInput) => {
    const parsed = updateWarehouseLogSchema.parse(input);

    const { data, error } = await supabase
      .from("warehouse_logs")
      .update(parsed)
      .eq("id", id)
      .select()
      .single();

    if (error) throw new Error(error.message);

    revalidatePath("/warehouse");
    return warehouseLogRowSchema.parse(data);
  }
);
