// ============================================================
// THE LIQUIDATOR — Action Helpers
// src/actions/_helpers.ts
// ============================================================
// Współdzielone typy i wrapper eliminujący boilerplate
// z każdej akcji serwerowej.
// ============================================================

import { createClient } from "@/lib/supabase/server";
import type { SupabaseClient } from "@supabase/supabase-js";

// ────────────────────────────────────────────────────────────
// Typ odpowiedzi — discriminated union
// ────────────────────────────────────────────────────────────

export type ActionResult<T> =
  | { success: true; data: T }
  | { success: false; error: string };

// ────────────────────────────────────────────────────────────
// Mapowanie kodów błędów PostgreSQL → czytelne komunikaty
// ────────────────────────────────────────────────────────────

const PG_ERROR_MAP: Record<string, string> = {
  "23505": "Naruszenie unikalności — taki rekord już istnieje",
  "23503": "Nie można usunąć — istnieją powiązane rekordy",
  "23514": "Naruszenie ograniczenia — sprawdź poprawność danych",
};

function humanizeError(error: unknown): string {
  if (error instanceof Error) {
    // Supabase errors mają `code` na obiekcie
    const pgCode = (error as { code?: string }).code;
    if (pgCode && PG_ERROR_MAP[pgCode]) {
      return PG_ERROR_MAP[pgCode];
    }
    return error.message;
  }
  return "Nieznany błąd serwera";
}

// ────────────────────────────────────────────────────────────
// withAction — wrapper eliminujący try/catch boilerplate
// ────────────────────────────────────────────────────────────
// Użycie:
//   export const doSomething = withAction("module", async (sb) => {
//     const { data } = await sb.from("...").select();
//     return data;
//   });
// ────────────────────────────────────────────────────────────

export function withAction<TArgs extends unknown[], TResult>(
  module: string,
  fn: (supabase: SupabaseClient, ...args: TArgs) => Promise<TResult>
) {
  return async (...args: TArgs): Promise<ActionResult<TResult>> => {
    try {
      const supabase = await createClient();
      const data = await fn(supabase, ...args);
      return { success: true, data };
    } catch (error) {
      const message = humanizeError(error);
      console.error(`[${module}]`, message);
      return { success: false, error: message };
    }
  };
}
