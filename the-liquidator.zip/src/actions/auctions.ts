// ============================================================
// THE LIQUIDATOR — Auctions & Bids Server Actions
// src/actions/auctions.ts
// ============================================================
// Aukcje: CRUD + tranzycje statusu.
// Bidy: atomowe składanie oferty z walidacją biznesową.
// ============================================================

"use server";

import { revalidatePath } from "next/cache";
import { withAction } from "./_helpers";
import { checkRateLimit } from "@/lib/rate-limit";
import {
  createAuctionSchema,
  updateAuctionSchema,
  auctionRowSchema,
  bidRowSchema,
  placeBidSchema,
  auctionFilterSchema,
  type CreateAuctionInput,
  type UpdateAuctionInput,
  type PlaceBidInput,
  type AuctionFilter,
} from "@/types";

// ────────────────────────────────────────────────────────────
// AUCTION — CREATE
// ────────────────────────────────────────────────────────────

export const createAuctionAction = withAction(
  "auctions:create",
  async (supabase, input: CreateAuctionInput) => {
    const parsed = createAuctionSchema.parse(input);

    // Weryfikuj że listing istnieje i jest typu auction
    const { data: listing, error: listErr } = await supabase
      .from("listings")
      .select("listing_type, status")
      .eq("id", parsed.listing_id)
      .single();

    if (listErr) throw new Error("Oferta nie istnieje");
    if (listing.listing_type !== "auction") {
      throw new Error("Ta oferta nie jest typu aukcja");
    }

    const { data, error } = await supabase
      .from("auctions")
      .insert({
        ...parsed,
        current_price: parsed.starting_price,
      })
      .select()
      .single();

    if (error) {
      if (error.code === "23505") {
        throw new Error("Ta oferta ma już przypisaną aukcję");
      }
      throw new Error(error.message);
    }

    revalidatePath("/admin/auctions");
    return auctionRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// AUCTION — READ (lista z filtrami)
// ────────────────────────────────────────────────────────────

export const getAuctionsAction = withAction(
  "auctions:list",
  async (supabase, filters?: AuctionFilter) => {
    const parsed = filters
      ? auctionFilterSchema.parse(filters)
      : undefined;

    let query = supabase
      .from("auctions")
      .select("*")
      .order("end_time", { ascending: true });

    if (parsed?.status) {
      query = query.eq("status", parsed.status);
    }
    if (parsed?.ending_before) {
      query = query.lte("end_time", parsed.ending_before);
    }
    if (parsed?.ending_after) {
      query = query.gte("end_time", parsed.ending_after);
    }
    if (parsed?.min_price) {
      query = query.gte("current_price", parsed.min_price);
    }
    if (parsed?.max_price) {
      query = query.lte("current_price", parsed.max_price);
    }

    const { data, error } = await query;
    if (error) throw new Error(error.message);

    return data.map((row) => auctionRowSchema.parse(row));
  }
);

// ────────────────────────────────────────────────────────────
// AUCTION — READ po ID
// ────────────────────────────────────────────────────────────

export const getAuctionByIdAction = withAction(
  "auctions:get",
  async (supabase, id: string) => {
    const { data, error } = await supabase
      .from("auctions")
      .select("*")
      .eq("id", id)
      .single();

    if (error) throw new Error(error.message);
    return auctionRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// AUCTION — READ po listing_id
// ────────────────────────────────────────────────────────────

export const getAuctionByListingAction = withAction(
  "auctions:by-listing",
  async (supabase, listingId: string) => {
    const { data, error } = await supabase
      .from("auctions")
      .select("*")
      .eq("listing_id", listingId)
      .single();

    if (error) throw new Error(error.message);
    return auctionRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// AUCTION — UPDATE (przed startem)
// ────────────────────────────────────────────────────────────

export const updateAuctionAction = withAction(
  "auctions:update",
  async (supabase, id: string, input: UpdateAuctionInput) => {
    const parsed = updateAuctionSchema.parse(input);

    // Tylko scheduled aukcje można edytować w pełni
    const { data, error } = await supabase
      .from("auctions")
      .update(parsed)
      .eq("id", id)
      .eq("status", "scheduled")
      .select()
      .single();

    if (error) {
      if (error.code === "PGRST116") {
        throw new Error(
          "Aukcja nie istnieje lub już wystartowała — edycja niemożliwa"
        );
      }
      throw new Error(error.message);
    }

    revalidatePath("/admin/auctions");
    return auctionRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// AUCTION — START (scheduled → active)
// ────────────────────────────────────────────────────────────

export const startAuctionAction = withAction(
  "auctions:start",
  async (supabase, id: string) => {
    const { data, error } = await supabase
      .from("auctions")
      .update({ status: "active" as const })
      .eq("id", id)
      .eq("status", "scheduled")
      .select()
      .single();

    if (error) {
      if (error.code === "PGRST116") {
        throw new Error("Aukcja nie istnieje lub nie jest zaplanowana");
      }
      throw new Error(error.message);
    }

    revalidatePath("/admin/auctions");
    return auctionRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// AUCTION — END (active → ended)
// ────────────────────────────────────────────────────────────

export const endAuctionAction = withAction(
  "auctions:end",
  async (supabase, id: string) => {
    const { data, error } = await supabase
      .from("auctions")
      .update({ status: "ended" as const })
      .eq("id", id)
      .eq("status", "active")
      .select()
      .single();

    if (error) {
      if (error.code === "PGRST116") {
        throw new Error("Aukcja nie jest aktywna");
      }
      throw new Error(error.message);
    }

    revalidatePath("/admin/auctions");
    return auctionRowSchema.parse(data);
  }
);

// ────────────────────────────────────────────────────────────
// BIDS — PLACE BID (atomowa operacja)
//
// Walidacja biznesowa:
//   1. Aukcja musi być aktywna
//   2. end_time nie minął
//   3. amount > current_price + min_bid_increment
//   4. Atomowy update: insert bid + update auction
//      w jednej transakcji (Supabase RPC)
//
// UWAGA: Dla pełnej atomowości w produkcji użyj
// Supabase Edge Function lub pg function.
// Tu robimy best-effort z sekwencyjnymi operacjami
// i walidacją po stronie bazy (CHECK constraints).
// ────────────────────────────────────────────────────────────

export const placeBidAction = withAction(
  "bids:place",
  async (supabase, userId: string, input: PlaceBidInput) => {
    const parsed = placeBidSchema.parse(input);

    // Rate limit: 1 bid per second per user
    const rl = checkRateLimit(`bid:${userId}`, 1, 1000);
    if (!rl.allowed) {
      throw new Error("Za szybko — poczekaj sekundę przed kolejnym bidem");
    }

    // Atomowa operacja — pg function z row lock.
    // Eliminuje race conditions: dwa bidy w tej samej ms
    // nie przejdą — FOR UPDATE blokuje wiersz aukcji.
    const { data, error } = await supabase.rpc("place_bid", {
      p_auction_id: parsed.auction_id,
      p_user_id: userId,
      p_amount: parsed.amount,
    });

    if (error) {
      // PG function rzuca EXCEPTION z czytelnym komunikatem
      throw new Error(error.message.replace("ERROR: ", ""));
    }

    const result = Array.isArray(data) ? data[0] : data;

    revalidatePath(`/auction/${parsed.auction_id}`);
    revalidatePath("/catalog");

    // Pobierz pełny bid z bazy (RPC zwraca minimal)
    const { data: bid, error: bErr } = await supabase
      .from("bids")
      .select("*")
      .eq("id", result.bid_id)
      .single();

    if (bErr) throw new Error(bErr.message);
    return bidRowSchema.parse(bid);
  }
);

// ────────────────────────────────────────────────────────────
// BIDS — READ (historia bidów dla aukcji)
// ────────────────────────────────────────────────────────────

export const getBidsForAuctionAction = withAction(
  "bids:list",
  async (supabase, auctionId: string) => {
    const { data, error } = await supabase
      .from("bids")
      .select("*")
      .eq("auction_id", auctionId)
      .order("created_at", { ascending: false });

    if (error) throw new Error(error.message);
    return data.map((row) => bidRowSchema.parse(row));
  }
);

// ────────────────────────────────────────────────────────────
// BIDS — READ (bidy użytkownika)
// ────────────────────────────────────────────────────────────

export const getUserBidsAction = withAction(
  "bids:user",
  async (supabase, userId: string) => {
    const { data, error } = await supabase
      .from("bids")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });

    if (error) throw new Error(error.message);
    return data.map((row) => bidRowSchema.parse(row));
  }
);
