// ============================================================
// THE LIQUIDATOR — Inventory List
// src/components/inventory/inventory-list.tsx
// ============================================================

"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";

import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

import { archiveInventoryItemAction } from "@/actions/inventory";
import { STAN_LABELS, type InventoryItemRow, type ClientRow } from "@/types";

// ────────────────────────────────────────────────────────────
// Props
// ────────────────────────────────────────────────────────────

interface InventoryListProps {
  items: InventoryItemRow[];
  clients: ClientRow[];
}

// ────────────────────────────────────────────────────────────
// Helpers
// ────────────────────────────────────────────────────────────

const STATUS_BADGE: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  w_magazynie: { label: "W magazynie", variant: "default" },
  sprzedane:   { label: "Sprzedane", variant: "secondary" },
  zwrocone:    { label: "Zwrócone", variant: "outline" },
  wycofane:    { label: "Wycofane", variant: "destructive" },
};

// ────────────────────────────────────────────────────────────
// Component
// ────────────────────────────────────────────────────────────

export function InventoryList({ items, clients }: InventoryListProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [search, setSearch] = useState("");

  const clientMap = new Map(clients.map((c) => [c.id, c.nazwa]));

  const filtered = items.filter((item) => {
    if (!search) return true;
    const q = search.toUpperCase();
    return (
      item.sku.includes(q) ||
      item.nazwa.toUpperCase().includes(q) ||
      item.lokalizacja_kod.includes(q)
    );
  });

  function handleArchive(id: string, sku: string) {
    startTransition(async () => {
      const result = await archiveInventoryItemAction(id);
      if (!result.success) {
        toast.error("Błąd wycofania", { description: result.error });
        return;
      }
      toast.success("Przedmiot wycofany", { description: sku });
      router.refresh();
    });
  }

  return (
    <Card>
      <CardHeader className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <CardTitle>Magazyn</CardTitle>
        <div className="flex gap-2">
          <Input
            placeholder="Szukaj SKU, nazwy, lokalizacji…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-[280px] font-mono"
          />
          <Button size="sm" onClick={() => router.push("/inventory/new")}>
            + Przyjmij
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {filtered.length === 0 ? (
          <p className="py-8 text-center text-muted-foreground">
            {search
              ? "Brak wyników dla podanego filtra."
              : "Magazyn jest pusty. Przyjmij pierwszy towar."}
          </p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>SKU</TableHead>
                  <TableHead>Nazwa</TableHead>
                  <TableHead>Lokalizacja</TableHead>
                  <TableHead>Stan</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Klient</TableHead>
                  <TableHead className="text-right">Zakup</TableHead>
                  <TableHead className="text-right">Cel</TableHead>
                  <TableHead className="text-right">Akcje</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((item) => {
                  const badge = STATUS_BADGE[item.status] ?? {
                    label: item.status,
                    variant: "outline" as const,
                  };
                  return (
                    <TableRow key={item.id}>
                      <TableCell className="font-mono text-sm">
                        {item.sku}
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate">
                        {item.nazwa}
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {item.lokalizacja_kod}
                      </TableCell>
                      <TableCell className="text-sm">
                        {STAN_LABELS[item.stan]}
                      </TableCell>
                      <TableCell>
                        <Badge variant={badge.variant}>
                          {badge.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {clientMap.get(item.client_id) ?? "—"}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {item.cena_zakupu.toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {item.cena_docelowa.toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() =>
                              router.push(`/inventory/${item.id}`)
                            }
                            disabled={isPending}
                          >
                            Szczegóły
                          </Button>
                          {item.status === "w_magazynie" && (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-destructive"
                              onClick={() =>
                                handleArchive(item.id, item.sku)
                              }
                              disabled={isPending}
                            >
                              Wycofaj
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
