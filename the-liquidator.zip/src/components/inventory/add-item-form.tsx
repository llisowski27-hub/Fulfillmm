// ============================================================
// THE LIQUIDATOR — Add Inventory Item Form
// src/components/inventory/add-item-form.tsx
// ============================================================
// Garażowy UX:
//   • Sticky context — client_id i lokalizacja_kod zostają po submicie
//   • Smart focus — po sukcesie focus wraca do SKU (skaner)
//   • Toast na sukces/błąd
//
// Wymaga:
//   npx shadcn@latest add form input button card select sonner
// ============================================================

"use client";

import { useRef, useTransition } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

import { SelectCondition } from "@/components/ui/select-condition";
import { createInventoryItemAction } from "@/actions/inventory";
import {
  createInventoryItemSchema,
  type CreateInventoryItemInput,
  type ClientRow,
  type Stan,
} from "@/types";

// ────────────────────────────────────────────────────────────
// Props
// ────────────────────────────────────────────────────────────

interface AddItemFormProps {
  clients: ClientRow[];
}

// ────────────────────────────────────────────────────────────
// Default values — pola "sticky" zachowują wartość po reset
// ────────────────────────────────────────────────────────────

const EMPTY_FORM: CreateInventoryItemInput = {
  sku: "",
  nazwa: "",
  opis: null,
  stan: "nowy" as Stan,
  status: "w_magazynie",
  lokalizacja_kod: "",
  cena_zakupu: 0,
  cena_docelowa: 0,
  client_id: "",
  last_audited_at: null,
  checked_by: null,
};

// ────────────────────────────────────────────────────────────
// Component
// ────────────────────────────────────────────────────────────

export function AddItemForm({ clients }: AddItemFormProps) {
  const skuInputRef = useRef<HTMLInputElement>(null);
  const [isPending, startTransition] = useTransition();

  const form = useForm<CreateInventoryItemInput>({
    resolver: zodResolver(createInventoryItemSchema),
    defaultValues: EMPTY_FORM,
  });

  function onSubmit(values: CreateInventoryItemInput) {
    startTransition(async () => {
      const result = await createInventoryItemAction(values);

      if (!result.success) {
        toast.error("Błąd zapisu", { description: result.error });
        return;
      }

      toast.success("Towar przyjęty", {
        description: `SKU: ${result.data.sku} → ${result.data.lokalizacja_kod}`,
      });

      // ── Sticky context reset ────────────────────────────
      // Zachowaj client_id i lokalizacja_kod, wyczyść resztę
      const stickyClientId = form.getValues("client_id");
      const stickyLokalizacja = form.getValues("lokalizacja_kod");

      form.reset({
        ...EMPTY_FORM,
        client_id: stickyClientId,
        lokalizacja_kod: stickyLokalizacja,
      });

      // ── Smart focus → SKU (skaner) ──────────────────────
      requestAnimationFrame(() => {
        skuInputRef.current?.focus();
      });
    });
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Przyjęcie towaru</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="grid gap-6"
          >
            {/* ── Sekcja sticky: Klient + Lokalizacja ────── */}
            <div className="grid gap-4 sm:grid-cols-2 rounded-lg border border-dashed p-4">
              <FormField
                control={form.control}
                name="client_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Klient</FormLabel>
                    <Select
                      value={field.value}
                      onValueChange={field.onChange}
                      disabled={isPending}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Wybierz klienta" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {clients.map((c) => (
                          <SelectItem key={c.id} value={c.id}>
                            {c.nazwa}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="lokalizacja_kod"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Lokalizacja (regał)</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="np. A-01-03"
                        disabled={isPending}
                        className="uppercase"
                        onChange={(e) =>
                          field.onChange(e.target.value.toUpperCase())
                        }
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* ── SKU (smart focus target) ───────────────── */}
            <FormField
              control={form.control}
              name="sku"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>SKU</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      ref={(el) => {
                        field.ref(el);
                        (skuInputRef as React.MutableRefObject<HTMLInputElement | null>).current = el;
                      }}
                      placeholder="np. NIKE-AF1-42-BLK"
                      disabled={isPending}
                      className="uppercase font-mono"
                      autoFocus
                      onChange={(e) =>
                        field.onChange(e.target.value.toUpperCase())
                      }
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Nazwa + Opis ────────────────────────────── */}
            <FormField
              control={form.control}
              name="nazwa"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nazwa przedmiotu</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="np. Nike Air Force 1 Low White"
                      disabled={isPending}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="opis"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Opis{" "}
                    <span className="text-muted-foreground font-normal">
                      (opcjonalnie)
                    </span>
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      value={field.value ?? ""}
                      onChange={(e) =>
                        field.onChange(e.target.value || null)
                      }
                      placeholder="Uwagi, stan pudełka, braki…"
                      disabled={isPending}
                      rows={2}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Stan (kondycja) ─────────────────────────── */}
            <FormField
              control={form.control}
              name="stan"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Stan (kondycja)</FormLabel>
                  <FormControl>
                    <SelectCondition
                      value={field.value}
                      onValueChange={field.onChange}
                      disabled={isPending}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Ceny ────────────────────────────────────── */}
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="cena_zakupu"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cena zakupu (PLN)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        disabled={isPending}
                        value={field.value}
                        onChange={(e) =>
                          field.onChange(parseFloat(e.target.value) || 0)
                        }
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="cena_docelowa"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cena docelowa (PLN)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        disabled={isPending}
                        value={field.value}
                        onChange={(e) =>
                          field.onChange(parseFloat(e.target.value) || 0)
                        }
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* ── Submit ──────────────────────────────────── */}
            <Button
              type="submit"
              disabled={isPending}
              className="w-full sm:w-auto"
            >
              {isPending ? "Zapisuję…" : "Przyjmij towar"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
