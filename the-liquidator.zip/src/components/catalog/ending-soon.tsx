// ============================================================
// THE LIQUIDATOR — Ending Soon Section
// src/components/catalog/ending-soon.tsx
// ============================================================
// Sekcja na górze katalogu: aukcje kończące się najwcześniej.
// Buduje presję czasu, zwiększa konwersję.
// ============================================================

import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import type { ListingRow, AuctionRow } from "@/types";

interface EndingSoonProps {
  listings: ListingRow[];
  auctions: AuctionRow[];
  limit?: number;
}

export function EndingSoon({
  listings,
  auctions,
  limit = 6,
}: EndingSoonProps) {
  // Filtruj aktywne aukcje, sortuj po end_time
  const activeAuctions = auctions
    .filter((a) => a.status === "active" && new Date(a.end_time) > new Date())
    .sort(
      (a, b) =>
        new Date(a.end_time).getTime() - new Date(b.end_time).getTime()
    )
    .slice(0, limit);

  if (activeAuctions.length === 0) return null;

  const listingMap = new Map(listings.map((l) => [l.id, l]));

  return (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold">Kończy się wkrótce</h2>
        <span className="text-xs text-muted-foreground">
          {activeAuctions.length} aktywnych aukcji
        </span>
      </div>

      <div className="grid gap-3 grid-cols-2 sm:grid-cols-3 lg:grid-cols-6">
        {activeAuctions.map((auction) => {
          const listing = listingMap.get(auction.listing_id);
          if (!listing) return null;

          const href = listing.slug
            ? `/product/${listing.slug}`
            : `/product/${listing.id}`;
          const timeLeft = getCompactTimeLeft(auction.end_time);
          const price = auction.current_price ?? auction.starting_price;
          const isUrgent = isWithinMinutes(auction.end_time, 5);

          return (
            <Link key={auction.id} href={href} className="group block">
              <Card className="overflow-hidden border transition-colors hover:border-foreground/20">
                {/* Miniatura */}
                <div className="relative aspect-[4/3] bg-muted">
                  {listing.images[0] ? (
                    <img
                      src={listing.images[0]}
                      alt={listing.title}
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  ) : (
                    <div className="flex h-full items-center justify-center text-muted-foreground text-xs">
                      Brak zdjęcia
                    </div>
                  )}

                  {/* Countdown badge */}
                  <div
                    className={`absolute top-1.5 right-1.5 rounded-md px-1.5 py-0.5 text-[11px] font-mono font-medium tabular-nums ${
                      isUrgent
                        ? "bg-red-600 text-white"
                        : "bg-background/90 backdrop-blur-sm text-foreground"
                    }`}
                  >
                    {timeLeft}
                  </div>
                </div>

                <CardContent className="p-2">
                  <p className="text-xs leading-tight line-clamp-1 mb-1">
                    {listing.title}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold tabular-nums">
                      {price.toLocaleString("pl-PL", {
                        minimumFractionDigits: 2,
                      })}{" "}
                      zł
                    </span>
                    {auction.bid_count > 0 && (
                      <Badge
                        variant="secondary"
                        className="text-[10px] px-1.5 py-0"
                      >
                        {auction.bid_count}
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>
    </section>
  );
}

// ────────────────────────────────────────────────────────────
// Helpers
// ────────────────────────────────────────────────────────────

function getCompactTimeLeft(endTime: string): string {
  const diff = new Date(endTime).getTime() - Date.now();
  if (diff <= 0) return "0:00";

  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff / (1000 * 60)) % 60);
  const seconds = Math.floor((diff / 1000) % 60);

  if (hours > 24) {
    const days = Math.floor(hours / 24);
    return `${days}d`;
  }
  if (hours > 0) {
    return `${hours}h ${minutes}m`;
  }
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
}

function isWithinMinutes(endTime: string, mins: number): boolean {
  const diff = new Date(endTime).getTime() - Date.now();
  return diff > 0 && diff <= mins * 60 * 1000;
}
