// ============================================================
// THE LIQUIDATOR — Catalog Filters
// src/components/catalog/catalog-filters.tsx
// ============================================================

"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useCallback } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { LISTING_TYPES, LISTING_TYPE_LABELS } from "@/types";

interface CatalogFiltersProps {
  categories: string[];
}

export function CatalogFilters({ categories }: CatalogFiltersProps) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const updateParam = useCallback(
    (key: string, value: string | null) => {
      const params = new URLSearchParams(searchParams.toString());
      if (value) {
        params.set(key, value);
      } else {
        params.delete(key);
      }
      params.delete("page"); // reset paginacji
      router.push(`/catalog?${params.toString()}`);
    },
    [router, searchParams]
  );

  const clearAll = useCallback(() => {
    router.push("/catalog");
  }, [router]);

  const currentType = searchParams.get("type") ?? "";
  const currentCategory = searchParams.get("category") ?? "";
  const currentSearch = searchParams.get("q") ?? "";
  const currentMinPrice = searchParams.get("min") ?? "";
  const currentMaxPrice = searchParams.get("max") ?? "";
  const hasFilters = currentType || currentCategory || currentSearch || currentMinPrice || currentMaxPrice;

  return (
    <div className="space-y-4">
      {/* Szukaj */}
      <div>
        <label className="text-sm font-medium mb-1.5 block">Szukaj</label>
        <Input
          placeholder="Nike, Adidas, iPhone…"
          defaultValue={currentSearch}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              updateParam("q", (e.target as HTMLInputElement).value || null);
            }
          }}
        />
      </div>

      {/* Typ oferty */}
      <div>
        <label className="text-sm font-medium mb-1.5 block">Typ oferty</label>
        <Select
          value={currentType}
          onValueChange={(v) => updateParam("type", v === "all" ? null : v)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Wszystkie" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Wszystkie</SelectItem>
            {LISTING_TYPES.map((t) => (
              <SelectItem key={t} value={t}>
                {LISTING_TYPE_LABELS[t]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Kategoria */}
      {categories.length > 0 && (
        <div>
          <label className="text-sm font-medium mb-1.5 block">Kategoria</label>
          <Select
            value={currentCategory}
            onValueChange={(v) =>
              updateParam("category", v === "all" ? null : v)
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Wszystkie" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Wszystkie</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Zakres cenowy */}
      <div>
        <label className="text-sm font-medium mb-1.5 block">Cena (zł)</label>
        <div className="flex gap-2">
          <Input
            type="number"
            placeholder="Od"
            min={0}
            defaultValue={currentMinPrice}
            className="tabular-nums"
            onBlur={(e) =>
              updateParam("min", e.target.value || null)
            }
          />
          <Input
            type="number"
            placeholder="Do"
            min={0}
            defaultValue={currentMaxPrice}
            className="tabular-nums"
            onBlur={(e) =>
              updateParam("max", e.target.value || null)
            }
          />
        </div>
      </div>

      {/* Wyczyść */}
      {hasFilters && (
        <Button variant="ghost" size="sm" onClick={clearAll} className="w-full">
          Wyczyść filtry
        </Button>
      )}
    </div>
  );
}
