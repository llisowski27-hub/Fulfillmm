// ============================================================
// THE LIQUIDATOR — Product Card v2
// src/components/catalog/product-card.tsx
// ============================================================

import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import {
  LISTING_TYPE_LABELS,
  type ListingRow,
  type AuctionRow,
} from "@/types";

interface ProductCardProps {
  listing: ListingRow;
  auction?: AuctionRow;
}

export function ProductCard({ listing, auction }: ProductCardProps) {
  const isAuction = listing.listing_type === "auction";
  const href = listing.slug
    ? `/product/${listing.slug}`
    : `/product/${listing.id}`;

  const displayPrice = isAuction
    ? auction?.current_price ?? auction?.starting_price ?? 0
    : listing.buy_now_price ?? 0;

  const timeLeft = auction?.end_time
    ? getTimeLeft(auction.end_time)
    : null;

  const isUrgent = auction?.end_time
    ? new Date(auction.end_time).getTime() - Date.now() <= 5 * 60 * 1000
    : false;

  return (
    <Link href={href} className="group block">
      <div className="overflow-hidden rounded-lg border bg-card transition-colors hover:border-foreground/20">
        {/* Zdjęcie — 1:1 */}
        <div className="relative aspect-square bg-muted overflow-hidden">
          {listing.images[0] ? (
            <img
              src={listing.images[0]}
              alt={listing.title}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
            />
          ) : (
            <div className="flex h-full items-center justify-center">
              <span className="text-sm text-muted-foreground">Brak zdjęcia</span>
            </div>
          )}

          {/* Górny lewy — badge typ */}
          <div className="absolute left-2 top-2 flex flex-wrap gap-1">
            <Badge
              variant={isAuction ? "default" : "secondary"}
              className="text-[11px] leading-none px-2 py-0.5"
            >
              {LISTING_TYPE_LABELS[listing.listing_type]}
            </Badge>
            {listing.is_featured && (
              <Badge
                variant="outline"
                className="text-[11px] leading-none px-2 py-0.5 bg-card/80 backdrop-blur-sm"
              >
                Hit
              </Badge>
            )}
          </div>

          {/* Dolny prawy — countdown */}
          {isAuction && timeLeft && (
            <div
              className={`absolute bottom-2 right-2 rounded px-2 py-1 text-[11px] font-mono font-medium leading-none tabular-nums ${
                isUrgent
                  ? "bg-red-600 text-white"
                  : "bg-card/90 backdrop-blur-sm text-foreground"
              }`}
            >
              {timeLeft}
            </div>
          )}
        </div>

        {/* Info — stałe paddingi */}
        <div className="px-3 py-3 space-y-2">
          {/* Tytuł — 14px, max 2 linie */}
          <h3 className="text-[14px] leading-[1.3] font-medium line-clamp-2 min-h-[36px]">
            {listing.title}
          </h3>

          {/* Cena + meta */}
          <div className="flex items-end justify-between gap-2">
            <div>
              {isAuction && (
                <p className="text-[11px] leading-none text-muted-foreground mb-1">
                  {auction?.bid_count
                    ? `${auction.bid_count} ${pluralizeBids(auction.bid_count)}`
                    : "Brak ofert"}
                </p>
              )}
              <p className="text-[18px] leading-none font-bold tabular-nums">
                {displayPrice.toLocaleString("pl-PL", {
                  minimumFractionDigits: 2,
                })}
                <span className="text-[13px] font-normal text-muted-foreground ml-0.5">
                  zł
                </span>
              </p>
            </div>

            {/* Buy-it-now na aukcji */}
            {isAuction && listing.buy_now_price && (
              <p className="text-[11px] leading-tight text-right text-muted-foreground tabular-nums">
                Kup teraz
                <br />
                {listing.buy_now_price.toLocaleString("pl-PL", {
                  minimumFractionDigits: 2,
                })}{" "}
                zł
              </p>
            )}
          </div>

          {/* Kategoria */}
          {listing.category && (
            <p className="text-[11px] leading-none text-muted-foreground pt-1 border-t">
              {listing.category}
            </p>
          )}
        </div>
      </div>
    </Link>
  );
}

// ── Helpers ─────────────────────────────────────────────────

function getTimeLeft(endTime: string): string | null {
  const diff = new Date(endTime).getTime() - Date.now();
  if (diff <= 0) return "Zakończona";

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diff / (1000 * 60)) % 60);

  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

function pluralizeBids(n: number): string {
  if (n === 1) return "oferta";
  if (n >= 2 && n <= 4) return "oferty";
  return "ofert";
}
