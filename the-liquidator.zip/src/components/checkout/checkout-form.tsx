// ============================================================
// THE LIQUIDATOR — Checkout Form
// src/components/checkout/checkout-form.tsx
// ============================================================
// Trzy sekcje: dane zamawiającego, adres, podsumowanie.
// Walidacja client-side (Zod) + server-side (createOrderAction).
// Po sukcesie: clear cart + redirect → /order/[id]/success
// ============================================================

"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import { useCart, type CartItem } from "@/components/cart/cart-context";
import { createOrderAction } from "@/actions/orders";
import type { CreateOrderInput } from "@/types";

// ────────────────────────────────────────────────────────────
// Checkout schema (client-side — dane zamawiającego + adres)
// ────────────────────────────────────────────────────────────

const checkoutFormSchema = z.object({
  email: z
    .string()
    .email("Nieprawidłowy adres email"),
  shipping_name: z
    .string()
    .trim()
    .min(1, "Imię i nazwisko wymagane")
    .max(200),
  shipping_street: z
    .string()
    .trim()
    .min(1, "Ulica wymagana")
    .max(300),
  shipping_city: z
    .string()
    .trim()
    .min(1, "Miasto wymagane")
    .max(100),
  shipping_postal: z
    .string()
    .trim()
    .regex(/^\d{2}-\d{3}$/, "Format: 00-000"),
  shipping_country: z.string().trim().default("PL"),
  shipping_phone: z
    .string()
    .trim()
    .max(20)
    .nullable()
    .default(null),
  notes: z
    .string()
    .trim()
    .max(500, "Notatka max 500 znaków")
    .nullable()
    .default(null),
});

type CheckoutFormValues = z.infer<typeof checkoutFormSchema>;

// ────────────────────────────────────────────────────────────
// Component
// ────────────────────────────────────────────────────────────

export function CheckoutForm() {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const { items, total, clearCart } = useCart();

  const form = useForm<CheckoutFormValues>({
    resolver: zodResolver(checkoutFormSchema),
    defaultValues: {
      email: "",
      shipping_name: "",
      shipping_street: "",
      shipping_city: "",
      shipping_postal: "",
      shipping_country: "PL",
      shipping_phone: null,
      notes: null,
    },
  });

  function onSubmit(values: CheckoutFormValues) {
    if (items.length === 0) {
      toast.error("Koszyk jest pusty");
      return;
    }

    startTransition(async () => {
      // Buduj input dla Server Action
      const orderInput: CreateOrderInput = {
        shipping_name: values.shipping_name,
        shipping_street: values.shipping_street,
        shipping_city: values.shipping_city,
        shipping_postal: values.shipping_postal,
        shipping_country: values.shipping_country,
        shipping_phone: values.shipping_phone,
        notes: values.notes,
        items: items.map((item) => ({
          listing_id: item.listing_id,
          quantity: item.quantity,
          unit_price: item.unit_price,
          source_type: item.source_type,
          bid_id: null,
        })),
      };

      // TODO: userId z Supabase Auth session
      // Na start: placeholder, w produkcji pobierz z auth
      const userId = "placeholder";

      const result = await createOrderAction(userId, orderInput);

      if (!result.success) {
        toast.error("Błąd zamówienia", { description: result.error });
        return;
      }

      clearCart();
      router.push(`/order/${result.data.id}/success`);
    });
  }

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(onSubmit)}
        className="grid gap-6 lg:grid-cols-[1fr_340px]"
      >
        {/* ── Lewa kolumna: formularze ──────────────────── */}
        <div className="space-y-6">
          {/* Sekcja A: Dane zamawiającego */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Dane zamawiającego</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="email"
                        placeholder="twoj@email.pl"
                        disabled={isPending}
                        autoFocus
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="shipping_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Imię i nazwisko</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="Jan Kowalski"
                        disabled={isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="shipping_phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Telefon{" "}
                      <span className="text-muted-foreground font-normal">
                        (opcjonalnie)
                      </span>
                    </FormLabel>
                    <FormControl>
                      <Input
                        value={field.value ?? ""}
                        onChange={(e) =>
                          field.onChange(e.target.value || null)
                        }
                        placeholder="+48 123 456 789"
                        disabled={isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Sekcja B: Adres dostawy */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Adres dostawy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="shipping_street"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Ulica i numer</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="ul. Marszałkowska 1/2"
                        disabled={isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid gap-4 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="shipping_postal"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Kod pocztowy</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="00-000"
                          maxLength={6}
                          disabled={isPending}
                          onChange={(e) => {
                            let v = e.target.value.replace(/[^\d-]/g, "");
                            // Auto-format: 00000 → 00-000
                            if (v.length === 5 && !v.includes("-")) {
                              v = `${v.slice(0, 2)}-${v.slice(2)}`;
                            }
                            field.onChange(v);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="shipping_city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Miasto</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="Warszawa"
                          disabled={isPending}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="shipping_country"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Kraj</FormLabel>
                    <FormControl>
                      <Input {...field} disabled />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Uwagi do zamówienia{" "}
                      <span className="text-muted-foreground font-normal">
                        (opcjonalnie)
                      </span>
                    </FormLabel>
                    <FormControl>
                      <Textarea
                        value={field.value ?? ""}
                        onChange={(e) =>
                          field.onChange(e.target.value || null)
                        }
                        placeholder="Dodatkowe informacje dla dostawcy…"
                        disabled={isPending}
                        rows={2}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>
        </div>

        {/* ── Prawa kolumna: podsumowanie ───────────────── */}
        <div className="lg:sticky lg:top-20 h-fit">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">
                Podsumowanie zamówienia
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Lista pozycji (read-only) */}
              <ul className="space-y-2">
                {items.map((item) => (
                  <OrderSummaryItem key={item.listing_id} item={item} />
                ))}
              </ul>

              {items.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-4">
                  Koszyk jest pusty
                </p>
              )}

              {/* Kwoty */}
              <div className="border-t pt-3 space-y-1.5">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Produkty</span>
                  <span className="tabular-nums">
                    {total.toLocaleString("pl-PL", {
                      minimumFractionDigits: 2,
                    })}{" "}
                    zł
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Dostawa</span>
                  <span className="tabular-nums text-muted-foreground">
                    0,00 zł
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t">
                  <span className="font-semibold">Do zapłaty</span>
                  <span className="font-semibold tabular-nums text-lg">
                    {total.toLocaleString("pl-PL", {
                      minimumFractionDigits: 2,
                    })}{" "}
                    zł
                  </span>
                </div>
              </div>

              {/* CTA */}
              <Button
                type="submit"
                className="w-full"
                disabled={isPending || items.length === 0}
              >
                {isPending ? "Składam zamówienie…" : "Złóż zamówienie"}
              </Button>

              <p className="text-[11px] text-muted-foreground text-center leading-tight">
                Składając zamówienie akceptujesz regulamin.
                Płatność przy odbiorze lub przelewem.
              </p>
            </CardContent>
          </Card>
        </div>
      </form>
    </Form>
  );
}

// ────────────────────────────────────────────────────────────
// Sub-component: pozycja w podsumowaniu
// ────────────────────────────────────────────────────────────

function OrderSummaryItem({ item }: { item: CartItem }) {
  const lineTotal =
    Math.round(item.unit_price * item.quantity * 100) / 100;

  return (
    <li className="flex items-center gap-3">
      <div className="h-10 w-10 shrink-0 overflow-hidden rounded bg-muted">
        {item.image ? (
          <img
            src={item.image}
            alt={item.title}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="h-full w-full flex items-center justify-center text-[10px] text-muted-foreground">
            —
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm truncate">{item.title}</p>
        <p className="text-xs text-muted-foreground tabular-nums">
          {item.quantity} × {item.unit_price.toFixed(2)} zł
        </p>
      </div>
      <span className="text-sm font-medium tabular-nums shrink-0">
        {lineTotal.toLocaleString("pl-PL", {
          minimumFractionDigits: 2,
        })}{" "}
        zł
      </span>
    </li>
  );
}
