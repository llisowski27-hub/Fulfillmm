// ============================================================
// THE LIQUIDATOR — Admin: Listing Form (Create / Edit)
// src/components/admin/listing-form.tsx
// ============================================================
// Jeden komponent: create + edit.
// Discriminated union na listing_type:
//   buy_now → price, quantity
//   auction → start_price, min_bid_increment, start/end_time
// ============================================================

"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import {
  createListingAction,
  updateListingAction,
} from "@/actions/listings";
import {
  createAuctionAction,
} from "@/actions/auctions";
import {
  type ListingRow,
  type AuctionRow,
  type ListingType,
  LISTING_TYPES,
  LISTING_TYPE_LABELS,
} from "@/types";

// ────────────────────────────────────────────────────────────
// Form schema — superset pól (walidacja dynamiczna)
// ────────────────────────────────────────────────────────────

const listingFormSchema = z
  .object({
    listing_type: z.enum(LISTING_TYPES),
    inventory_item_id: z.string().uuid("Wybierz przedmiot z magazynu"),
    title: z.string().trim().min(1, "Tytuł wymagany").max(300),
    description: z.string().trim().max(5000).nullable().default(null),
    images: z.string().default(""),
    buy_now_price: z.number().min(0).nullable().default(null),
    quantity_available: z.number().int().min(1).default(1),
    category: z.string().trim().max(100).nullable().default(null),
    slug: z.string().trim().max(200).nullable().default(null),
    // Auction fields
    starting_price: z.number().min(0).nullable().default(null),
    min_bid_increment: z.number().min(0.01).default(1),
    reserve_price: z.number().min(0).nullable().default(null),
    start_time: z.string().default(""),
    end_time: z.string().default(""),
  })
  .refine(
    (d) => d.listing_type !== "buy_now" || (d.buy_now_price !== null && d.buy_now_price > 0),
    { message: "Cena 'Kup teraz' wymagana", path: ["buy_now_price"] }
  )
  .refine(
    (d) =>
      d.listing_type !== "auction" ||
      (d.starting_price !== null && d.starting_price > 0),
    { message: "Cena wywoławcza wymagana", path: ["starting_price"] }
  )
  .refine(
    (d) => d.listing_type !== "auction" || (d.start_time && d.end_time),
    { message: "Daty aukcji wymagane", path: ["end_time"] }
  )
  .refine(
    (d) => {
      if (d.listing_type !== "auction" || !d.start_time || !d.end_time) return true;
      return new Date(d.start_time) < new Date(d.end_time);
    },
    { message: "Data startu musi być przed datą końca", path: ["end_time"] }
  );

type FormValues = z.infer<typeof listingFormSchema>;

// ────────────────────────────────────────────────────────────
// Props
// ────────────────────────────────────────────────────────────

interface ListingFormProps {
  inventoryItems: { id: string; sku: string; nazwa: string }[];
  listing?: ListingRow;
  auction?: AuctionRow;
}

// ────────────────────────────────────────────────────────────
// Component
// ────────────────────────────────────────────────────────────

export function ListingForm({
  inventoryItems,
  listing,
  auction,
}: ListingFormProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const isEditing = !!listing;

  const form = useForm<FormValues>({
    resolver: zodResolver(listingFormSchema),
    defaultValues: listing
      ? {
          listing_type: listing.listing_type,
          inventory_item_id: listing.inventory_item_id,
          title: listing.title,
          description: listing.description,
          images: listing.images.join("\n"),
          buy_now_price: listing.buy_now_price,
          quantity_available: listing.quantity_available,
          category: listing.category,
          slug: listing.slug,
          starting_price: auction?.starting_price ?? null,
          min_bid_increment: auction?.min_bid_increment ?? 1,
          reserve_price: auction?.reserve_price ?? null,
          start_time: auction?.start_time
            ? toLocalDatetimeValue(auction.start_time)
            : "",
          end_time: auction?.end_time
            ? toLocalDatetimeValue(auction.end_time)
            : "",
        }
      : {
          listing_type: "buy_now" as ListingType,
          inventory_item_id: "",
          title: "",
          description: null,
          images: "",
          buy_now_price: null,
          quantity_available: 1,
          category: null,
          slug: null,
          starting_price: null,
          min_bid_increment: 1,
          reserve_price: null,
          start_time: "",
          end_time: "",
        },
  });

  const listingType = form.watch("listing_type");
  const isAuction = listingType === "auction";

  function onSubmit(values: FormValues) {
    startTransition(async () => {
      // Parse images from newline-separated URLs
      const images = values.images
        .split("\n")
        .map((u) => u.trim())
        .filter(Boolean);

      // Build listing input
      const listingInput = {
        listing_type: values.listing_type,
        inventory_item_id: values.inventory_item_id,
        title: values.title,
        description: values.description,
        images,
        buy_now_price: values.listing_type === "buy_now"
          ? values.buy_now_price
          : values.buy_now_price, // buy-it-now for auctions
        quantity_available: values.quantity_available,
        category: values.category,
        slug: values.slug,
        tags: [],
      } as Parameters<typeof createListingAction>[0];

      let result;
      if (isEditing) {
        result = await updateListingAction(listing!.id, listingInput as Parameters<typeof updateListingAction>[1]);
      } else {
        result = await createListingAction(listingInput);
      }

      if (!result.success) {
        toast.error("Błąd zapisu", { description: result.error });
        return;
      }

      // Jeśli nowa aukcja — utwórz rekord aukcji
      if (!isEditing && values.listing_type === "auction") {
        const auctionResult = await createAuctionAction({
          listing_id: result.data.id,
          starting_price: values.starting_price!,
          min_bid_increment: values.min_bid_increment,
          reserve_price: values.reserve_price,
          start_time: new Date(values.start_time).toISOString(),
          end_time: new Date(values.end_time).toISOString(),
        });

        if (!auctionResult.success) {
          toast.error("Listing utworzony, ale aukcja nie", {
            description: auctionResult.error,
          });
          router.push("/admin/listings");
          return;
        }
      }

      toast.success(
        isEditing ? "Oferta zaktualizowana" : "Oferta utworzona",
        { description: result.data.title }
      );
      router.push("/admin/listings");
      router.refresh();
    });
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          {isEditing ? `Edycja: ${listing.title}` : "Nowa oferta"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="space-y-6"
          >
            {/* ── Typ oferty ──────────────────────────────── */}
            <FormField
              control={form.control}
              name="listing_type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Typ oferty</FormLabel>
                  <Select
                    value={field.value}
                    onValueChange={field.onChange}
                    disabled={isPending || isEditing}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {LISTING_TYPES.map((t) => (
                        <SelectItem key={t} value={t}>
                          {LISTING_TYPE_LABELS[t]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Przedmiot z magazynu ─────────────────────── */}
            <FormField
              control={form.control}
              name="inventory_item_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Przedmiot z magazynu</FormLabel>
                  <Select
                    value={field.value}
                    onValueChange={field.onChange}
                    disabled={isPending || isEditing}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Wybierz przedmiot" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {inventoryItems.map((item) => (
                        <SelectItem key={item.id} value={item.id}>
                          {item.sku} — {item.nazwa}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Tytuł + opis ────────────────────────────── */}
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tytuł oferty</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      disabled={isPending}
                      placeholder="np. Nike Air Force 1 Low White EU 42"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Opis{" "}
                    <span className="text-muted-foreground font-normal">
                      (opcjonalnie)
                    </span>
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      value={field.value ?? ""}
                      onChange={(e) =>
                        field.onChange(e.target.value || null)
                      }
                      disabled={isPending}
                      rows={4}
                      placeholder="Szczegółowy opis przedmiotu…"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Zdjęcia (URL per linia) ─────────────────── */}
            <FormField
              control={form.control}
              name="images"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Zdjęcia (URL, jedno na linię)
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      disabled={isPending}
                      rows={3}
                      placeholder={"https://example.com/photo1.jpg\nhttps://example.com/photo2.jpg"}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Kategoria + slug ────────────────────────── */}
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Kategoria</FormLabel>
                    <FormControl>
                      <Input
                        value={field.value ?? ""}
                        onChange={(e) =>
                          field.onChange(e.target.value || null)
                        }
                        disabled={isPending}
                        placeholder="np. Sneakers"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="slug"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Slug (URL)</FormLabel>
                    <FormControl>
                      <Input
                        value={field.value ?? ""}
                        onChange={(e) =>
                          field.onChange(
                            e.target.value
                              .toLowerCase()
                              .replace(/[^a-z0-9-]/g, "") || null
                          )
                        }
                        disabled={isPending}
                        placeholder="nike-air-force-1-42"
                        className="font-mono text-sm"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* ── Cena buy-now ────────────────────────────── */}
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="buy_now_price"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Cena kup teraz (PLN)
                      {isAuction && (
                        <span className="text-muted-foreground font-normal">
                          {" "}
                          — opcjonalna
                        </span>
                      )}
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        value={field.value ?? ""}
                        onChange={(e) =>
                          field.onChange(
                            e.target.value
                              ? parseFloat(e.target.value)
                              : null
                          )
                        }
                        disabled={isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="quantity_available"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Ilość</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="1"
                        value={field.value}
                        onChange={(e) =>
                          field.onChange(parseInt(e.target.value) || 1)
                        }
                        disabled={isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* ── Pola aukcji (warunkowe) ─────────────────── */}
            {isAuction && (
              <Card className="border-dashed">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">
                    Ustawienia aukcji
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-3">
                    <FormField
                      control={form.control}
                      name="starting_price"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Cena wywoławcza (PLN)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.01"
                              min="0.01"
                              value={field.value ?? ""}
                              onChange={(e) =>
                                field.onChange(
                                  e.target.value
                                    ? parseFloat(e.target.value)
                                    : null
                                )
                              }
                              disabled={isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="min_bid_increment"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Krok licytacji (PLN)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.01"
                              min="0.01"
                              value={field.value}
                              onChange={(e) =>
                                field.onChange(
                                  parseFloat(e.target.value) || 1
                                )
                              }
                              disabled={isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="reserve_price"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>
                            Cena minimalna{" "}
                            <span className="text-muted-foreground font-normal">
                              (opcj.)
                            </span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.01"
                              min="0"
                              value={field.value ?? ""}
                              onChange={(e) =>
                                field.onChange(
                                  e.target.value
                                    ? parseFloat(e.target.value)
                                    : null
                                )
                              }
                              disabled={isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="start_time"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Start aukcji</FormLabel>
                          <FormControl>
                            <Input
                              type="datetime-local"
                              {...field}
                              disabled={isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="end_time"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Koniec aukcji</FormLabel>
                          <FormControl>
                            <Input
                              type="datetime-local"
                              {...field}
                              disabled={isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* ── Akcje ──────────────────────────────────── */}
            <div className="flex gap-3">
              <Button type="submit" disabled={isPending}>
                {isPending
                  ? "Zapisuję…"
                  : isEditing
                    ? "Zapisz zmiany"
                    : "Utwórz ofertę"}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => router.back()}
                disabled={isPending}
              >
                Anuluj
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

// ────────────────────────────────────────────────────────────
// Helper — ISO string → datetime-local value
// ────────────────────────────────────────────────────────────

function toLocalDatetimeValue(iso: string): string {
  const d = new Date(iso);
  const pad = (n: number) => n.toString().padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
