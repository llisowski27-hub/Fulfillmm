// ============================================================
// THE LIQUIDATOR — Admin: Listings Table
// src/components/admin/admin-listings-table.tsx
// ============================================================

"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

import {
  publishListingAction,
  cancelListingAction,
} from "@/actions/listings";
import {
  LISTING_TYPE_LABELS,
  LISTING_STATUS_LABELS,
  type ListingRow,
  type AuctionRow,
  type ListingStatus,
} from "@/types";

// ────────────────────────────────────────────────────────────
// Badge variants per status
// ────────────────────────────────────────────────────────────

const STATUS_VARIANT: Record<ListingStatus, "default" | "secondary" | "destructive" | "outline"> = {
  draft: "outline",
  active: "default",
  sold: "secondary",
  cancelled: "destructive",
};

// ────────────────────────────────────────────────────────────
// Component
// ────────────────────────────────────────────────────────────

interface Props {
  listings: ListingRow[];
  auctions: AuctionRow[];
}

export function AdminListingsTable({ listings, auctions }: Props) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [search, setSearch] = useState("");

  const auctionMap = new Map(auctions.map((a) => [a.listing_id, a]));

  const filtered = listings.filter((l) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      l.title.toLowerCase().includes(q) ||
      l.slug?.toLowerCase().includes(q) ||
      l.category?.toLowerCase().includes(q)
    );
  });

  function handlePublish(id: string, title: string) {
    startTransition(async () => {
      const result = await publishListingAction(id);
      if (!result.success) {
        toast.error("Błąd publikacji", { description: result.error });
        return;
      }
      toast.success("Oferta opublikowana", { description: title });
      router.refresh();
    });
  }

  function handleCancel(id: string, title: string) {
    startTransition(async () => {
      const result = await cancelListingAction(id);
      if (!result.success) {
        toast.error("Błąd anulowania", { description: result.error });
        return;
      }
      toast.success("Oferta anulowana", { description: title });
      router.refresh();
    });
  }

  return (
    <Card>
      <CardContent className="pt-4">
        <div className="mb-4">
          <Input
            placeholder="Szukaj po tytule, slug, kategorii…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-sm"
          />
        </div>

        {filtered.length === 0 ? (
          <p className="py-8 text-center text-sm text-muted-foreground">
            {search ? "Brak wyników." : "Brak ofert."}
          </p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Tytuł</TableHead>
                  <TableHead>Typ</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Cena</TableHead>
                  <TableHead className="text-right">Ilość</TableHead>
                  <TableHead>Aukcja</TableHead>
                  <TableHead className="text-right">Akcje</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((listing) => {
                  const auction = auctionMap.get(listing.id);
                  const price =
                    listing.listing_type === "auction"
                      ? auction?.current_price ?? auction?.starting_price ?? 0
                      : listing.buy_now_price ?? 0;

                  return (
                    <TableRow key={listing.id}>
                      <TableCell>
                        <div className="max-w-[240px]">
                          <p className="text-sm font-medium truncate">
                            {listing.title}
                          </p>
                          {listing.category && (
                            <p className="text-xs text-muted-foreground">
                              {listing.category}
                            </p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            listing.listing_type === "auction"
                              ? "default"
                              : "secondary"
                          }
                          className="text-[11px]"
                        >
                          {LISTING_TYPE_LABELS[listing.listing_type]}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={STATUS_VARIANT[listing.status]}
                          className="text-[11px]"
                        >
                          {LISTING_STATUS_LABELS[listing.status]}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {price.toFixed(2)} zł
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {listing.quantity_available}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {auction ? (
                          <div>
                            <p>{auction.bid_count} bidów</p>
                            <p>
                              {new Date(auction.end_time).toLocaleDateString(
                                "pl-PL"
                              )}
                            </p>
                          </div>
                        ) : (
                          "—"
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() =>
                              router.push(
                                `/admin/listings/${listing.id}/edit`
                              )
                            }
                            disabled={isPending}
                          >
                            Edytuj
                          </Button>
                          {listing.status === "draft" && (
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() =>
                                handlePublish(listing.id, listing.title)
                              }
                              disabled={isPending}
                            >
                              Publikuj
                            </Button>
                          )}
                          {(listing.status === "draft" ||
                            listing.status === "active") && (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-destructive"
                              onClick={() =>
                                handleCancel(listing.id, listing.title)
                              }
                              disabled={isPending}
                            >
                              Anuluj
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
