// ============================================================
// THE LIQUIDATOR — Auction User Status
// src/components/auction/auction-user-status.tsx
// ============================================================
// Wyświetla stan użytkownika w aukcji:
//   - "Prowadzisz" (zielony) — najwyższy bid jest Twój
//   - "Ktoś Cię przebił!" (czerwony) — miałeś bid, przebity
//   - neutralny — nie brałeś udziału
// Aktualizuje się w realtime (dane z hooka).
// ============================================================

"use client";

import type { AuctionRow, BidRow } from "@/types";

interface AuctionUserStatusProps {
  auction: AuctionRow;
  bids: BidRow[];
  userId: string;
}

export type UserAuctionState = "leading" | "outbid" | "neutral";

export function getAuctionUserState(
  auction: AuctionRow,
  bids: BidRow[],
  userId: string
): UserAuctionState {
  const myBids = bids.filter((b) => b.user_id === userId);
  if (myBids.length === 0) return "neutral";

  const winningBid = bids.find((b) => b.is_winning);
  if (winningBid && winningBid.user_id === userId) return "leading";

  return "outbid";
}

export function AuctionUserStatus({
  auction,
  bids,
  userId,
}: AuctionUserStatusProps) {
  const state = getAuctionUserState(auction, bids, userId);

  if (state === "neutral") return null;

  if (state === "leading") {
    return (
      <div className="flex items-center gap-2 rounded-lg bg-green-50 dark:bg-green-950/50 px-3 py-2.5">
        <svg
          className="h-4 w-4 text-green-600 dark:text-green-400 shrink-0"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={2.5}
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        </svg>
        <span className="text-sm font-medium text-green-800 dark:text-green-200">
          Prowadzisz aukcję
        </span>
      </div>
    );
  }

  // outbid
  return (
    <div className="flex items-center gap-2 rounded-lg bg-red-50 dark:bg-red-950/50 px-3 py-2.5">
      <svg
        className="h-4 w-4 text-red-600 dark:text-red-400 shrink-0"
        fill="none"
        viewBox="0 0 24 24"
        strokeWidth={2.5}
        stroke="currentColor"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z"
        />
      </svg>
      <span className="text-sm font-medium text-red-800 dark:text-red-200">
        Ktoś Cię przebił!
      </span>
    </div>
  );
}
