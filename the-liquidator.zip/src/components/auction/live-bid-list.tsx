// ============================================================
// THE LIQUIDATOR — Live Bid List
// src/components/auction/live-bid-list.tsx
// ============================================================
// Lista bidów z animacją wjazdu nowych pozycji.
// Wyróżnia bidy aktualnego użytkownika i zwycięzcę.
// ============================================================

"use client";

import { useEffect, useRef } from "react";
import type { BidRow } from "@/types";

interface LiveBidListProps {
  bids: BidRow[];
  currentUserId: string;
}

export function LiveBidList({ bids, currentUserId }: LiveBidListProps) {
  const listRef = useRef<HTMLUListElement>(null);
  const prevCountRef = useRef(bids.length);

  // Scroll to top gdy pojawi się nowy bid
  useEffect(() => {
    if (bids.length > prevCountRef.current && listRef.current) {
      listRef.current.scrollTop = 0;
    }
    prevCountRef.current = bids.length;
  }, [bids.length]);

  if (bids.length === 0) {
    return (
      <p className="py-6 text-center text-sm text-muted-foreground">
        Brak ofert — bądź pierwszy!
      </p>
    );
  }

  return (
    <ul
      ref={listRef}
      className="space-y-1 max-h-[280px] overflow-y-auto"
      style={{ scrollBehavior: "smooth" }}
    >
      {bids.map((bid, index) => {
        const isMine = bid.user_id === currentUserId;
        const isNewest = index === 0;
        const time = new Date(bid.created_at);

        return (
          <li
            key={bid.id}
            className={`
              flex items-center justify-between rounded-md px-2.5 py-2 text-sm
              transition-all duration-300
              ${isNewest ? "animate-in slide-in-from-top-2 fade-in" : ""}
              ${bid.is_winning ? "bg-green-50 dark:bg-green-950/50" : ""}
              ${isMine && !bid.is_winning ? "bg-blue-50 dark:bg-blue-950/50" : ""}
            `}
          >
            <div className="flex items-center gap-2 min-w-0">
              {/* Pozycja / wskaźnik */}
              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-medium bg-muted">
                {bid.is_winning ? (
                  <svg
                    className="h-3 w-3 text-green-600 dark:text-green-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2.5}
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M4.5 12.75l6 6 9-13.5"
                    />
                  </svg>
                ) : (
                  <span className="text-muted-foreground">
                    {index + 1}
                  </span>
                )}
              </span>

              {/* User indicator */}
              <span className="text-xs text-muted-foreground truncate">
                {isMine ? "Ty" : `Licytujący ${bid.user_id.slice(0, 4)}`}
              </span>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <span
                className={`tabular-nums ${
                  bid.is_winning ? "font-semibold" : ""
                }`}
              >
                {bid.amount.toLocaleString("pl-PL", {
                  minimumFractionDigits: 2,
                })}{" "}
                zł
              </span>
              <time className="text-[11px] text-muted-foreground tabular-nums">
                {time.toLocaleTimeString("pl-PL", {
                  hour: "2-digit",
                  minute: "2-digit",
                  second: "2-digit",
                })}
              </time>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
