// ============================================================
// THE LIQUIDATOR — Live Auction Panel v3
// src/components/auction/live-auction-panel.tsx
// ============================================================
// Layout: stacked cards, clear hierarchy.
// Status colors: green (lead), red (outbid) — minimal.
// ============================================================

"use client";

import { useRealtimeAuction } from "@/hooks/use-realtime-auction";
import { useCountdown } from "@/hooks/use-countdown";
import { useUser } from "@/hooks/use-user";
import { BidForm } from "@/components/auction/bid-form";
import { LiveBidList } from "@/components/auction/live-bid-list";
import {
  AuctionUserStatus,
  getAuctionUserState,
} from "@/components/auction/auction-user-status";
import { Badge } from "@/components/ui/badge";
import type { AuctionRow, BidRow } from "@/types";

interface LiveAuctionPanelProps {
  initialAuction: AuctionRow;
  initialBids: BidRow[];
  buyNowPrice?: number | null;
}

export function LiveAuctionPanel({
  initialAuction,
  initialBids,
  buyNowPrice,
}: LiveAuctionPanelProps) {
  const { userId, isReady } = useUser();

  const { auction, bids, isLive } = useRealtimeAuction({
    auctionId: initialAuction.id,
    initialAuction,
    initialBids,
  });

  const countdown = useCountdown(auction.end_time);
  const displayPrice = auction.current_price ?? auction.starting_price;
  const userState = isReady
    ? getAuctionUserState(auction, bids, userId)
    : "neutral";

  return (
    <div className="space-y-3">
      {/* ── Karta główna: cena + countdown + bid ──────── */}
      <div className="rounded-lg border bg-card p-4 space-y-4">
        {/* Row 1: status + live dot + bid count */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-[11px] leading-none">
              {auction.status === "active"
                ? "Trwa"
                : auction.status === "ended"
                  ? "Zakończona"
                  : auction.status === "scheduled"
                    ? "Zaplanowana"
                    : "Anulowana"}
            </Badge>
            {isLive && (
              <span className="flex items-center gap-1 text-[11px] text-green-600 dark:text-green-400">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-green-500" />
                </span>
                Live
              </span>
            )}
          </div>
          <span className="text-[12px] text-muted-foreground tabular-nums">
            {auction.bid_count} {pluralizeBids(auction.bid_count)}
          </span>
        </div>

        {/* Row 2: user status (prowadzisz / przebity) */}
        <AuctionUserStatus
          auction={auction}
          bids={bids}
          userId={userId}
        />

        {/* Row 3: cena — duża, centrowana */}
        <div className="text-center py-1">
          <p className="text-[12px] text-muted-foreground mb-1">
            Aktualna cena
          </p>
          <p className="text-[36px] leading-none font-bold tabular-nums tracking-tight">
            {displayPrice.toLocaleString("pl-PL", {
              minimumFractionDigits: 2,
            })}
            <span className="text-[16px] font-normal text-muted-foreground ml-1">
              zł
            </span>
          </p>
        </div>

        {/* Row 4: countdown */}
        <div
          className={`text-center py-2.5 rounded-md transition-colors ${
            countdown.isUrgent
              ? "bg-red-50 dark:bg-red-950/60"
              : "bg-muted/60"
          }`}
        >
          <p className="text-[11px] text-muted-foreground mb-0.5">
            {countdown.isExpired
              ? "Aukcja zakończona"
              : countdown.isUrgent
                ? `Kończy się za (${auction.extend_count}/${auction.max_extends} przedłużeń)`
                : "Kończy się za"}
          </p>
          <p
            className={`text-[22px] leading-none font-mono font-bold tabular-nums tracking-widest ${
              countdown.isUrgent
                ? "text-red-600 dark:text-red-400"
                : "text-foreground"
            }`}
          >
            {countdown.formatted}
          </p>
        </div>

        {/* Row 5: bid form */}
        <div className="pt-1">
          {isReady ? (
            <BidForm
              auction={auction}
              userId={userId}
              userState={userState}
            />
          ) : (
            <div className="h-[100px] animate-pulse rounded-md bg-muted" />
          )}
        </div>

        {/* Row 6: buy-it-now (opcjonalnie) */}
        {buyNowPrice && !countdown.isExpired && (
          <div className="border-t pt-3 flex items-center justify-between">
            <span className="text-[13px] text-muted-foreground">
              Kup teraz
            </span>
            <span className="text-[16px] font-semibold tabular-nums">
              {buyNowPrice.toLocaleString("pl-PL", {
                minimumFractionDigits: 2,
              })}{" "}
              zł
            </span>
          </div>
        )}
      </div>

      {/* ── Karta historii bidów ──────────────────────── */}
      <div className="rounded-lg border bg-card p-4">
        <p className="text-[13px] font-medium mb-2">Historia licytacji</p>
        <LiveBidList bids={bids} currentUserId={userId} />
      </div>
    </div>
  );
}

function pluralizeBids(n: number): string {
  if (n === 1) return "oferta";
  if (n >= 2 && n <= 4) return "oferty";
  return "ofert";
}
