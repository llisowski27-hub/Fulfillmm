// ============================================================
// THE LIQUIDATOR — Bid Form v2
// src/components/auction/bid-form.tsx
// ============================================================
// Blokady:
//   - Jeśli user jest highest bidder → zablokowany
//   - Jeśli aukcja wygasła → zablokowany
// Feedback:
//   - Sukces → toast zielony + refresh
//   - Przebity (race condition) → toast z komunikatem + refresh
// ============================================================

"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { placeBidAction } from "@/actions/auctions";
import { type UserAuctionState } from "@/components/auction/auction-user-status";
import type { AuctionRow } from "@/types";

interface BidFormProps {
  auction: AuctionRow;
  userId: string;
  userState: UserAuctionState;
}

export function BidForm({ auction, userId, userState }: BidFormProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();

  const minBid =
    (auction.current_price ?? auction.starting_price) +
    auction.min_bid_increment;

  const [amount, setAmount] = useState(
    Math.ceil(minBid * 100) / 100
  );

  // Aktualizuj minBid gdy cena się zmienia (realtime)
  const currentMin =
    (auction.current_price ?? auction.starting_price) +
    auction.min_bid_increment;

  if (amount < currentMin && !isPending) {
    // Cena wzrosła — zaktualizuj input
    setTimeout(() => setAmount(Math.ceil(currentMin * 100) / 100), 0);
  }

  const isEnded = new Date(auction.end_time) <= new Date();
  const isActive = auction.status === "active" && !isEnded;
  const isLeading = userState === "leading";

  // ── Stany zablokowane ─────────────────────────────────
  if (!isActive) {
    return (
      <div className="rounded-lg border border-dashed p-4 text-center text-sm text-muted-foreground">
        {isEnded
          ? "Aukcja zakończona"
          : auction.status === "scheduled"
            ? "Aukcja jeszcze nie rozpoczęta"
            : "Aukcja nieaktywna"}
      </div>
    );
  }

  if (isLeading) {
    return (
      <div className="rounded-lg border border-green-200 dark:border-green-800 bg-green-50/50 dark:bg-green-950/30 p-4 text-center text-sm">
        <p className="font-medium text-green-800 dark:text-green-200">
          Masz najwyższą ofertę
        </p>
        <p className="text-green-600 dark:text-green-400 text-xs mt-1">
          Poczekaj na wynik lub obserwuj aukcję
        </p>
      </div>
    );
  }

  // ── Aktywny formularz ─────────────────────────────────
  function handleBid() {
    if (amount < currentMin) {
      toast.error("Za niska kwota", {
        description: `Minimalna oferta: ${currentMin.toFixed(2)} zł`,
      });
      return;
    }

    startTransition(async () => {
      const result = await placeBidAction(userId, {
        auction_id: auction.id,
        amount,
      });

      if (!result.success) {
        // Race condition — ktoś wbił się szybciej
        toast.error("Nie udało się zalicytować", {
          description: result.error,
        });
        router.refresh();
        return;
      }

      toast.success("Oferta złożona!", {
        description: `Twoja oferta: ${amount.toFixed(2)} zł`,
      });

      // Nie robimy refresh — Realtime zaktualizuje dane
    });
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <p className="text-sm text-muted-foreground">
          Minimalna oferta:
        </p>
        <p className="text-sm font-medium tabular-nums">
          {currentMin.toFixed(2)} zł
        </p>
      </div>

      <div className="flex gap-2">
        <Input
          type="number"
          step="0.01"
          min={currentMin}
          value={amount}
          onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
          disabled={isPending}
          className="tabular-nums font-mono max-w-[160px]"
        />
        <Button
          onClick={handleBid}
          disabled={isPending || amount < currentMin}
          className="flex-1"
        >
          {isPending ? "Licytuję…" : "Licytuj"}
        </Button>
      </div>

      <div className="flex gap-1.5">
        {[1, 5, 10, 50].map((bump) => (
          <Button
            key={bump}
            size="sm"
            variant="outline"
            className="tabular-nums text-xs"
            disabled={isPending}
            onClick={() =>
              setAmount(Math.ceil((currentMin + bump) * 100) / 100)
            }
          >
            +{bump} zł
          </Button>
        ))}
      </div>
    </div>
  );
}
