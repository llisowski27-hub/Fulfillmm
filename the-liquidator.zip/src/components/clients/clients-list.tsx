// ============================================================
// THE LIQUIDATOR — Clients List
// src/components/clients/clients-list.tsx
// ============================================================

"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

import { archiveClientAction, restoreClientAction } from "@/actions/clients";
import type { ClientRow } from "@/types";

// ────────────────────────────────────────────────────────────
// Props
// ────────────────────────────────────────────────────────────

interface ClientsListProps {
  clients: ClientRow[];
  showArchived?: boolean;
}

// ────────────────────────────────────────────────────────────
// Component
// ────────────────────────────────────────────────────────────

export function ClientsList({ clients, showArchived = false }: ClientsListProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();

  function handleArchive(id: string, nazwa: string) {
    startTransition(async () => {
      const result = await archiveClientAction(id);
      if (!result.success) {
        toast.error("Błąd archiwizacji", { description: result.error });
        return;
      }
      toast.success("Klient zarchiwizowany", { description: nazwa });
      router.refresh();
    });
  }

  function handleRestore(id: string, nazwa: string) {
    startTransition(async () => {
      const result = await restoreClientAction(id);
      if (!result.success) {
        toast.error("Błąd przywracania", { description: result.error });
        return;
      }
      toast.success("Klient przywrócony", { description: nazwa });
      router.refresh();
    });
  }

  if (clients.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <p className="text-muted-foreground">
            {showArchived
              ? "Brak zarchiwizowanych klientów."
              : "Brak klientów. Dodaj pierwszego."}
          </p>
          {!showArchived && (
            <Button
              variant="outline"
              className="mt-4"
              onClick={() => router.push("/clients/new")}
            >
              Dodaj klienta
            </Button>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>
          {showArchived ? "Archiwum klientów" : "Klienci"}
        </CardTitle>
        {!showArchived && (
          <Button size="sm" onClick={() => router.push("/clients/new")}>
            + Dodaj
          </Button>
        )}
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nazwa</TableHead>
              <TableHead>Model</TableHead>
              <TableHead className="text-right">Stawka</TableHead>
              <TableHead>Kontakt</TableHead>
              <TableHead className="text-right">Akcje</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {clients.map((c) => (
              <TableRow key={c.id}>
                <TableCell className="font-medium">{c.nazwa}</TableCell>
                <TableCell>
                  <Badge variant={c.typ_modelu === "komis" ? "default" : "secondary"}>
                    {c.typ_modelu === "komis" ? "Komis" : "Fulfillment"}
                  </Badge>
                </TableCell>
                <TableCell className="text-right tabular-nums">
                  {c.typ_modelu === "komis"
                    ? `${Math.round((c.stawka_prowizji ?? 0) * 100)}%`
                    : `${c.stawka_za_paczke?.toFixed(2)} zł/szt`}
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  {c.email ?? c.telefon ?? "—"}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    {!showArchived && (
                      <>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => router.push(`/clients/${c.id}/edit`)}
                          disabled={isPending}
                        >
                          Edytuj
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-destructive"
                          onClick={() => handleArchive(c.id, c.nazwa)}
                          disabled={isPending}
                        >
                          Archiwizuj
                        </Button>
                      </>
                    )}
                    {showArchived && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleRestore(c.id, c.nazwa)}
                        disabled={isPending}
                      >
                        Przywróć
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
