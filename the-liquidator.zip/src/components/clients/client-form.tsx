// ============================================================
// THE LIQUIDATOR — Client Form (Create / Edit)
// src/components/clients/client-form.tsx
// ============================================================

"use client";

import { useTransition } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { toast } from "sonner";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import {
  createClientSchema,
  type CreateClientInput,
  type ClientRow,
  type TypModelu,
} from "@/types";
import {
  createClientAction,
  updateClientAction,
} from "@/actions/clients";

// ────────────────────────────────────────────────────────────
// Props
// ────────────────────────────────────────────────────────────

interface ClientFormProps {
  /** Przekaż istniejącego klienta → tryb edycji */
  client?: ClientRow;
}

// ────────────────────────────────────────────────────────────
// Defaults
// ────────────────────────────────────────────────────────────

function getDefaults(client?: ClientRow): CreateClientInput {
  if (client) {
    return {
      nazwa: client.nazwa,
      email: client.email,
      telefon: client.telefon,
      typ_modelu: client.typ_modelu,
      stawka_prowizji: client.stawka_prowizji ?? 0,
      stawka_za_paczke: client.stawka_za_paczke ?? 0,
    } as CreateClientInput;
  }
  return {
    nazwa: "",
    email: null,
    telefon: null,
    typ_modelu: "komis" as TypModelu,
    stawka_prowizji: 0.15,
    stawka_za_paczke: null,
  } as CreateClientInput;
}

// ────────────────────────────────────────────────────────────
// Component
// ────────────────────────────────────────────────────────────

export function ClientForm({ client }: ClientFormProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const isEditing = !!client;

  const form = useForm<CreateClientInput>({
    resolver: zodResolver(createClientSchema),
    defaultValues: getDefaults(client),
  });

  const typModelu = form.watch("typ_modelu");

  function onSubmit(values: CreateClientInput) {
    startTransition(async () => {
      const result = isEditing
        ? await updateClientAction(client!.id, values)
        : await createClientAction(values);

      if (!result.success) {
        toast.error("Błąd zapisu", { description: result.error });
        return;
      }

      toast.success(
        isEditing ? "Klient zaktualizowany" : "Klient dodany",
        { description: result.data.nazwa }
      );
      router.push("/clients");
      router.refresh();
    });
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          {isEditing ? `Edycja: ${client.nazwa}` : "Nowy klient"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="grid gap-6"
          >
            {/* ── Nazwa ──────────────────────────────────── */}
            <FormField
              control={form.control}
              name="nazwa"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nazwa klienta</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="np. Jan Kowalski / Firma XYZ"
                      disabled={isPending}
                      autoFocus
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Kontakt ────────────────────────────────── */}
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Email{" "}
                      <span className="text-muted-foreground font-normal">
                        (opcjonalnie)
                      </span>
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        value={field.value ?? ""}
                        onChange={(e) =>
                          field.onChange(e.target.value || null)
                        }
                        placeholder="email@example.com"
                        disabled={isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="telefon"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Telefon{" "}
                      <span className="text-muted-foreground font-normal">
                        (opcjonalnie)
                      </span>
                    </FormLabel>
                    <FormControl>
                      <Input
                        value={field.value ?? ""}
                        onChange={(e) =>
                          field.onChange(e.target.value || null)
                        }
                        placeholder="+48 123 456 789"
                        disabled={isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* ── Model biznesowy ─────────────────────────── */}
            <FormField
              control={form.control}
              name="typ_modelu"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Model współpracy</FormLabel>
                  <Select
                    value={field.value}
                    onValueChange={(v) => {
                      field.onChange(v);
                      // Reset stawek przy zmianie modelu
                      if (v === "komis") {
                        form.setValue("stawka_prowizji", 0.15);
                        form.setValue("stawka_za_paczke", null as unknown as number);
                      } else {
                        form.setValue("stawka_prowizji", null as unknown as number);
                        form.setValue("stawka_za_paczke", 5);
                      }
                    }}
                    disabled={isPending}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="komis">
                        Komis (prowizja od sprzedaży)
                      </SelectItem>
                      <SelectItem value="fulfillment">
                        Fulfillment (stawka za paczkę)
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Stawki (warunkowe) ──────────────────────── */}
            {typModelu === "komis" && (
              <FormField
                control={form.control}
                name="stawka_prowizji"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Prowizja (%)</FormLabel>
                    <FormControl>
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          step="1"
                          min="0"
                          max="100"
                          disabled={isPending}
                          value={
                            field.value != null
                              ? Math.round(field.value * 100)
                              : ""
                          }
                          onChange={(e) => {
                            const pct = parseFloat(e.target.value) || 0;
                            field.onChange(pct / 100);
                          }}
                          className="max-w-[120px]"
                        />
                        <span className="text-sm text-muted-foreground">
                          %
                        </span>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {typModelu === "fulfillment" && (
              <FormField
                control={form.control}
                name="stawka_za_paczke"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Stawka za paczkę (PLN)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        disabled={isPending}
                        value={field.value ?? ""}
                        onChange={(e) =>
                          field.onChange(parseFloat(e.target.value) || 0)
                        }
                        className="max-w-[160px]"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* ── Akcje ──────────────────────────────────── */}
            <div className="flex gap-3">
              <Button type="submit" disabled={isPending}>
                {isPending
                  ? "Zapisuję…"
                  : isEditing
                    ? "Zapisz zmiany"
                    : "Dodaj klienta"}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => router.back()}
                disabled={isPending}
              >
                Anuluj
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
