// ============================================================
// THE LIQUIDATOR — Dashboard Cards
// src/components/dashboard/dashboard-cards.tsx
// ============================================================

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

interface DashboardCardsProps {
  clientCount: number;
  inStock: number;
  sold: number;
  totalValue: number;
  pendingPayoutsCount: number;
  pendingTotal: number;
}

export function DashboardCards({
  clientCount,
  inStock,
  sold,
  totalValue,
  pendingPayoutsCount,
  pendingTotal,
}: DashboardCardsProps) {
  const cards = [
    {
      title: "Klienci",
      value: clientCount.toString(),
      sub: "aktywnych",
    },
    {
      title: "W magazynie",
      value: inStock.toString(),
      sub: `${sold} sprzedanych`,
    },
    {
      title: "Wartość magazynu",
      value: `${totalValue.toLocaleString("pl-PL", { minimumFractionDigits: 2 })} zł`,
      sub: "ceny docelowe",
    },
    {
      title: "Oczekujące wypłaty",
      value: pendingPayoutsCount.toString(),
      sub: `${pendingTotal.toLocaleString("pl-PL", { minimumFractionDigits: 2 })} zł`,
    },
  ];

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {cards.map((card) => (
        <Card key={card.title}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {card.title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold tabular-nums">{card.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{card.sub}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
