// ============================================================
// THE LIQUIDATOR — Pending Payouts (Dashboard Widget)
// src/components/dashboard/pending-payouts.tsx
// ============================================================

"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";

import { markPayoutPaidAction } from "@/actions/payouts";
import type { PayoutRow, ClientRow } from "@/types";

interface PendingPayoutsProps {
  payouts: PayoutRow[];
  clients: ClientRow[];
}

export function PendingPayouts({ payouts, clients }: PendingPayoutsProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();

  const clientMap = new Map(clients.map((c) => [c.id, c.nazwa]));

  function handlePay(id: string, clientName: string, kwota: number) {
    startTransition(async () => {
      const result = await markPayoutPaidAction(id);
      if (!result.success) {
        toast.error("Błąd wypłaty", { description: result.error });
        return;
      }
      toast.success("Wypłata zrealizowana", {
        description: `${clientName} — ${kwota.toFixed(2)} zł`,
      });
      router.refresh();
    });
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Oczekujące wypłaty</CardTitle>
      </CardHeader>
      <CardContent>
        {payouts.length === 0 ? (
          <p className="py-4 text-center text-sm text-muted-foreground">
            Brak oczekujących wypłat.
          </p>
        ) : (
          <ul className="space-y-3">
            {payouts.map((p) => {
              const name = clientMap.get(p.client_id) ?? "Nieznany klient";
              return (
                <li
                  key={p.id}
                  className="flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{name}</p>
                    <p className="text-xs text-muted-foreground tabular-nums">
                      {p.kwota_netto.toLocaleString("pl-PL", {
                        minimumFractionDigits: 2,
                      })}{" "}
                      zł
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={isPending}
                    onClick={() => handlePay(p.id, name, p.kwota_netto)}
                  >
                    {isPending ? "…" : "Wypłać"}
                  </Button>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
