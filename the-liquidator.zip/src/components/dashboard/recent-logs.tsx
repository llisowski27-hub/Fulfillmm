// ============================================================
// THE LIQUIDATOR — Recent Logs (Dashboard Widget)
// src/components/dashboard/recent-logs.tsx
// ============================================================

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { WarehouseLogRow } from "@/types";

const AKCJA_BADGE: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  PRZYJECIE: { label: "Przyjęcie", variant: "default" },
  WYDANIE:   { label: "Wydanie", variant: "secondary" },
  ZWROT:     { label: "Zwrot", variant: "outline" },
  KOREKTA:   { label: "Korekta", variant: "destructive" },
};

interface RecentLogsProps {
  logs: WarehouseLogRow[];
}

export function RecentLogs({ logs }: RecentLogsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Ostatnie operacje</CardTitle>
      </CardHeader>
      <CardContent>
        {logs.length === 0 ? (
          <p className="py-4 text-center text-sm text-muted-foreground">
            Brak operacji magazynowych.
          </p>
        ) : (
          <ul className="space-y-3">
            {logs.map((log) => {
              const badge = AKCJA_BADGE[log.typ_akcji] ?? {
                label: log.typ_akcji,
                variant: "outline" as const,
              };
              const date = new Date(log.created_at);
              return (
                <li
                  key={log.id}
                  className="flex items-start justify-between gap-3 text-sm"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <Badge variant={badge.variant} className="shrink-0">
                      {badge.label}
                    </Badge>
                    {log.notes && (
                      <span className="truncate text-muted-foreground">
                        {log.notes}
                      </span>
                    )}
                  </div>
                  <time
                    dateTime={log.created_at}
                    className="shrink-0 text-xs text-muted-foreground tabular-nums"
                  >
                    {date.toLocaleDateString("pl-PL")}{" "}
                    {date.toLocaleTimeString("pl-PL", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </time>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
