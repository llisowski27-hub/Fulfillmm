// ============================================================
// THE LIQUIDATOR — Navbar v3
// src/components/layout/navbar.tsx
// ============================================================
// Clean spacing, responsive flex-wrap, cart badge.
// ============================================================

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useTransition } from "react";
import { useCart } from "@/components/cart/cart-context";
import { useUser } from "@/hooks/use-user";
import { logoutAction } from "@/actions/auth";

const NAV_LINKS = [
  { href: "/catalog", label: "Katalog" },
  { href: "/admin/listings", label: "Oferty" },
  { href: "/inventory", label: "Magazyn" },
  { href: "/clients", label: "Klienci" },
] as const;

export function Navbar() {
  const pathname = usePathname();
  const { itemCount } = useCart();
  const { isLoggedIn, isReady } = useUser();
  const [isPending, startTransition] = useTransition();

  function handleLogout() {
    startTransition(async () => {
      await logoutAction();
    });
  }

  return (
    <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <nav className="mx-auto max-w-7xl h-14 px-4 sm:px-6 flex items-center justify-between gap-4">
        {/* Logo */}
        <Link
          href="/"
          className="text-[15px] font-bold tracking-tight shrink-0 hover:opacity-80 transition-opacity"
        >
          The Liquidator
        </Link>

        {/* Nav links — wrap on small screens */}
        <div className="flex items-center flex-wrap gap-0.5">
          {NAV_LINKS.map((link) => {
            const isActive =
              pathname === link.href || pathname.startsWith(link.href + "/");
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`px-2.5 py-1.5 rounded-md text-[13px] leading-none transition-colors whitespace-nowrap ${
                  isActive
                    ? "bg-accent text-accent-foreground font-medium"
                    : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
                }`}
              >
                {link.label}
              </Link>
            );
          })}

          {/* Koszyk */}
          <Link
            href="/cart"
            className={`relative px-2.5 py-1.5 rounded-md text-[13px] leading-none transition-colors whitespace-nowrap ml-1 ${
              pathname === "/cart"
                ? "bg-accent text-accent-foreground font-medium"
                : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
            }`}
          >
            Koszyk
            {itemCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-foreground px-1 text-[10px] font-semibold leading-none text-background tabular-nums">
                {itemCount > 99 ? "99+" : itemCount}
              </span>
            )}
          </Link>

          {/* Separator */}
          <div className="w-px h-5 bg-border mx-1.5" />

          {/* Auth */}
          {isReady && (
            <>
              {isLoggedIn ? (
                <>
                  <Link
                    href="/account/bids"
                    className={`px-2.5 py-1.5 rounded-md text-[13px] leading-none transition-colors whitespace-nowrap ${
                      pathname.startsWith("/account")
                        ? "bg-accent text-accent-foreground font-medium"
                        : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
                    }`}
                  >
                    Konto
                  </Link>
                  <button
                    onClick={handleLogout}
                    disabled={isPending}
                    className="px-2.5 py-1.5 rounded-md text-[13px] leading-none text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-colors whitespace-nowrap disabled:opacity-50"
                  >
                    Wyloguj
                  </button>
                </>
              ) : (
                <>
                  <Link
                    href="/login"
                    className="px-2.5 py-1.5 rounded-md text-[13px] leading-none text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-colors whitespace-nowrap"
                  >
                    Zaloguj
                  </Link>
                  <Link
                    href="/register"
                    className="px-2.5 py-1.5 rounded-md text-[13px] leading-none font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors whitespace-nowrap"
                  >
                    Rejestracja
                  </Link>
                </>
              )}
            </>
          )}
        </div>
      </nav>
    </header>
  );
}
