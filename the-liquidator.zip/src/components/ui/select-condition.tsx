// ============================================================
// THE LIQUIDATOR — SelectCondition Component
// src/components/ui/select-condition.tsx
// ============================================================
// Reużywalny <Select> dla pola `stan` (kondycja fizyczna).
// Etykiety i wartości czerpane z STAN_ITEMS / STAN_LABELS
// (single source of truth w src/types/inventory.ts).
//
// Wymaga shadcn/ui: npx shadcn@latest add select
// ============================================================

"use client";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import { STAN_ITEMS, STAN_LABELS, type Stan } from "@/types";

// ────────────────────────────────────────────────────────────
// Props
// ────────────────────────────────────────────────────────────

interface SelectConditionProps {
  /** Aktualnie wybrana wartość */
  value?: Stan;
  /** Callback przy zmianie wyboru */
  onValueChange: (value: Stan) => void;
  /** Placeholder gdy nic nie wybrano */
  placeholder?: string;
  /** Disabled state */
  disabled?: boolean;
  /** Ograniczenie widocznych opcji (np. tylko stany dla zwrotów) */
  allowedValues?: readonly Stan[];
}

// ────────────────────────────────────────────────────────────
// Component
// ────────────────────────────────────────────────────────────

export function SelectCondition({
  value,
  onValueChange,
  placeholder = "Wybierz stan",
  disabled = false,
  allowedValues,
}: SelectConditionProps) {
  const options = allowedValues ?? STAN_ITEMS;

  return (
    <Select
      value={value}
      onValueChange={(v) => onValueChange(v as Stan)}
      disabled={disabled}
    >
      <SelectTrigger>
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        {options.map((stan) => (
          <SelectItem key={stan} value={stan}>
            {STAN_LABELS[stan]}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
