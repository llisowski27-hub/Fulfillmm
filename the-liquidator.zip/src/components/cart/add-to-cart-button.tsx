// ============================================================
// THE LIQUIDATOR — Add to Cart Button
// src/components/cart/add-to-cart-button.tsx
// ============================================================

"use client";

import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useCart } from "@/components/cart/cart-context";
import type { ListingRow } from "@/types";

interface AddToCartButtonProps {
  listing: ListingRow;
  quantity?: number;
}

export function AddToCartButton({
  listing,
  quantity = 1,
}: AddToCartButtonProps) {
  const { addItem, items } = useCart();

  const inCart = items.find((i) => i.listing_id === listing.id);
  const isMaxed =
    inCart && inCart.quantity >= listing.quantity_available;

  function handleAdd() {
    addItem(listing, quantity);
    toast.success("Dodano do koszyka", {
      description: listing.title,
    });
  }

  return (
    <Button
      onClick={handleAdd}
      disabled={isMaxed || listing.quantity_available === 0}
      className="w-full"
    >
      {listing.quantity_available === 0
        ? "Niedostępne"
        : isMaxed
          ? "Maksymalna ilość"
          : "Dodaj do koszyka"}
    </Button>
  );
}
