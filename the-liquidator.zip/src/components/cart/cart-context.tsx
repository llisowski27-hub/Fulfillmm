// ============================================================
// THE LIQUIDATOR — Cart Context
// src/components/cart/cart-context.tsx
// ============================================================
// In-memory koszyk (React Context). Stan resetuje się
// po odświeżeniu strony — na start wystarczające.
// Faza 2: persist do Supabase lub cookies.
// ============================================================

"use client";

import {
  createContext,
  useContext,
  useReducer,
  type ReactNode,
} from "react";
import type { ListingRow, ListingType } from "@/types";

// ────────────────────────────────────────────────────────────
// Types
// ────────────────────────────────────────────────────────────

export interface CartItem {
  listing_id: string;
  title: string;
  unit_price: number;
  quantity: number;
  source_type: ListingType;
  image: string | null;
  max_quantity: number;
}

interface CartState {
  items: CartItem[];
}

type CartAction =
  | { type: "ADD"; listing: ListingRow; quantity?: number }
  | { type: "REMOVE"; listing_id: string }
  | { type: "SET_QUANTITY"; listing_id: string; quantity: number }
  | { type: "CLEAR" };

interface CartContextValue extends CartState {
  addItem: (listing: ListingRow, quantity?: number) => void;
  removeItem: (listingId: string) => void;
  setQuantity: (listingId: string, quantity: number) => void;
  clearCart: () => void;
  itemCount: number;
  total: number;
}

// ────────────────────────────────────────────────────────────
// Reducer
// ────────────────────────────────────────────────────────────

function cartReducer(state: CartState, action: CartAction): CartState {
  switch (action.type) {
    case "ADD": {
      const existing = state.items.find(
        (i) => i.listing_id === action.listing.id
      );
      if (existing) {
        const newQty = Math.min(
          existing.quantity + (action.quantity ?? 1),
          existing.max_quantity
        );
        return {
          items: state.items.map((i) =>
            i.listing_id === action.listing.id
              ? { ...i, quantity: newQty }
              : i
          ),
        };
      }
      return {
        items: [
          ...state.items,
          {
            listing_id: action.listing.id,
            title: action.listing.title,
            unit_price: action.listing.buy_now_price ?? 0,
            quantity: action.quantity ?? 1,
            source_type: action.listing.listing_type,
            image: action.listing.images[0] ?? null,
            max_quantity: action.listing.quantity_available,
          },
        ],
      };
    }
    case "REMOVE":
      return {
        items: state.items.filter((i) => i.listing_id !== action.listing_id),
      };
    case "SET_QUANTITY": {
      if (action.quantity <= 0) {
        return {
          items: state.items.filter(
            (i) => i.listing_id !== action.listing_id
          ),
        };
      }
      return {
        items: state.items.map((i) =>
          i.listing_id === action.listing_id
            ? {
                ...i,
                quantity: Math.min(action.quantity, i.max_quantity),
              }
            : i
        ),
      };
    }
    case "CLEAR":
      return { items: [] };
    default:
      return state;
  }
}

// ────────────────────────────────────────────────────────────
// Context
// ────────────────────────────────────────────────────────────

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(cartReducer, { items: [] });

  const itemCount = state.items.reduce((sum, i) => sum + i.quantity, 0);
  const total = state.items.reduce(
    (sum, i) =>
      sum + Math.round(i.unit_price * i.quantity * 100) / 100,
    0
  );

  const value: CartContextValue = {
    ...state,
    addItem: (listing, quantity) =>
      dispatch({ type: "ADD", listing, quantity }),
    removeItem: (listing_id) =>
      dispatch({ type: "REMOVE", listing_id }),
    setQuantity: (listing_id, quantity) =>
      dispatch({ type: "SET_QUANTITY", listing_id, quantity }),
    clearCart: () => dispatch({ type: "CLEAR" }),
    itemCount,
    total,
  };

  return (
    <CartContext.Provider value={value}>{children}</CartContext.Provider>
  );
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
