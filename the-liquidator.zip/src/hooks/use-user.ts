// ============================================================
// THE LIQUIDATOR — useUser Hook
// src/hooks/use-user.ts
// ============================================================
// Unified user identity:
//   - Zalogowany → user.id z Supabase Auth
//   - Guest → anon UUID z localStorage
//
// Backward compatible — AuctionUserStatus, BidForm,
// LiveBidList działają identycznie dla obu typów.
// ============================================================

"use client";

import { useState, useEffect } from "react";
import { createClient } from "@/lib/supabase/client";

const ANON_STORAGE_KEY = "liquidator_anon_id";

interface UserState {
  userId: string;
  isLoggedIn: boolean;
  email: string | null;
  isReady: boolean;
}

function getOrCreateAnonId(): string {
  let id = localStorage.getItem(ANON_STORAGE_KEY);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(ANON_STORAGE_KEY, id);
  }
  return id;
}

export function useUser(): UserState {
  const [state, setState] = useState<UserState>({
    userId: "",
    isLoggedIn: false,
    email: null,
    isReady: false,
  });

  useEffect(() => {
    const supabase = createClient();

    // Pobierz aktualną sesję
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (user) {
        setState({
          userId: user.id,
          isLoggedIn: true,
          email: user.email ?? null,
          isReady: true,
        });
      } else {
        setState({
          userId: getOrCreateAnonId(),
          isLoggedIn: false,
          email: null,
          isReady: true,
        });
      }
    });

    // Nasłuchuj zmian sesji (login/logout)
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        setState({
          userId: session.user.id,
          isLoggedIn: true,
          email: session.user.email ?? null,
          isReady: true,
        });
      } else {
        setState({
          userId: getOrCreateAnonId(),
          isLoggedIn: false,
          email: null,
          isReady: true,
        });
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  return state;
}
