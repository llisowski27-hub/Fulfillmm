// ============================================================
// THE LIQUIDATOR — useRealtimeAuction Hook
// src/hooks/use-realtime-auction.ts
// ============================================================
// Subskrybuje zmiany w auctions i bids przez Supabase
// Realtime. Zwraca live dane aukcji i listę bidów
// bez potrzeby odświeżania strony.
//
// Dwa kanały:
//   1. auctions table → UPDATE na wierszu aukcji
//      (current_price, bid_count, winning_bid_id, status)
//   2. bids table → INSERT nowych bidów
// ============================================================

"use client";

import { useEffect, useState, useCallback } from "react";
import { createClient } from "@/lib/supabase/client";
import type { AuctionRow, BidRow } from "@/types";

interface UseRealtimeAuctionOptions {
  auctionId: string;
  initialAuction: AuctionRow;
  initialBids: BidRow[];
}

interface UseRealtimeAuctionReturn {
  auction: AuctionRow;
  bids: BidRow[];
  isLive: boolean;
}

export function useRealtimeAuction({
  auctionId,
  initialAuction,
  initialBids,
}: UseRealtimeAuctionOptions): UseRealtimeAuctionReturn {
  const [auction, setAuction] = useState<AuctionRow>(initialAuction);
  const [bids, setBids] = useState<BidRow[]>(initialBids);
  const [isLive, setIsLive] = useState(false);

  const handleAuctionUpdate = useCallback(
    (payload: { new: Record<string, unknown> }) => {
      const updated = payload.new as unknown as AuctionRow;
      if (updated.id === auctionId) {
        setAuction(updated);
      }
    },
    [auctionId]
  );

  const handleNewBid = useCallback(
    (payload: { new: Record<string, unknown> }) => {
      const newBid = payload.new as unknown as BidRow;
      if (newBid.auction_id === auctionId) {
        setBids((prev) => {
          // Deduplikacja — bid mógł przyjść z SSR refresh
          if (prev.some((b) => b.id === newBid.id)) return prev;
          // Aktualizuj is_winning na poprzednich bidach
          const updated = prev.map((b) => ({
            ...b,
            is_winning: false,
          }));
          return [newBid, ...updated];
        });
      }
    },
    [auctionId]
  );

  useEffect(() => {
    const supabase = createClient();

    const channel = supabase
      .channel(`auction:${auctionId}`)
      // Nasłuchuj UPDATE na wierszu aukcji
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "auctions",
          filter: `id=eq.${auctionId}`,
        },
        handleAuctionUpdate
      )
      // Nasłuchuj INSERT nowych bidów
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "bids",
          filter: `auction_id=eq.${auctionId}`,
        },
        handleNewBid
      )
      .subscribe((status) => {
        setIsLive(status === "SUBSCRIBED");
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [auctionId, handleAuctionUpdate, handleNewBid]);

  return { auction, bids, isLive };
}
