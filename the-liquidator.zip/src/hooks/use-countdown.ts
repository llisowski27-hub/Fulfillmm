// ============================================================
// THE LIQUIDATOR — useCountdown Hook
// src/hooks/use-countdown.ts
// ============================================================
// Precyzyjny countdown do końca aukcji.
// Aktualizuje się co sekundę, zwraca structured time
// i flagi isExpired / isUrgent (< 5 min).
// ============================================================

"use client";

import { useEffect, useState } from "react";

interface CountdownResult {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isExpired: boolean;
  isUrgent: boolean;
  formatted: string;
}

export function useCountdown(endTime: string): CountdownResult {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  const diff = new Date(endTime).getTime() - now;
  const isExpired = diff <= 0;
  const isUrgent = diff > 0 && diff <= 5 * 60 * 1000;

  if (isExpired) {
    return {
      days: 0,
      hours: 0,
      minutes: 0,
      seconds: 0,
      isExpired: true,
      isUrgent: false,
      formatted: "Zakończona",
    };
  }

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diff / (1000 * 60)) % 60);
  const seconds = Math.floor((diff / 1000) % 60);

  const pad = (n: number) => n.toString().padStart(2, "0");

  let formatted: string;
  if (days > 0) {
    formatted = `${days}d ${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
  } else {
    formatted = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
  }

  return { days, hours, minutes, seconds, isExpired, isUrgent, formatted };
}
