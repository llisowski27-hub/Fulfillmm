// ============================================================
// THE LIQUIDATOR — Supabase Server Client
// src/lib/supabase/server.ts
// ============================================================
// SSR helper for Next.js 15 App Router (Server Components,
// Server Actions, Route Handlers).
//
// Wymaga zmiennych środowiskowych:
//   NEXT_PUBLIC_SUPABASE_URL
//   NEXT_PUBLIC_SUPABASE_ANON_KEY
//
// Setup: npm install @supabase/supabase-js @supabase/ssr
// ============================================================

import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            );
          } catch {
            // `setAll` rzuci w Server Components (read-only).
            // Bezpieczne do zignorowania — cookies ustawiają się
            // tylko w Server Actions i Route Handlers.
          }
        },
      },
    }
  );
}
