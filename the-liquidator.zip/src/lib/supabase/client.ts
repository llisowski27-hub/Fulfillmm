// ============================================================
// THE LIQUIDATOR — Supabase Browser Client
// src/lib/supabase/client.ts
// ============================================================
// Dla Client Components (useEffect, event handlers).
// Singleton — jedna instancja na sesję przeglądarki.
//
// Setup: npm install @supabase/supabase-js @supabase/ssr
// ============================================================

import { createBrowserClient } from "@supabase/ssr";

export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
