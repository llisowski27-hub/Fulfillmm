// ============================================================
// THE LIQUIDATOR — Rate Limiter
// src/lib/rate-limit.ts
// ============================================================
// In-memory rate limiter. Prosty, zero zależności.
// Na start wystarczy — przy skali migruj do Redis.
// ============================================================

const store = new Map<string, { count: number; resetAt: number }>();

// Cleanup co 60s — nie pozwól mapie rosnąć w nieskończoność
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of store) {
    if (entry.resetAt <= now) store.delete(key);
  }
}, 60_000);

interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  retryAfterMs: number;
}

/**
 * Sprawdź rate limit dla danego klucza.
 * @param key — np. `bid:${userId}`
 * @param maxRequests — max zapytań w oknie
 * @param windowMs — okno czasowe w ms
 */
export function checkRateLimit(
  key: string,
  maxRequests: number,
  windowMs: number
): RateLimitResult {
  const now = Date.now();
  const entry = store.get(key);

  if (!entry || entry.resetAt <= now) {
    store.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: maxRequests - 1, retryAfterMs: 0 };
  }

  if (entry.count >= maxRequests) {
    return {
      allowed: false,
      remaining: 0,
      retryAfterMs: entry.resetAt - now,
    };
  }

  entry.count++;
  return {
    allowed: true,
    remaining: maxRequests - entry.count,
    retryAfterMs: 0,
  };
}
