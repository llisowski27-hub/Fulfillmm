// ============================================================
// THE LIQUIDATOR — Auth Helpers
// src/lib/auth.ts
// ============================================================
// Pobieranie sesji użytkownika w Server Components i Actions.
// Jedno miejsce — zero duplikacji.
// ============================================================

import { createClient } from "@/lib/supabase/server";

export interface AuthUser {
  id: string;
  email: string;
}

/**
 * Pobiera zalogowanego użytkownika z sesji Supabase.
 * Zwraca null jeśli niezalogowany — nie rzuca błędu.
 */
export async function getCurrentUser(): Promise<AuthUser | null> {
  try {
    const supabase = await createClient();
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser();

    if (error || !user) return null;

    return {
      id: user.id,
      email: user.email ?? "",
    };
  } catch {
    return null;
  }
}

/**
 * Wymaga zalogowanego użytkownika.
 * Rzuca błąd jeśli niezalogowany — do użycia w Server Actions.
 */
export async function requireUser(): Promise<AuthUser> {
  const user = await getCurrentUser();
  if (!user) {
    throw new Error("Musisz być zalogowany");
  }
  return user;
}
