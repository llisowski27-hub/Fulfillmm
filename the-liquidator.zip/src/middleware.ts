// ============================================================
// THE LIQUIDATOR — Middleware
// src/middleware.ts
// ============================================================
// Odświeża sesję Supabase Auth przy każdym request.
// Bez tego sesja wygaśnie po godzinie i Server Components
// nie rozpoznają zalogowanego użytkownika.
// ============================================================

import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value)
          );
          supabaseResponse = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          );
        },
      },
    }
  );

  // Odśwież sesję — WAŻNE: nie usuwaj tego
  await supabase.auth.getUser();

  return supabaseResponse;
}

export const config = {
  matcher: [
    // Matchuj wszystko oprócz statycznych plików i _next
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};
