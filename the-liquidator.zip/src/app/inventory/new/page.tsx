// ============================================================
// THE LIQUIDATOR — Przyjęcie towaru (strona)
// src/app/inventory/new/page.tsx
// ============================================================

import { redirect } from "next/navigation";
import { getClientsAction } from "@/actions/clients";
import { AddItemForm } from "@/components/inventory/add-item-form";

export const metadata = {
  title: "Przyjęcie towaru | The Liquidator",
};

export default async function NewInventoryItemPage() {
  const result = await getClientsAction();

  if (!result.success) {
    // Brak klientów = brak sensu pokazywania formularza
    redirect("/clients");
  }

  if (result.data.length === 0) {
    return (
      <main className="mx-auto max-w-2xl p-6">
        <div className="rounded-lg border border-dashed p-8 text-center">
          <h2 className="text-lg font-semibold">Brak klientów</h2>
          <p className="mt-1 text-muted-foreground">
            Dodaj pierwszego klienta, zanim zaczniesz przyjmować towar.
          </p>
          <a
            href="/clients"
            className="mt-4 inline-block text-sm underline"
          >
            Przejdź do klientów →
          </a>
        </div>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-2xl p-6">
      <AddItemForm clients={result.data} />
    </main>
  );
}
