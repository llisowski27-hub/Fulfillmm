// ============================================================
// THE LIQUIDATOR — Inventory Page
// src/app/inventory/page.tsx
// ============================================================

import { getInventoryItemsAction } from "@/actions/inventory";
import { getClientsAction } from "@/actions/clients";
import { InventoryList } from "@/components/inventory/inventory-list";

export const metadata = { title: "Magazyn | The Liquidator" };

export default async function InventoryPage() {
  const [itemsResult, clientsResult] = await Promise.all([
    getInventoryItemsAction(),
    getClientsAction(),
  ]);

  const items = itemsResult.success ? itemsResult.data : [];
  const clients = clientsResult.success ? clientsResult.data : [];

  return (
    <main className="mx-auto max-w-6xl p-6">
      <InventoryList items={items} clients={clients} />
    </main>
  );
}
