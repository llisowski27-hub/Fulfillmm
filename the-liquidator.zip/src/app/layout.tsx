// ============================================================
// THE LIQUIDATOR — Root Layout
// src/app/layout.tsx
// ============================================================

import type { ReactNode } from "react";
import { Toaster } from "sonner";
import { CartProvider } from "@/components/cart/cart-context";
import { Navbar } from "@/components/layout/navbar";
import "./globals.css";

export const metadata = {
  title: "The Liquidator",
  description: "Mikro-fulfillment & komis — marketplace",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pl" suppressHydrationWarning>
      <body>
        <CartProvider>
          <Navbar />
          {children}
          <Toaster position="bottom-right" richColors />
        </CartProvider>
      </body>
    </html>
  );
}
