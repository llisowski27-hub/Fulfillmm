// ============================================================
// THE LIQUIDATOR — Dashboard
// src/app/page.tsx
// ============================================================

import Link from "next/link";
import { getClientsAction } from "@/actions/clients";
import { getInventoryItemsAction } from "@/actions/inventory";
import { getWarehouseLogsAction } from "@/actions/warehouse-logs";
import { getPayoutsAction } from "@/actions/payouts";
import { DashboardCards } from "@/components/dashboard/dashboard-cards";
import { RecentLogs } from "@/components/dashboard/recent-logs";
import { PendingPayouts } from "@/components/dashboard/pending-payouts";

export const metadata = { title: "Dashboard | The Liquidator" };

export default async function DashboardPage() {
  const [clientsRes, inventoryRes, logsRes, payoutsRes] = await Promise.all([
    getClientsAction(),
    getInventoryItemsAction(),
    getWarehouseLogsAction(),
    getPayoutsAction(),
  ]);

  const clients = clientsRes.success ? clientsRes.data : [];
  const items = inventoryRes.success ? inventoryRes.data : [];
  const logs = logsRes.success ? logsRes.data : [];
  const payouts = payoutsRes.success ? payoutsRes.data : [];

  // ── Agregacje ───────────────────────────────────────────
  const inStock = items.filter((i) => i.status === "w_magazynie").length;
  const sold = items.filter((i) => i.status === "sprzedane").length;
  const totalValue = items
    .filter((i) => i.status === "w_magazynie")
    .reduce((sum, i) => sum + i.cena_docelowa, 0);
  const pendingPayouts = payouts.filter((p) => p.status === "oczekujace");
  const pendingTotal = pendingPayouts.reduce((sum, p) => sum + p.kwota_netto, 0);

  return (
    <main className="mx-auto max-w-6xl p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <div className="flex gap-2">
          <Link
            href="/inventory/new"
            className="inline-flex items-center rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
          >
            + Przyjmij towar
          </Link>
          <Link
            href="/clients/new"
            className="inline-flex items-center rounded-md border px-3 py-2 text-sm font-medium hover:bg-accent"
          >
            + Nowy klient
          </Link>
        </div>
      </div>

      <DashboardCards
        clientCount={clients.length}
        inStock={inStock}
        sold={sold}
        totalValue={totalValue}
        pendingPayoutsCount={pendingPayouts.length}
        pendingTotal={pendingTotal}
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <RecentLogs logs={logs.slice(0, 10)} />
        <PendingPayouts payouts={pendingPayouts} clients={clients} />
      </div>
    </main>
  );
}
