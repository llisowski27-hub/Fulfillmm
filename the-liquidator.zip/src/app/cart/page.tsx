// ============================================================
// THE LIQUIDATOR — Cart Page
// src/app/cart/page.tsx
// ============================================================

"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useCart } from "@/components/cart/cart-context";

export default function CartPage() {
  const { items, removeItem, setQuantity, total, itemCount } =
    useCart();

  if (items.length === 0) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-2">Koszyk jest pusty</h1>
        <p className="text-muted-foreground mb-6">
          Przejrzyj katalog i dodaj produkty.
        </p>
        <Link href="/catalog">
          <Button variant="outline">Przejdź do katalogu</Button>
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-3xl px-4 py-6 sm:px-6">
      <h1 className="text-2xl font-bold tracking-tight mb-6">
        Koszyk ({itemCount})
      </h1>

      <div className="grid gap-6 lg:grid-cols-[1fr_280px]">
        {/* Lista pozycji */}
        <div className="space-y-3">
          {items.map((item) => (
            <Card key={item.listing_id}>
              <CardContent className="flex items-center gap-4 py-4">
                {/* Miniatura */}
                <div className="h-16 w-16 shrink-0 overflow-hidden rounded-md bg-muted">
                  {item.image ? (
                    <img
                      src={item.image}
                      alt={item.title}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="h-full w-full flex items-center justify-center text-xs text-muted-foreground">
                      —
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">
                    {item.title}
                  </p>
                  <p className="text-sm text-muted-foreground tabular-nums">
                    {item.unit_price.toLocaleString("pl-PL", {
                      minimumFractionDigits: 2,
                    })}{" "}
                    zł / szt.
                  </p>
                </div>

                {/* Ilość */}
                <Input
                  type="number"
                  min={1}
                  max={item.max_quantity}
                  value={item.quantity}
                  onChange={(e) =>
                    setQuantity(
                      item.listing_id,
                      parseInt(e.target.value) || 1
                    )
                  }
                  className="w-16 tabular-nums text-center"
                />

                {/* Suma + usuń */}
                <div className="text-right shrink-0">
                  <p className="text-sm font-medium tabular-nums">
                    {(
                      Math.round(item.unit_price * item.quantity * 100) /
                      100
                    ).toLocaleString("pl-PL", {
                      minimumFractionDigits: 2,
                    })}{" "}
                    zł
                  </p>
                  <button
                    onClick={() => removeItem(item.listing_id)}
                    className="text-xs text-destructive hover:underline mt-1"
                  >
                    Usuń
                  </button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Podsumowanie */}
        <Card className="h-fit lg:sticky lg:top-6">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Podsumowanie</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">
                Produkty ({itemCount})
              </span>
              <span className="tabular-nums font-medium">
                {total.toLocaleString("pl-PL", {
                  minimumFractionDigits: 2,
                })}{" "}
                zł
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Dostawa</span>
              <span className="text-muted-foreground text-xs">
                Obliczona w checkout
              </span>
            </div>
            <div className="border-t pt-3 flex justify-between">
              <span className="font-semibold">Razem</span>
              <span className="font-semibold tabular-nums">
                {total.toLocaleString("pl-PL", {
                  minimumFractionDigits: 2,
                })}{" "}
                zł
              </span>
            </div>
            <Link href="/checkout" className="block">
              <Button className="w-full">Przejdź do kasy</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
