// ============================================================
// THE LIQUIDATOR — Catalog Page
// src/app/catalog/page.tsx
// ============================================================

import { Suspense } from "react";
import { getListingsAction } from "@/actions/listings";
import { getAuctionsAction } from "@/actions/auctions";
import { ProductCard } from "@/components/catalog/product-card";
import { CatalogFilters } from "@/components/catalog/catalog-filters";
import { EndingSoon } from "@/components/catalog/ending-soon";
import type { ListingFilter, ListingType } from "@/types";

export const metadata = { title: "Katalog | The Liquidator" };

interface Props {
  searchParams: Promise<{
    type?: string;
    category?: string;
    q?: string;
    min?: string;
    max?: string;
  }>;
}

export default async function CatalogPage({ searchParams }: Props) {
  const params = await searchParams;

  // Buduj filtr z search params
  const filters: ListingFilter = {};
  if (params.type && (params.type === "buy_now" || params.type === "auction")) {
    filters.listing_type = params.type as ListingType;
  }
  if (params.category) filters.category = params.category;
  if (params.q) filters.search = params.q;
  if (params.min) filters.min_price = parseFloat(params.min);
  if (params.max) filters.max_price = parseFloat(params.max);

  const [listingsRes, auctionsRes] = await Promise.all([
    getListingsAction(Object.keys(filters).length > 0 ? filters : undefined),
    getAuctionsAction({ status: "active" }),
  ]);

  const listings = listingsRes.success ? listingsRes.data : [];
  const auctions = auctionsRes.success ? auctionsRes.data : [];

  // Mapa aukcji po listing_id
  const auctionMap = new Map(auctions.map((a) => [a.listing_id, a]));

  // Unikalne kategorie do filtrów
  const categories = [
    ...new Set(listings.map((l) => l.category).filter(Boolean)),
  ] as string[];

  return (
    <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Katalog</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {listings.length}{" "}
            {listings.length === 1 ? "oferta" : "ofert"}
          </p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[240px_1fr]">
        {/* Sidebar — filtry */}
        <aside className="hidden lg:block">
          <div className="sticky top-6">
            <Suspense>
              <CatalogFilters categories={categories} />
            </Suspense>
          </div>
        </aside>

        {/* Grid produktów */}
        <div>
          {/* Sekcja: Kończy się wkrótce */}
          <EndingSoon
            listings={listings}
            auctions={auctions}
          />

          {listings.length === 0 ? (
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <p className="text-muted-foreground">
                Brak ofert spełniających kryteria.
              </p>
              {Object.keys(filters).length > 0 && (
                <a
                  href="/catalog"
                  className="mt-2 inline-block text-sm underline"
                >
                  Wyczyść filtry
                </a>
              )}
            </div>
          </div>
        ) : (
          <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 xl:grid-cols-4">
            {listings.map((listing) => (
              <ProductCard
                key={listing.id}
                listing={listing}
                auction={auctionMap.get(listing.id)}
              />
            ))}
          </div>
        )}
        </div>
      </div>
    </main>
  );
}
