// ============================================================
// THE LIQUIDATOR — Login Page
// src/app/login/page.tsx
// ============================================================

"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { loginAction } from "@/actions/auth";

export default function LoginPage() {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    startTransition(async () => {
      const result = await loginAction({ email, password });
      if (!result.success) {
        toast.error("Błąd logowania", { description: result.error });
        return;
      }
      toast.success("Zalogowano");
      router.push("/");
      router.refresh();
    });
  }

  return (
    <main className="mx-auto max-w-sm px-4 py-16">
      <Card>
        <CardHeader>
          <CardTitle className="text-center">Zaloguj się</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">
                Email
              </label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="twoj@email.pl"
                required
                disabled={isPending}
                autoFocus
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">
                Hasło
              </label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Min 6 znaków"
                required
                minLength={6}
                disabled={isPending}
              />
            </div>
            <Button type="submit" className="w-full" disabled={isPending}>
              {isPending ? "Loguję…" : "Zaloguj się"}
            </Button>
          </form>
          <p className="text-center text-sm text-muted-foreground mt-4">
            Nie masz konta?{" "}
            <Link href="/register" className="underline hover:text-foreground">
              Zarejestruj się
            </Link>
          </p>
        </CardContent>
      </Card>
    </main>
  );
}
