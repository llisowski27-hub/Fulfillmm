// ============================================================
// THE LIQUIDATOR — Product Page
// src/app/product/[slug]/page.tsx
// ============================================================

import { notFound } from "next/navigation";
import {
  getListingBySlugAction,
  getListingByIdAction,
} from "@/actions/listings";
import {
  getAuctionByListingAction,
  getBidsForAuctionAction,
} from "@/actions/auctions";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { LiveAuctionPanel } from "@/components/auction/live-auction-panel";
import { AddToCartButton } from "@/components/cart/add-to-cart-button";
import {
  LISTING_TYPE_LABELS,
  type AuctionRow,
  type BidRow,
} from "@/types";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props) {
  const { slug } = await params;
  const res = await getListingBySlugAction(slug).catch(() =>
    getListingByIdAction(slug)
  );
  const title = res.success ? res.data.title : "Produkt";
  return { title: `${title} | The Liquidator` };
}

export default async function ProductPage({ params }: Props) {
  const { slug } = await params;

  // Próbuj slug, fallback na ID
  let listingRes = await getListingBySlugAction(slug);
  if (!listingRes.success) {
    listingRes = await getListingByIdAction(slug);
  }
  if (!listingRes.success) notFound();

  const listing = listingRes.data;
  const isAuction = listing.listing_type === "auction";

  let auction: AuctionRow | null = null;
  let bids: BidRow[] = [];

  if (isAuction) {
    const [aRes, bRes] = await Promise.all([
      getAuctionByListingAction(listing.id),
      getAuctionByListingAction(listing.id).then((a) =>
        a.success ? getBidsForAuctionAction(a.data.id) : { success: false as const, data: [], error: "" }
      ),
    ]);
    auction = aRes.success ? aRes.data : null;
    bids = bRes.success ? bRes.data : [];
  }

  const displayPrice = isAuction
    ? auction?.current_price ?? auction?.starting_price ?? 0
    : listing.buy_now_price ?? 0;

  return (
    <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      <div className="grid gap-8 lg:grid-cols-[1fr_380px]">
        {/* Lewa kolumna — zdjęcia */}
        <div>
          {listing.images.length > 0 ? (
            <div className="space-y-3">
              <div className="aspect-square overflow-hidden rounded-lg bg-muted">
                <img
                  src={listing.images[0]}
                  alt={listing.title}
                  className="h-full w-full object-cover"
                />
              </div>
              {listing.images.length > 1 && (
                <div className="grid grid-cols-4 gap-2">
                  {listing.images.slice(1, 5).map((img, i) => (
                    <div
                      key={i}
                      className="aspect-square overflow-hidden rounded-md bg-muted"
                    >
                      <img
                        src={img}
                        alt={`${listing.title} ${i + 2}`}
                        className="h-full w-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="aspect-square rounded-lg bg-muted flex items-center justify-center text-muted-foreground">
              Brak zdjęcia
            </div>
          )}

          {/* Opis */}
          {listing.description && (
            <div className="mt-6">
              <h2 className="text-lg font-semibold mb-2">Opis</h2>
              <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line">
                {listing.description}
              </p>
            </div>
          )}
        </div>

        {/* Prawa kolumna — info + akcje */}
        <div className="space-y-4">
          {/* Tytuł + badge */}
          <div>
            <div className="flex gap-2 mb-2">
              <Badge variant={isAuction ? "default" : "secondary"}>
                {LISTING_TYPE_LABELS[listing.listing_type]}
              </Badge>
              {listing.category && (
                <Badge variant="outline">{listing.category}</Badge>
              )}
            </div>
            <h1 className="text-xl font-bold leading-tight">
              {listing.title}
            </h1>
          </div>

          {/* Cena / Aukcja */}
          {isAuction && auction ? (
            <LiveAuctionPanel
              initialAuction={auction}
              initialBids={bids}
              buyNowPrice={listing.buy_now_price}
            />
          ) : (
            <Card>
              <CardContent className="pt-4 space-y-3">
                <p className="text-3xl font-bold tabular-nums">
                  {displayPrice.toLocaleString("pl-PL", {
                    minimumFractionDigits: 2,
                  })}{" "}
                  <span className="text-base font-normal text-muted-foreground">
                    zł
                  </span>
                </p>
                <p className="text-xs text-muted-foreground">
                  Dostępne: {listing.quantity_available} szt.
                </p>
                <AddToCartButton listing={listing} />
              </CardContent>
            </Card>
          )}

          {/* Tagi */}
          {listing.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {listing.tags.map((tag) => (
                <Badge
                  key={tag}
                  variant="outline"
                  className="text-[11px] font-normal"
                >
                  {tag}
                </Badge>
              ))}
            </div>
          )}

        </div>
      </div>
    </main>
  );
}
