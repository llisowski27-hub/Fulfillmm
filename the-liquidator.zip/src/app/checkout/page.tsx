// ============================================================
// THE LIQUIDATOR — Checkout Page
// src/app/checkout/page.tsx
// ============================================================

"use client";

import Link from "next/link";
import { useCart } from "@/components/cart/cart-context";
import { CheckoutForm } from "@/components/checkout/checkout-form";
import { Button } from "@/components/ui/button";

export default function CheckoutPage() {
  const { items } = useCart();

  if (items.length === 0) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-2">
          Nie masz nic w koszyku
        </h1>
        <p className="text-muted-foreground mb-6">
          Dodaj produkty, żeby przejść do kasy.
        </p>
        <Link href="/catalog">
          <Button variant="outline">Przejdź do katalogu</Button>
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6">
      <div className="flex items-center gap-3 mb-6">
        <Link
          href="/cart"
          className="text-sm text-muted-foreground hover:text-foreground"
        >
          Koszyk
        </Link>
        <span className="text-muted-foreground">/</span>
        <h1 className="text-2xl font-bold tracking-tight">Kasa</h1>
      </div>

      <CheckoutForm />
    </main>
  );
}
