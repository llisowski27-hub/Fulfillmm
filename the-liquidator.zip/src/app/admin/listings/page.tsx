// ============================================================
// THE LIQUIDATOR — Admin: Lista Listingów
// src/app/admin/listings/page.tsx
// ============================================================

import Link from "next/link";
import { getAdminListingsAction } from "@/actions/listings";
import { getAuctionsAction } from "@/actions/auctions";
import { AdminListingsTable } from "@/components/admin/admin-listings-table";
import { Button } from "@/components/ui/button";

export const metadata = { title: "Oferty | Admin | The Liquidator" };

export default async function AdminListingsPage() {
  const [listingsRes, auctionsRes] = await Promise.all([
    getAdminListingsAction(),
    getAuctionsAction(),
  ]);

  const listings = listingsRes.success ? listingsRes.data : [];
  const auctions = auctionsRes.success ? auctionsRes.data : [];

  return (
    <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Oferty</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {listings.length} ofert łącznie
          </p>
        </div>
        <Link href="/admin/listings/new">
          <Button>+ Nowa oferta</Button>
        </Link>
      </div>

      <AdminListingsTable listings={listings} auctions={auctions} />
    </main>
  );
}
