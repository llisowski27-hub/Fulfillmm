// ============================================================
// THE LIQUIDATOR — Admin: Edycja oferty
// src/app/admin/listings/[id]/edit/page.tsx
// ============================================================

import { notFound } from "next/navigation";
import { getListingByIdAction } from "@/actions/listings";
import { getAuctionByListingAction } from "@/actions/auctions";
import { getInventoryItemsAction } from "@/actions/inventory";
import { ListingForm } from "@/components/admin/listing-form";

export const metadata = { title: "Edycja oferty | Admin | The Liquidator" };

interface Props {
  params: Promise<{ id: string }>;
}

export default async function EditListingPage({ params }: Props) {
  const { id } = await params;

  const [listingRes, itemsRes] = await Promise.all([
    getListingByIdAction(id),
    getInventoryItemsAction(),
  ]);

  if (!listingRes.success) notFound();

  const listing = listingRes.data;
  const items = itemsRes.success ? itemsRes.data : [];

  // Pobierz aukcję jeśli listing jest typu auction
  let auction = undefined;
  if (listing.listing_type === "auction") {
    const aRes = await getAuctionByListingAction(listing.id);
    auction = aRes.success ? aRes.data : undefined;
  }

  const inventoryItems = items.map((i) => ({
    id: i.id,
    sku: i.sku,
    nazwa: i.nazwa,
  }));

  return (
    <main className="mx-auto max-w-3xl px-4 py-6 sm:px-6">
      <ListingForm
        inventoryItems={inventoryItems}
        listing={listing}
        auction={auction}
      />
    </main>
  );
}
