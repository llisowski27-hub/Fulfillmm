// ============================================================
// THE LIQUIDATOR — Admin: Nowa oferta
// src/app/admin/listings/new/page.tsx
// ============================================================

import { getInventoryItemsAction } from "@/actions/inventory";
import { ListingForm } from "@/components/admin/listing-form";

export const metadata = { title: "Nowa oferta | Admin | The Liquidator" };

export default async function NewListingPage() {
  const result = await getInventoryItemsAction({ status: "w_magazynie" });
  const items = result.success ? result.data : [];

  const inventoryItems = items.map((i) => ({
    id: i.id,
    sku: i.sku,
    nazwa: i.nazwa,
  }));

  if (inventoryItems.length === 0) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-2">Brak przedmiotów</h1>
        <p className="text-muted-foreground mb-6">
          Najpierw przyjmij towar do magazynu.
        </p>
        <a href="/inventory/new" className="text-sm underline">
          Przyjmij towar
        </a>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-3xl px-4 py-6 sm:px-6">
      <ListingForm inventoryItems={inventoryItems} />
    </main>
  );
}
