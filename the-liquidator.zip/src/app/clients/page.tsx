// ============================================================
// THE LIQUIDATOR — Clients Page
// src/app/clients/page.tsx
// ============================================================

import { getClientsAction } from "@/actions/clients";
import { ClientsList } from "@/components/clients/clients-list";

export const metadata = { title: "Klienci | The Liquidator" };

export default async function ClientsPage() {
  const result = await getClientsAction();
  const clients = result.success ? result.data : [];

  return (
    <main className="mx-auto max-w-5xl p-6">
      <ClientsList clients={clients} />
    </main>
  );
}
