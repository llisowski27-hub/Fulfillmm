// ============================================================
// THE LIQUIDATOR — New Client Page
// src/app/clients/new/page.tsx
// ============================================================

import { ClientForm } from "@/components/clients/client-form";

export const metadata = { title: "Nowy klient | The Liquidator" };

export default function NewClientPage() {
  return (
    <main className="mx-auto max-w-2xl p-6">
      <ClientForm />
    </main>
  );
}
