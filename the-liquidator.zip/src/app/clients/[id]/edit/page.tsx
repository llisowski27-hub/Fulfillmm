// ============================================================
// THE LIQUIDATOR — Edit Client Page
// src/app/clients/[id]/edit/page.tsx
// ============================================================

import { notFound } from "next/navigation";
import { getClientByIdAction } from "@/actions/clients";
import { ClientForm } from "@/components/clients/client-form";

export const metadata = { title: "Edycja klienta | The Liquidator" };

interface Props {
  params: Promise<{ id: string }>;
}

export default async function EditClientPage({ params }: Props) {
  const { id } = await params;
  const result = await getClientByIdAction(id);

  if (!result.success) notFound();

  return (
    <main className="mx-auto max-w-2xl p-6">
      <ClientForm client={result.data} />
    </main>
  );
}
