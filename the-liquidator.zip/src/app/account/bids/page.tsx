// ============================================================
// THE LIQUIDATOR — Moje licytacje
// src/app/account/bids/page.tsx
// ============================================================

import { redirect } from "next/navigation";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { getUserBidsAction } from "@/actions/auctions";
import { getAuctionsAction } from "@/actions/auctions";
import { getListingsAction } from "@/actions/listings";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export const metadata = { title: "Moje licytacje | The Liquidator" };

export default async function MyBidsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const [bidsRes, auctionsRes, listingsRes] = await Promise.all([
    getUserBidsAction(user.id),
    getAuctionsAction(),
    getListingsAction(),
  ]);

  const bids = bidsRes.success ? bidsRes.data : [];
  const auctions = auctionsRes.success ? auctionsRes.data : [];
  const listings = listingsRes.success ? listingsRes.data : [];

  if (bids.length === 0) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-2">Moje licytacje</h1>
        <p className="text-muted-foreground mb-6">
          Nie brałeś jeszcze udziału w żadnej aukcji.
        </p>
        <Link
          href="/catalog?type=auction"
          className="text-sm underline"
        >
          Przeglądaj aukcje
        </Link>
      </main>
    );
  }

  // Grupuj bidy po aukcji — pokaż unikalną aukcję raz
  const auctionMap = new Map(auctions.map((a) => [a.id, a]));
  const listingMap = new Map(listings.map((l) => [l.id, l]));

  const uniqueAuctionIds = [...new Set(bids.map((b) => b.auction_id))];

  const auctionEntries = uniqueAuctionIds
    .map((auctionId) => {
      const auction = auctionMap.get(auctionId);
      if (!auction) return null;

      const listing = listingMap.get(auction.listing_id);
      const myBids = bids
        .filter((b) => b.auction_id === auctionId)
        .sort(
          (a, b) =>
            new Date(b.created_at).getTime() -
            new Date(a.created_at).getTime()
        );
      const myHighest = myBids[0];
      const isWinning = myHighest?.is_winning ?? false;
      const isEnded =
        auction.status === "ended" ||
        new Date(auction.end_time) <= new Date();

      let status: "leading" | "outbid" | "won" | "lost";
      if (isEnded) {
        status = isWinning ? "won" : "lost";
      } else {
        status = isWinning ? "leading" : "outbid";
      }

      return { auction, listing, myHighest, myBids, status };
    })
    .filter(Boolean);

  const STATUS_CONFIG = {
    leading: {
      label: "Prowadzisz",
      variant: "default" as const,
      className: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
    },
    outbid: {
      label: "Przebity",
      variant: "destructive" as const,
      className: "",
    },
    won: {
      label: "Wygrałeś",
      variant: "default" as const,
      className: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
    },
    lost: {
      label: "Przegrana",
      variant: "secondary" as const,
      className: "",
    },
  };

  return (
    <main className="mx-auto max-w-3xl px-4 py-6 sm:px-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold tracking-tight">
          Moje licytacje
        </h1>
        <span className="text-sm text-muted-foreground">
          {uniqueAuctionIds.length} aukcji
        </span>
      </div>

      <div className="space-y-3">
        {auctionEntries.map((entry) => {
          if (!entry) return null;
          const { auction, listing, myHighest, myBids, status } = entry;
          const config = STATUS_CONFIG[status];
          const href = listing?.slug
            ? `/product/${listing.slug}`
            : `/product/${listing?.id ?? auction.listing_id}`;

          return (
            <Link key={auction.id} href={href} className="block group">
              <Card className="transition-colors hover:border-foreground/20">
                <CardContent className="flex items-center gap-4 py-4">
                  {/* Miniatura */}
                  <div className="h-14 w-14 shrink-0 overflow-hidden rounded-md bg-muted">
                    {listing?.images[0] ? (
                      <img
                        src={listing.images[0]}
                        alt={listing.title}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center text-xs text-muted-foreground">
                        —
                      </div>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">
                      {listing?.title ?? "Aukcja"}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {myBids.length}{" "}
                      {myBids.length === 1 ? "oferta" : "ofert"} · Twoja
                      najwyższa:{" "}
                      <span className="tabular-nums font-medium">
                        {myHighest.amount.toFixed(2)} zł
                      </span>
                    </p>
                  </div>

                  {/* Aktualna cena */}
                  <div className="text-right shrink-0">
                    <p className="text-sm font-semibold tabular-nums">
                      {(
                        auction.current_price ?? auction.starting_price
                      ).toFixed(2)}{" "}
                      zł
                    </p>
                    <Badge
                      variant={config.variant}
                      className={`text-[11px] mt-1 ${config.className}`}
                    >
                      {config.label}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>
    </main>
  );
}
