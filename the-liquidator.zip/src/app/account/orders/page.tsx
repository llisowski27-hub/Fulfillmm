// ============================================================
// THE LIQUIDATOR — Moje zamówienia
// src/app/account/orders/page.tsx
// ============================================================

import { redirect } from "next/navigation";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { getUserOrdersAction } from "@/actions/orders";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { ORDER_STATUS_LABELS } from "@/types";

export const metadata = { title: "Moje zamówienia | The Liquidator" };

const STATUS_VARIANT: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  pending: "outline",
  paid: "default",
  shipped: "default",
  completed: "secondary",
  cancelled: "destructive",
};

export default async function MyOrdersPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const result = await getUserOrdersAction(user.id);
  const orders = result.success ? result.data : [];

  if (orders.length === 0) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-2">Moje zamówienia</h1>
        <p className="text-muted-foreground mb-6">
          Nie masz jeszcze żadnych zamówień.
        </p>
        <Link href="/catalog" className="text-sm underline">
          Przejdź do katalogu
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-3xl px-4 py-6 sm:px-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold tracking-tight">
          Moje zamówienia
        </h1>
        <span className="text-sm text-muted-foreground">
          {orders.length}{" "}
          {orders.length === 1 ? "zamówienie" : "zamówień"}
        </span>
      </div>

      <div className="space-y-3">
        {orders.map((order) => {
          const date = new Date(order.created_at);

          return (
            <Link
              key={order.id}
              href={`/order/${order.id}/success`}
              className="block group"
            >
              <Card className="transition-colors hover:border-foreground/20">
                <CardContent className="flex items-center justify-between py-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-mono text-muted-foreground">
                        #{order.id.slice(0, 8)}
                      </span>
                      <Badge
                        variant={STATUS_VARIANT[order.status] ?? "outline"}
                        className="text-[11px]"
                      >
                        {ORDER_STATUS_LABELS[order.status]}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {date.toLocaleDateString("pl-PL")} ·{" "}
                      {order.shipping_city}
                    </p>
                  </div>

                  <div className="text-right shrink-0">
                    <p className="text-base font-semibold tabular-nums">
                      {order.total.toLocaleString("pl-PL", {
                        minimumFractionDigits: 2,
                      })}{" "}
                      zł
                    </p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>
    </main>
  );
}
