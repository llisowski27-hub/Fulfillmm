// ============================================================
// THE LIQUIDATOR — Order Success Page
// src/app/order/[id]/success/page.tsx
// ============================================================

import { notFound } from "next/navigation";
import Link from "next/link";
import { getOrderWithItemsAction } from "@/actions/orders";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ORDER_STATUS_LABELS } from "@/types";

interface Props {
  params: Promise<{ id: string }>;
}

export async function generateMetadata() {
  return { title: "Zamówienie złożone | The Liquidator" };
}

export default async function OrderSuccessPage({ params }: Props) {
  const { id } = await params;
  const result = await getOrderWithItemsAction(id);

  if (!result.success) notFound();

  const { order, items } = result.data;

  return (
    <main className="mx-auto max-w-2xl px-4 py-12 sm:px-6">
      {/* Nagłówek sukcesu */}
      <div className="text-center mb-8">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-50 dark:bg-green-950">
          <svg
            className="h-8 w-8 text-green-600 dark:text-green-400"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={2}
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M4.5 12.75l6 6 9-13.5"
            />
          </svg>
        </div>
        <h1 className="text-2xl font-bold">Zamówienie złożone</h1>
        <p className="text-muted-foreground mt-1">
          Numer zamówienia:{" "}
          <span className="font-mono text-sm">{order.id.slice(0, 8)}</span>
        </p>
      </div>

      {/* Szczegóły zamówienia */}
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">
              Szczegóły zamówienia
            </CardTitle>
            <Badge variant="outline">
              {ORDER_STATUS_LABELS[order.status]}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Pozycje */}
          <ul className="space-y-2">
            {items.map((item) => (
              <li
                key={item.id}
                className="flex justify-between text-sm"
              >
                <span>
                  {item.quantity} × {item.unit_price.toFixed(2)} zł
                </span>
                <span className="font-medium tabular-nums">
                  {item.total_price.toLocaleString("pl-PL", {
                    minimumFractionDigits: 2,
                  })}{" "}
                  zł
                </span>
              </li>
            ))}
          </ul>

          {/* Kwoty */}
          <div className="border-t pt-3 space-y-1">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Produkty</span>
              <span className="tabular-nums">
                {order.subtotal.toFixed(2)} zł
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Dostawa</span>
              <span className="tabular-nums">
                {order.shipping_cost.toFixed(2)} zł
              </span>
            </div>
            <div className="flex justify-between pt-2 border-t font-semibold">
              <span>Razem</span>
              <span className="tabular-nums">
                {order.total.toLocaleString("pl-PL", {
                  minimumFractionDigits: 2,
                })}{" "}
                zł
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Adres dostawy */}
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Adres dostawy</CardTitle>
        </CardHeader>
        <CardContent className="text-sm space-y-0.5">
          <p className="font-medium">{order.shipping_name}</p>
          <p className="text-muted-foreground">{order.shipping_street}</p>
          <p className="text-muted-foreground">
            {order.shipping_postal} {order.shipping_city}
          </p>
          <p className="text-muted-foreground">{order.shipping_country}</p>
          {order.shipping_phone && (
            <p className="text-muted-foreground mt-1">
              Tel: {order.shipping_phone}
            </p>
          )}
        </CardContent>
      </Card>

      {/* Uwagi */}
      {order.notes && (
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Uwagi</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">{order.notes}</p>
          </CardContent>
        </Card>
      )}

      {/* Płatność */}
      <Card className="mb-8">
        <CardContent className="py-4">
          <p className="text-sm text-center text-muted-foreground">
            Płatność: przelew tradycyjny lub przy odbiorze.
            <br />
            Dane do przelewu zostaną wysłane na email.
          </p>
        </CardContent>
      </Card>

      {/* Akcje */}
      <div className="flex gap-3 justify-center">
        <Link href="/catalog">
          <Button variant="outline">Kontynuuj zakupy</Button>
        </Link>
        <Link href="/">
          <Button>Strona główna</Button>
        </Link>
      </div>
    </main>
  );
}
