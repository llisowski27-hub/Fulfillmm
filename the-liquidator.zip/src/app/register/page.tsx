// ============================================================
// THE LIQUIDATOR — Register Page
// src/app/register/page.tsx
// ============================================================

"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { registerAction } from "@/actions/auth";

export default function RegisterPage() {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    startTransition(async () => {
      const result = await registerAction({
        display_name: displayName,
        email,
        password,
      });
      if (!result.success) {
        toast.error("Błąd rejestracji", { description: result.error });
        return;
      }
      toast.success("Konto utworzone", {
        description: "Możesz się teraz zalogować",
      });
      router.push("/login");
    });
  }

  return (
    <main className="mx-auto max-w-sm px-4 py-16">
      <Card>
        <CardHeader>
          <CardTitle className="text-center">Utwórz konto</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">
                Nazwa
              </label>
              <Input
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Jan Kowalski"
                required
                disabled={isPending}
                autoFocus
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">
                Email
              </label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="twoj@email.pl"
                required
                disabled={isPending}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">
                Hasło
              </label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Min 6 znaków"
                required
                minLength={6}
                disabled={isPending}
              />
            </div>
            <Button type="submit" className="w-full" disabled={isPending}>
              {isPending ? "Tworzę konto…" : "Zarejestruj się"}
            </Button>
          </form>
          <p className="text-center text-sm text-muted-foreground mt-4">
            Masz konto?{" "}
            <Link href="/login" className="underline hover:text-foreground">
              Zaloguj się
            </Link>
          </p>
        </CardContent>
      </Card>
    </main>
  );
}
